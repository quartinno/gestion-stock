import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';

const MovementSummary = ({ summaryData, trendData }) => {
  const COLORS = ['#059669', '#DC2626', '#D97706', '#0EA5E9'];

  const movementTypeData = [
    { name: 'Stock In', value: summaryData.stockIn, color: '#059669' },
    { name: 'Stock Out', value: summaryData.stockOut, color: '#DC2626' },
    { name: 'Adjustments', value: summaryData.adjustments, color: '#D97706' },
    { name: 'Transfers', value: summaryData.transfers, color: '#0EA5E9' }
  ];

  const StatCard = ({ title, value, icon, color, change }) => (
    <div className="bg-surface border border-border rounded-lg p-4">
      <div className="flex items-center justify-between mb-2">
        <div className={`w-10 h-10 ${color} rounded-lg flex items-center justify-center`}>
          <Icon name={icon} size={20} color="white" />
        </div>
        {change && (
          <span className={`text-xs font-medium ${change > 0 ? 'text-success' : 'text-error'}`}>
            {change > 0 ? '+' : ''}{change}%
          </span>
        )}
      </div>
      <h3 className="text-2xl font-bold text-text-primary">{value.toLocaleString()}</h3>
      <p className="text-sm text-text-secondary">{title}</p>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <StatCard
          title="Total Movements Today"
          value={summaryData.totalMovements}
          icon="Activity"
          color="bg-primary"
          change={12}
        />
        <StatCard
          title="Active Locations"
          value={summaryData.activeLocations}
          icon="MapPin"
          color="bg-accent"
          change={-2}
        />
        <StatCard
          title="Products Affected"
          value={summaryData.productsAffected}
          icon="Package"
          color="bg-success"
          change={8}
        />
        <StatCard
          title="Total Value"
          value={summaryData.totalValue}
          icon="DollarSign"
          color="bg-warning"
          change={15}
        />
      </div>

      {/* Movement Type Distribution */}
      <div className="bg-surface border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4">Movement Type Distribution</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={movementTypeData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {movementTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [value.toLocaleString(), 'Movements']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-2 gap-4 mt-4">
          {movementTypeData.map((item, index) => (
            <div key={index} className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: item.color }}
              />
              <span className="text-sm text-text-secondary">{item.name}</span>
              <span className="text-sm font-medium text-text-primary ml-auto">
                {item.value.toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Weekly Trend */}
      <div className="bg-surface border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4">Weekly Movement Trend</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis 
                dataKey="day" 
                stroke="var(--color-text-secondary)"
                fontSize={12}
              />
              <YAxis 
                stroke="var(--color-text-secondary)"
                fontSize={12}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="movements" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-surface border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 gap-3">
          <button className="flex items-center gap-3 p-3 text-left hover:bg-secondary-50 rounded-lg transition-colors duration-200">
            <div className="w-8 h-8 bg-success-100 rounded-lg flex items-center justify-center">
              <Icon name="Plus" size={16} className="text-success" />
            </div>
            <div>
              <p className="text-sm font-medium text-text-primary">Record Stock In</p>
              <p className="text-xs text-text-secondary">Add new inventory</p>
            </div>
          </button>
          <button className="flex items-center gap-3 p-3 text-left hover:bg-secondary-50 rounded-lg transition-colors duration-200">
            <div className="w-8 h-8 bg-error-100 rounded-lg flex items-center justify-center">
              <Icon name="Minus" size={16} className="text-error" />
            </div>
            <div>
              <p className="text-sm font-medium text-text-primary">Record Stock Out</p>
              <p className="text-xs text-text-secondary">Remove inventory</p>
            </div>
          </button>
          <button className="flex items-center gap-3 p-3 text-left hover:bg-secondary-50 rounded-lg transition-colors duration-200">
            <div className="w-8 h-8 bg-warning-100 rounded-lg flex items-center justify-center">
              <Icon name="Settings" size={16} className="text-warning" />
            </div>
            <div>
              <p className="text-sm font-medium text-text-primary">Stock Adjustment</p>
              <p className="text-xs text-text-secondary">Correct inventory levels</p>
            </div>
          </button>
          <button className="flex items-center gap-3 p-3 text-left hover:bg-secondary-50 rounded-lg transition-colors duration-200">
            <div className="w-8 h-8 bg-accent-100 rounded-lg flex items-center justify-center">
              <Icon name="ArrowLeftRight" size={16} className="text-accent" />
            </div>
            <div>
              <p className="text-sm font-medium text-text-primary">Transfer Stock</p>
              <p className="text-xs text-text-secondary">Move between locations</p>
            </div>
          </button>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-surface border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4">Recent Activity</h3>
        <div className="space-y-3">
          {summaryData.recentActivity.map((activity, index) => (
            <div key={index} className="flex items-center gap-3 p-2">
              <div className={`w-2 h-2 rounded-full ${
                activity.type === 'in' ? 'bg-success' :
                activity.type === 'out' ? 'bg-error' :
                activity.type === 'adjustment' ? 'bg-warning' : 'bg-accent'
              }`} />
              <div className="flex-1">
                <p className="text-sm text-text-primary">{activity.description}</p>
                <p className="text-xs text-text-secondary">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MovementSummary;