import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const MovementTable = ({ movements, onSort, sortConfig, onBulkAction, selectedMovements, onSelectionChange }) => {
  const [expandedRows, setExpandedRows] = useState(new Set());

  const getMovementTypeIcon = (type) => {
    switch (type) {
      case 'in': return 'ArrowDown';
      case 'out': return 'ArrowUp';
      case 'adjustment': return 'Settings';
      case 'transfer': return 'ArrowLeftRight';
      default: return 'Package';
    }
  };

  const getMovementTypeColor = (type) => {
    switch (type) {
      case 'in': return 'text-success bg-success-50';
      case 'out': return 'text-error bg-error-50';
      case 'adjustment': return 'text-warning bg-warning-50';
      case 'transfer': return 'text-accent bg-accent-50';
      default: return 'text-text-secondary bg-secondary-50';
    }
  };

  const handleSort = (column) => {
    const direction = sortConfig.column === column && sortConfig.direction === 'asc' ? 'desc' : 'asc';
    onSort({ column, direction });
  };

  const toggleRowExpansion = (movementId) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(movementId)) {
      newExpanded.delete(movementId);
    } else {
      newExpanded.add(movementId);
    }
    setExpandedRows(newExpanded);
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      onSelectionChange(movements.map(m => m.id));
    } else {
      onSelectionChange([]);
    }
  };

  const handleSelectMovement = (movementId, checked) => {
    if (checked) {
      onSelectionChange([...selectedMovements, movementId]);
    } else {
      onSelectionChange(selectedMovements.filter(id => id !== movementId));
    }
  };

  const formatDateTime = (dateTime) => {
    return new Date(dateTime).toLocaleString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getSortIcon = (column) => {
    if (sortConfig.column !== column) return 'ArrowUpDown';
    return sortConfig.direction === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  return (
    <div className="bg-surface border border-border rounded-lg overflow-hidden">
      {/* Table Header with Bulk Actions */}
      {selectedMovements.length > 0 && (
        <div className="bg-primary-50 border-b border-border p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-text-primary">
              {selectedMovements.length} movement{selectedMovements.length !== 1 ? 's' : ''} selected
            </span>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => onBulkAction('reverse')}
                iconName="Undo"
              >
                Reverse
              </Button>
              <Button
                variant="outline"
                onClick={() => onBulkAction('export')}
                iconName="Download"
              >
                Export Selected
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Table */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-secondary-50 border-b border-border">
            <tr>
              <th className="px-4 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedMovements.length === movements.length && movements.length > 0}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                  className="rounded border-border"
                />
              </th>
              <th className="px-4 py-3 text-left">
                <button
                  onClick={() => handleSort('timestamp')}
                  className="flex items-center gap-2 text-sm font-medium text-text-secondary hover:text-text-primary"
                >
                  Timestamp
                  <Icon name={getSortIcon('timestamp')} size={16} />
                </button>
              </th>
              <th className="px-4 py-3 text-left">
                <button
                  onClick={() => handleSort('product')}
                  className="flex items-center gap-2 text-sm font-medium text-text-secondary hover:text-text-primary"
                >
                  Product
                  <Icon name={getSortIcon('product')} size={16} />
                </button>
              </th>
              <th className="px-4 py-3 text-left">
                <button
                  onClick={() => handleSort('type')}
                  className="flex items-center gap-2 text-sm font-medium text-text-secondary hover:text-text-primary"
                >
                  Type
                  <Icon name={getSortIcon('type')} size={16} />
                </button>
              </th>
              <th className="px-4 py-3 text-left">
                <button
                  onClick={() => handleSort('quantity')}
                  className="flex items-center gap-2 text-sm font-medium text-text-secondary hover:text-text-primary"
                >
                  Quantity
                  <Icon name={getSortIcon('quantity')} size={16} />
                </button>
              </th>
              <th className="px-4 py-3 text-left">Location</th>
              <th className="px-4 py-3 text-left">User</th>
              <th className="px-4 py-3 text-left">Reference</th>
              <th className="px-4 py-3 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {movements.map((movement) => (
              <React.Fragment key={movement.id}>
                <tr className="border-b border-border hover:bg-secondary-50">
                  <td className="px-4 py-3">
                    <input
                      type="checkbox"
                      checked={selectedMovements.includes(movement.id)}
                      onChange={(e) => handleSelectMovement(movement.id, e.target.checked)}
                      className="rounded border-border"
                    />
                  </td>
                  <td className="px-4 py-3 text-sm text-text-primary">
                    {formatDateTime(movement.timestamp)}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-secondary-100 rounded-lg flex items-center justify-center">
                        <Icon name="Package" size={16} className="text-text-secondary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-text-primary">{movement.product.name}</p>
                        <p className="text-xs text-text-secondary">SKU: {movement.product.sku}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${getMovementTypeColor(movement.type)}`}>
                      <Icon name={getMovementTypeIcon(movement.type)} size={14} />
                      {movement.type.charAt(0).toUpperCase() + movement.type.slice(1)}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-medium ${movement.type === 'out' ? 'text-error' : 'text-success'}`}>
                      {movement.type === 'out' ? '-' : '+'}{movement.quantity}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-text-secondary">{movement.location}</td>
                  <td className="px-4 py-3 text-sm text-text-secondary">{movement.user}</td>
                  <td className="px-4 py-3 text-sm text-text-secondary">{movement.reference}</td>
                  <td className="px-4 py-3">
                    <Button
                      variant="ghost"
                      onClick={() => toggleRowExpansion(movement.id)}
                      iconName={expandedRows.has(movement.id) ? "ChevronUp" : "ChevronDown"}
                    />
                  </td>
                </tr>
                {expandedRows.has(movement.id) && (
                  <tr className="bg-secondary-50">
                    <td colSpan="9" className="px-4 py-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <h4 className="font-medium text-text-primary mb-2">Additional Details</h4>
                          <div className="space-y-1">
                            <p><span className="text-text-secondary">Batch Number:</span> {movement.batchNumber || 'N/A'}</p>
                            <p><span className="text-text-secondary">Serial Number:</span> {movement.serialNumber || 'N/A'}</p>
                            <p><span className="text-text-secondary">Cost per Unit:</span> ${movement.costPerUnit || '0.00'}</p>
                            <p><span className="text-text-secondary">Total Value:</span> ${movement.totalValue || '0.00'}</p>
                          </div>
                        </div>
                        <div>
                          <h4 className="font-medium text-text-primary mb-2">Notes</h4>
                          <p className="text-text-secondary">{movement.notes || 'No notes available'}</p>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile/Tablet Timeline View */}
      <div className="lg:hidden">
        {movements.map((movement) => (
          <div key={movement.id} className="border-b border-border p-4">
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={selectedMovements.includes(movement.id)}
                onChange={(e) => handleSelectMovement(movement.id, e.target.checked)}
                className="rounded border-border mt-1"
              />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${getMovementTypeColor(movement.type)}`}>
                    <Icon name={getMovementTypeIcon(movement.type)} size={14} />
                    {movement.type.charAt(0).toUpperCase() + movement.type.slice(1)}
                  </span>
                  <span className="text-xs text-text-secondary">
                    {formatDateTime(movement.timestamp)}
                  </span>
                </div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 bg-secondary-100 rounded-lg flex items-center justify-center">
                    <Icon name="Package" size={14} className="text-text-secondary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-text-primary">{movement.product.name}</p>
                    <p className="text-xs text-text-secondary">SKU: {movement.product.sku}</p>
                  </div>
                  <span className={`text-sm font-medium ${movement.type === 'out' ? 'text-error' : 'text-success'}`}>
                    {movement.type === 'out' ? '-' : '+'}{movement.quantity}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-text-secondary">
                  <p><span className="font-medium">Location:</span> {movement.location}</p>
                  <p><span className="font-medium">User:</span> {movement.user}</p>
                  <p><span className="font-medium">Reference:</span> {movement.reference}</p>
                </div>
                {expandedRows.has(movement.id) && (
                  <div className="mt-3 pt-3 border-t border-border">
                    <div className="space-y-2 text-xs">
                      <p><span className="font-medium text-text-secondary">Batch:</span> {movement.batchNumber || 'N/A'}</p>
                      <p><span className="font-medium text-text-secondary">Serial:</span> {movement.serialNumber || 'N/A'}</p>
                      <p><span className="font-medium text-text-secondary">Cost:</span> ${movement.costPerUnit || '0.00'}</p>
                      <p><span className="font-medium text-text-secondary">Notes:</span> {movement.notes || 'No notes'}</p>
                    </div>
                  </div>
                )}
                <Button
                  variant="ghost"
                  onClick={() => toggleRowExpansion(movement.id)}
                  iconName={expandedRows.has(movement.id) ? "ChevronUp" : "ChevronDown"}
                  className="mt-2 text-xs"
                >
                  {expandedRows.has(movement.id) ? 'Less Details' : 'More Details'}
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MovementTable;