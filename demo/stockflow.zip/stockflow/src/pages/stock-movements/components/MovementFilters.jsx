import React, { useState } from 'react';

import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const MovementFilters = ({ onFiltersChange, onExport, onSaveFilter, savedFilters }) => {
  const [filters, setFilters] = useState({
    dateFrom: '',
    dateTo: '',
    movementType: '',
    productSearch: '',
    location: '',
    user: '',
    referenceNumber: ''
  });
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [filterName, setFilterName] = useState('');

  const movementTypes = [
    { value: '', label: 'All Types' },
    { value: 'in', label: 'Stock In' },
    { value: 'out', label: 'Stock Out' },
    { value: 'adjustment', label: 'Adjustment' },
    { value: 'transfer', label: 'Transfer' }
  ];

  const locations = [
    { value: '', label: 'All Locations' },
    { value: 'warehouse-a', label: 'Warehouse A' },
    { value: 'warehouse-b', label: 'Warehouse B' },
    { value: 'store-front', label: 'Store Front' },
    { value: 'storage-room', label: 'Storage Room' }
  ];

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const handleClearFilters = () => {
    const clearedFilters = {
      dateFrom: '',
      dateTo: '',
      movementType: '',
      productSearch: '',
      location: '',
      user: '',
      referenceNumber: ''
    };
    setFilters(clearedFilters);
    onFiltersChange(clearedFilters);
  };

  const handleSaveFilter = () => {
    if (filterName.trim()) {
      onSaveFilter(filterName, filters);
      setFilterName('');
      setShowSaveDialog(false);
    }
  };

  const handleLoadSavedFilter = (savedFilter) => {
    setFilters(savedFilter.filters);
    onFiltersChange(savedFilter.filters);
  };

  return (
    <div className="bg-surface border border-border rounded-lg p-4 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-4">
        <h3 className="text-lg font-semibold text-text-primary">Filter Movements</h3>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            onClick={() => setShowAdvanced(!showAdvanced)}
            iconName={showAdvanced ? "ChevronUp" : "ChevronDown"}
            iconPosition="right"
          >
            Advanced Filters
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowSaveDialog(true)}
            iconName="Save"
          >
            Save Filter
          </Button>
          <Button
            variant="primary"
            onClick={onExport}
            iconName="Download"
          >
            Export
          </Button>
        </div>
      </div>

      {/* Basic Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <div>
          <label className="block text-sm font-medium text-text-secondary mb-2">
            Date From
          </label>
          <Input
            type="date"
            value={filters.dateFrom}
            onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-text-secondary mb-2">
            Date To
          </label>
          <Input
            type="date"
            value={filters.dateTo}
            onChange={(e) => handleFilterChange('dateTo', e.target.value)}
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-text-secondary mb-2">
            Movement Type
          </label>
          <select
            value={filters.movementType}
            onChange={(e) => handleFilterChange('movementType', e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            {movementTypes.map(type => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-text-secondary mb-2">
            Search Product
          </label>
          <Input
            type="search"
            placeholder="Product name or SKU..."
            value={filters.productSearch}
            onChange={(e) => handleFilterChange('productSearch', e.target.value)}
            className="w-full"
          />
        </div>
      </div>

      {/* Advanced Filters */}
      {showAdvanced && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 p-4 bg-secondary-50 rounded-lg">
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-2">
              Location
            </label>
            <select
              value={filters.location}
              onChange={(e) => handleFilterChange('location', e.target.value)}
              className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              {locations.map(location => (
                <option key={location.value} value={location.value}>
                  {location.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-2">
              User
            </label>
            <Input
              type="text"
              placeholder="User name..."
              value={filters.user}
              onChange={(e) => handleFilterChange('user', e.target.value)}
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-2">
              Reference Number
            </label>
            <Input
              type="text"
              placeholder="Reference number..."
              value={filters.referenceNumber}
              onChange={(e) => handleFilterChange('referenceNumber', e.target.value)}
              className="w-full"
            />
          </div>
        </div>
      )}

      {/* Saved Filters */}
      {savedFilters.length > 0 && (
        <div className="mb-4">
          <label className="block text-sm font-medium text-text-secondary mb-2">
            Saved Filters
          </label>
          <div className="flex flex-wrap gap-2">
            {savedFilters.map((savedFilter, index) => (
              <Button
                key={index}
                variant="outline"
                onClick={() => handleLoadSavedFilter(savedFilter)}
                className="text-sm"
              >
                {savedFilter.name}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end gap-2">
        <Button
          variant="ghost"
          onClick={handleClearFilters}
          iconName="X"
        >
          Clear All
        </Button>
      </div>

      {/* Save Filter Dialog */}
      {showSaveDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-surface border border-border rounded-lg p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-semibold text-text-primary mb-4">Save Filter</h3>
            <Input
              type="text"
              placeholder="Enter filter name..."
              value={filterName}
              onChange={(e) => setFilterName(e.target.value)}
              className="w-full mb-4"
            />
            <div className="flex justify-end gap-2">
              <Button
                variant="ghost"
                onClick={() => setShowSaveDialog(false)}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                onClick={handleSaveFilter}
                disabled={!filterName.trim()}
              >
                Save
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MovementFilters;