import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const BarcodeScanner = ({ onScanResult, onClose }) => {
  const [isScanning, setIsScanning] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [scanHistory, setScanHistory] = useState([]);
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  const startScanning = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsScanning(true);
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      alert('Unable to access camera. Please check permissions or use manual entry.');
    }
  };

  const stopScanning = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsScanning(false);
  };

  const handleManualSubmit = (e) => {
    e.preventDefault();
    if (manualCode.trim()) {
      const scanResult = {
        code: manualCode.trim(),
        timestamp: new Date(),
        method: 'manual'
      };
      
      setScanHistory(prev => [scanResult, ...prev.slice(0, 9)]);
      onScanResult(scanResult);
      setManualCode('');
    }
  };

  const handleHistorySelect = (historyItem) => {
    onScanResult(historyItem);
  };

  // Mock barcode detection (in real implementation, use a barcode scanning library)
  const simulateScan = () => {
    const mockCodes = [
      '1234567890123',
      '9876543210987',
      '5555555555555',
      '1111111111111'
    ];
    
    const randomCode = mockCodes[Math.floor(Math.random() * mockCodes.length)];
    const scanResult = {
      code: randomCode,
      timestamp: new Date(),
      method: 'camera'
    };
    
    setScanHistory(prev => [scanResult, ...prev.slice(0, 9)]);
    onScanResult(scanResult);
    stopScanning();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-surface border border-border rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h3 className="text-lg font-semibold text-text-primary">Barcode Scanner</h3>
          <Button
            variant="ghost"
            onClick={onClose}
            iconName="X"
          />
        </div>

        <div className="p-4 space-y-4">
          {/* Camera Scanner */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-text-primary">Camera Scanner</h4>
            
            {!isScanning ? (
              <div className="bg-secondary-50 border-2 border-dashed border-border rounded-lg p-8 text-center">
                <Icon name="Camera" size={48} className="text-text-secondary mx-auto mb-4" />
                <p className="text-sm text-text-secondary mb-4">
                  Position barcode within camera view
                </p>
                <Button
                  variant="primary"
                  onClick={startScanning}
                  iconName="Camera"
                >
                  Start Scanning
                </Button>
              </div>
            ) : (
              <div className="relative">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-48 bg-black rounded-lg object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-48 h-24 border-2 border-primary rounded-lg"></div>
                </div>
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                  <Button
                    variant="success"
                    onClick={simulateScan}
                    iconName="Check"
                  >
                    Simulate Scan
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={stopScanning}
                    iconName="X"
                  >
                    Stop
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Manual Entry */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-text-primary">Manual Entry</h4>
            <form onSubmit={handleManualSubmit} className="flex gap-2">
              <Input
                type="text"
                placeholder="Enter barcode manually..."
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                className="flex-1"
              />
              <Button
                type="submit"
                variant="primary"
                iconName="Plus"
                disabled={!manualCode.trim()}
              >
                Add
              </Button>
            </form>
          </div>

          {/* Scan History */}
          {scanHistory.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-text-primary">Recent Scans</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {scanHistory.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => handleHistorySelect(item)}
                    className="w-full flex items-center justify-between p-3 bg-secondary-50 hover:bg-secondary-100 rounded-lg transition-colors duration-200"
                  >
                    <div className="text-left">
                      <p className="text-sm font-medium text-text-primary">{item.code}</p>
                      <p className="text-xs text-text-secondary">
                        {item.timestamp.toLocaleTimeString()} • {item.method}
                      </p>
                    </div>
                    <Icon name="ArrowRight" size={16} className="text-text-secondary" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Instructions */}
          <div className="bg-accent-50 border border-accent-200 rounded-lg p-3">
            <div className="flex items-start gap-2">
              <Icon name="Info" size={16} className="text-accent mt-0.5" />
              <div className="text-xs text-accent-700">
                <p className="font-medium mb-1">Scanning Tips:</p>
                <ul className="space-y-1">
                  <li>• Ensure good lighting</li>
                  <li>• Hold device steady</li>
                  <li>• Position barcode within frame</li>
                  <li>• Use manual entry if camera fails</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BarcodeScanner;