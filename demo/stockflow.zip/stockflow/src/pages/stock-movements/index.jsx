import React, { useState, useEffect } from 'react';
import Sidebar from '../../components/ui/Sidebar';
import Header from '../../components/ui/Header';
import MobileNavigation from '../../components/ui/MobileNavigation';
import Breadcrumb from '../../components/ui/Breadcrumb';
import MovementFilters from './components/MovementFilters';
import MovementTable from './components/MovementTable';
import MovementSummary from './components/MovementSummary';
import BarcodeScanner from './components/BarcodeScanner';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const StockMovements = () => {
  const [movements, setMovements] = useState([]);
  const [filteredMovements, setFilteredMovements] = useState([]);
  const [filters, setFilters] = useState({});
  const [sortConfig, setSortConfig] = useState({ column: 'timestamp', direction: 'desc' });
  const [selectedMovements, setSelectedMovements] = useState([]);
  const [showSummary, setShowSummary] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [savedFilters, setSavedFilters] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Mock data for stock movements
  const mockMovements = [
    {
      id: 1,
      timestamp: new Date('2024-01-15T10:30:00'),
      product: {
        name: 'Wireless Bluetooth Headphones',
        sku: 'WBH-001'
      },
      type: 'in',
      quantity: 50,
      location: 'Warehouse A',
      user: 'John Smith',
      reference: 'PO-2024-001',
      batchNumber: 'BT-2024-001',
      serialNumber: null,
      costPerUnit: 45.99,
      totalValue: 2299.50,
      notes: 'New stock arrival from supplier ABC Electronics'
    },
    {
      id: 2,
      timestamp: new Date('2024-01-15T09:15:00'),
      product: {
        name: 'Gaming Mechanical Keyboard',
        sku: 'GMK-002'
      },
      type: 'out',
      quantity: 15,
      location: 'Store Front',
      user: 'Sarah Johnson',
      reference: 'SO-2024-045',
      batchNumber: null,
      serialNumber: 'GMK002-001-015',
      costPerUnit: 89.99,
      totalValue: 1349.85,
      notes: 'Customer order fulfillment - bulk sale to corporate client'
    },
    {
      id: 3,
      timestamp: new Date('2024-01-15T08:45:00'),
      product: {
        name: 'USB-C Charging Cable',
        sku: 'UCC-003'
      },
      type: 'adjustment',
      quantity: 5,
      location: 'Storage Room',
      user: 'Mike Wilson',
      reference: 'ADJ-2024-012',
      batchNumber: 'CC-2024-003',
      serialNumber: null,
      costPerUnit: 12.99,
      totalValue: 64.95,
      notes: 'Stock count discrepancy correction - found additional units during audit'
    },
    {
      id: 4,
      timestamp: new Date('2024-01-15T07:20:00'),
      product: {
        name: 'Smartphone Screen Protector',
        sku: 'SSP-004'
      },
      type: 'transfer',
      quantity: 25,
      location: 'Warehouse B',
      user: 'Emily Davis',
      reference: 'TRF-2024-008',
      batchNumber: 'SP-2024-002',
      serialNumber: null,
      costPerUnit: 8.99,
      totalValue: 224.75,
      notes: 'Transfer from Warehouse A to Warehouse B for regional distribution'
    },
    {
      id: 5,
      timestamp: new Date('2024-01-14T16:30:00'),
      product: {
        name: 'Wireless Mouse',
        sku: 'WM-005'
      },
      type: 'out',
      quantity: 30,
      location: 'Warehouse A',
      user: 'David Brown',
      reference: 'SO-2024-044',
      batchNumber: null,
      serialNumber: null,
      costPerUnit: 24.99,
      totalValue: 749.70,
      notes: 'Online order shipment - multiple customer orders'
    },
    {
      id: 6,
      timestamp: new Date('2024-01-14T15:10:00'),
      product: {
        name: 'Laptop Stand',
        sku: 'LS-006'
      },
      type: 'in',
      quantity: 20,
      location: 'Warehouse A',
      user: 'Lisa Anderson',
      reference: 'PO-2024-002',
      batchNumber: 'LS-2024-001',
      serialNumber: null,
      costPerUnit: 35.99,
      totalValue: 719.80,
      notes: 'Restocking popular item - high demand product'
    }
  ];

  // Mock summary data
  const mockSummaryData = {
    totalMovements: 156,
    activeLocations: 4,
    productsAffected: 89,
    totalValue: 15420,
    stockIn: 45,
    stockOut: 78,
    adjustments: 12,
    transfers: 21,
    recentActivity: [
      {
        type: 'in',
        description: 'Wireless Headphones received - 50 units',
        time: '2 minutes ago'
      },
      {
        type: 'out',
        description: 'Gaming Keyboard shipped - 15 units',
        time: '15 minutes ago'
      },
      {
        type: 'adjustment',
        description: 'USB Cable stock adjusted - +5 units',
        time: '30 minutes ago'
      },
      {
        type: 'transfer',
        description: 'Screen Protectors transferred - 25 units',
        time: '1 hour ago'
      }
    ]
  };

  // Mock trend data
  const mockTrendData = [
    { day: 'Mon', movements: 45 },
    { day: 'Tue', movements: 52 },
    { day: 'Wed', movements: 38 },
    { day: 'Thu', movements: 61 },
    { day: 'Fri', movements: 49 },
    { day: 'Sat', movements: 33 },
    { day: 'Sun', movements: 28 }
  ];

  useEffect(() => {
    // Simulate loading
    setTimeout(() => {
      setMovements(mockMovements);
      setFilteredMovements(mockMovements);
      setIsLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    // Apply filters and sorting
    let filtered = [...movements];

    // Apply filters
    if (filters.dateFrom) {
      filtered = filtered.filter(m => new Date(m.timestamp) >= new Date(filters.dateFrom));
    }
    if (filters.dateTo) {
      filtered = filtered.filter(m => new Date(m.timestamp) <= new Date(filters.dateTo));
    }
    if (filters.movementType) {
      filtered = filtered.filter(m => m.type === filters.movementType);
    }
    if (filters.productSearch) {
      const search = filters.productSearch.toLowerCase();
      filtered = filtered.filter(m => 
        m.product.name.toLowerCase().includes(search) ||
        m.product.sku.toLowerCase().includes(search)
      );
    }
    if (filters.location) {
      filtered = filtered.filter(m => m.location === filters.location);
    }
    if (filters.user) {
      filtered = filtered.filter(m => m.user.toLowerCase().includes(filters.user.toLowerCase()));
    }
    if (filters.referenceNumber) {
      filtered = filtered.filter(m => m.reference.toLowerCase().includes(filters.referenceNumber.toLowerCase()));
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let aValue = a[sortConfig.column];
      let bValue = b[sortConfig.column];

      if (sortConfig.column === 'product') {
        aValue = a.product.name;
        bValue = b.product.name;
      } else if (sortConfig.column === 'timestamp') {
        aValue = new Date(a.timestamp);
        bValue = new Date(b.timestamp);
      }

      if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });

    setFilteredMovements(filtered);
  }, [movements, filters, sortConfig]);

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleSort = (newSortConfig) => {
    setSortConfig(newSortConfig);
  };

  const handleBulkAction = (action) => {
    console.log(`Bulk action: ${action} for movements:`, selectedMovements);
    // Implement bulk actions here
    if (action === 'export') {
      handleExport(selectedMovements);
    }
  };

  const handleExport = (movementIds = null) => {
    const dataToExport = movementIds 
      ? filteredMovements.filter(m => movementIds.includes(m.id))
      : filteredMovements;
    
    console.log('Exporting movements:', dataToExport);
    // Implement export functionality here
    alert(`Exporting ${dataToExport.length} movements...`);
  };

  const handleSaveFilter = (name, filterData) => {
    const newSavedFilter = { name, filters: filterData };
    setSavedFilters(prev => [...prev, newSavedFilter]);
    console.log('Filter saved:', newSavedFilter);
  };

  const handleScanResult = (scanResult) => {
    console.log('Barcode scanned:', scanResult);
    // Find movement by barcode/reference
    const foundMovement = movements.find(m => 
      m.reference === scanResult.code || 
      m.product.sku === scanResult.code ||
      m.batchNumber === scanResult.code
    );
    
    if (foundMovement) {
      // Highlight the found movement
      setSelectedMovements([foundMovement.id]);
      alert(`Found movement: ${foundMovement.product.name}`);
    } else {
      alert('No movement found for this barcode');
    }
    
    setShowScanner(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Sidebar />
        <Header />
        <main className="lg:ml-sidebar pt-header">
          <div className="p-6">
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <Icon name="Loader2" size={48} className="text-primary animate-spin mx-auto mb-4" />
                <p className="text-text-secondary">Loading stock movements...</p>
              </div>
            </div>
          </div>
        </main>
        <MobileNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Header />
      
      <main className="lg:ml-sidebar pt-header">
        <div className="p-4 lg:p-6">
          <Breadcrumb />
          
          {/* Page Header */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold text-text-primary">Stock Movements</h1>
              <p className="text-text-secondary mt-1">
                Track and audit all inventory transactions across your locations
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => setShowScanner(true)}
                iconName="Scan"
              >
                Scan Barcode
              </Button>
              <Button
                variant="ghost"
                onClick={() => setShowSummary(!showSummary)}
                iconName={showSummary ? "X" : "BarChart3"}
                className="lg:hidden"
              >
                {showSummary ? 'Hide' : 'Summary'}
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-3 space-y-6">
              <MovementFilters
                onFiltersChange={handleFiltersChange}
                onExport={() => handleExport()}
                onSaveFilter={handleSaveFilter}
                savedFilters={savedFilters}
              />
              
              <div className="bg-surface border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <h2 className="text-lg font-semibold text-text-primary">
                      Movement History
                    </h2>
                    <span className="px-3 py-1 bg-primary-100 text-primary text-sm font-medium rounded-full">
                      {filteredMovements.length} movements
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Icon name="Activity" size={16} className="text-success animate-pulse" />
                    <span className="text-sm text-text-secondary">Live updates</span>
                  </div>
                </div>
                
                <MovementTable
                  movements={filteredMovements}
                  onSort={handleSort}
                  sortConfig={sortConfig}
                  onBulkAction={handleBulkAction}
                  selectedMovements={selectedMovements}
                  onSelectionChange={setSelectedMovements}
                />
              </div>
            </div>

            {/* Summary Panel */}
            <div className={`lg:col-span-1 ${showSummary ? 'block' : 'hidden lg:block'}`}>
              <MovementSummary
                summaryData={mockSummaryData}
                trendData={mockTrendData}
              />
            </div>
          </div>
        </div>
      </main>

      <MobileNavigation />
      
      {/* Barcode Scanner Modal */}
      {showScanner && (
        <BarcodeScanner
          onScanResult={handleScanResult}
          onClose={() => setShowScanner(false)}
        />
      )}
    </div>
  );
};

export default StockMovements;