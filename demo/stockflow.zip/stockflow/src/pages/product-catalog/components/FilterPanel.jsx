import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const FilterPanel = ({ isOpen, onClose, filters, onFiltersChange }) => {
  const [localFilters, setLocalFilters] = useState(filters);

  const categories = [
    { id: 'electronics', name: 'Electronics', count: 45 },
    { id: 'clothing', name: 'Clothing', count: 32 },
    { id: 'books', name: 'Books', count: 28 },
    { id: 'home-garden', name: 'Home & Garden', count: 19 },
    { id: 'sports', name: 'Sports & Outdoors', count: 15 },
    { id: 'toys', name: 'Toys & Games', count: 12 }
  ];

  const suppliers = [
    { id: 'supplier-1', name: 'TechCorp Solutions' },
    { id: 'supplier-2', name: 'Fashion Forward Inc' },
    { id: 'supplier-3', name: 'BookWorld Publishers' },
    { id: 'supplier-4', name: 'HomeStyle Distributors' },
    { id: 'supplier-5', name: 'SportMax Wholesale' }
  ];

  const stockStatuses = [
    { id: 'in-stock', name: 'In Stock', color: 'text-success' },
    { id: 'low-stock', name: 'Low Stock', color: 'text-warning' },
    { id: 'out-of-stock', name: 'Out of Stock', color: 'text-error' }
  ];

  const handleFilterChange = (key, value) => {
    setLocalFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleCategoryToggle = (categoryId) => {
    const updatedCategories = localFilters.categories.includes(categoryId)
      ? localFilters.categories.filter(id => id !== categoryId)
      : [...localFilters.categories, categoryId];
    
    handleFilterChange('categories', updatedCategories);
  };

  const handleSupplierToggle = (supplierId) => {
    const updatedSuppliers = localFilters.suppliers.includes(supplierId)
      ? localFilters.suppliers.filter(id => id !== supplierId)
      : [...localFilters.suppliers, supplierId];
    
    handleFilterChange('suppliers', updatedSuppliers);
  };

  const handleStockStatusToggle = (statusId) => {
    const updatedStatuses = localFilters.stockStatus.includes(statusId)
      ? localFilters.stockStatus.filter(id => id !== statusId)
      : [...localFilters.stockStatus, statusId];
    
    handleFilterChange('stockStatus', updatedStatuses);
  };

  const handleApplyFilters = () => {
    onFiltersChange(localFilters);
    onClose();
  };

  const handleResetFilters = () => {
    const resetFilters = {
      categories: [],
      suppliers: [],
      stockStatus: [],
      priceRange: { min: '', max: '' }
    };
    setLocalFilters(resetFilters);
    onFiltersChange(resetFilters);
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
        onClick={onClose}
      />
      
      {/* Filter Panel */}
      <div className={`
        fixed lg:absolute top-0 left-0 h-full lg:h-auto
        w-80 bg-surface border-r lg:border border-border z-50
        transform transition-transform duration-300 ease-out
        lg:transform-none lg:transition-none
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        overflow-y-auto
      `}>
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-text-primary">Filters</h3>
            <Button
              variant="ghost"
              onClick={onClose}
              className="p-1 lg:hidden"
            >
              <Icon name="X" size={20} />
            </Button>
          </div>
        </div>

        <div className="p-4 space-y-6">
          {/* Categories */}
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-3">Categories</h4>
            <div className="space-y-2">
              {categories.map(category => (
                <label key={category.id} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={localFilters.categories.includes(category.id)}
                    onChange={() => handleCategoryToggle(category.id)}
                    className="w-4 h-4 text-primary bg-surface border-border rounded focus:ring-primary focus:ring-2"
                  />
                  <span className="text-sm text-text-secondary flex-1">{category.name}</span>
                  <span className="text-xs text-text-quaternary">({category.count})</span>
                </label>
              ))}
            </div>
          </div>

          {/* Suppliers */}
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-3">Suppliers</h4>
            <div className="space-y-2">
              {suppliers.map(supplier => (
                <label key={supplier.id} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={localFilters.suppliers.includes(supplier.id)}
                    onChange={() => handleSupplierToggle(supplier.id)}
                    className="w-4 h-4 text-primary bg-surface border-border rounded focus:ring-primary focus:ring-2"
                  />
                  <span className="text-sm text-text-secondary">{supplier.name}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Stock Status */}
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-3">Stock Status</h4>
            <div className="space-y-2">
              {stockStatuses.map(status => (
                <label key={status.id} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={localFilters.stockStatus.includes(status.id)}
                    onChange={() => handleStockStatusToggle(status.id)}
                    className="w-4 h-4 text-primary bg-surface border-border rounded focus:ring-primary focus:ring-2"
                  />
                  <span className={`text-sm ${status.color}`}>{status.name}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-3">Price Range</h4>
            <div className="flex items-center space-x-2">
              <Input
                type="number"
                placeholder="Min"
                value={localFilters.priceRange.min}
                onChange={(e) => handleFilterChange('priceRange', {
                  ...localFilters.priceRange,
                  min: e.target.value
                })}
                className="flex-1"
              />
              <span className="text-text-quaternary">-</span>
              <Input
                type="number"
                placeholder="Max"
                value={localFilters.priceRange.max}
                onChange={(e) => handleFilterChange('priceRange', {
                  ...localFilters.priceRange,
                  max: e.target.value
                })}
                className="flex-1"
              />
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-border space-y-2">
          <Button
            variant="primary"
            onClick={handleApplyFilters}
            className="w-full"
          >
            Apply Filters
          </Button>
          <Button
            variant="ghost"
            onClick={handleResetFilters}
            className="w-full"
          >
            Reset All
          </Button>
        </div>
      </div>
    </>
  );
};

export default FilterPanel;