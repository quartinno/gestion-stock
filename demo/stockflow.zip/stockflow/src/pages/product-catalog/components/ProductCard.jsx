import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ProductCard = ({ product, onEdit, onDuplicate, onDelete, onViewDetails }) => {
  const getStockStatusColor = (stock, reorderPoint) => {
    if (stock === 0) return 'text-error';
    if (stock <= reorderPoint) return 'text-warning';
    return 'text-success';
  };

  const getStockStatusBg = (stock, reorderPoint) => {
    if (stock === 0) return 'bg-error-50';
    if (stock <= reorderPoint) return 'bg-warning-50';
    return 'bg-success-50';
  };

  const getStockStatusText = (stock, reorderPoint) => {
    if (stock === 0) return 'Out of Stock';
    if (stock <= reorderPoint) return 'Low Stock';
    return 'In Stock';
  };

  return (
    <div className="bg-surface border border-border rounded-lg p-4 hover:shadow-card transition-shadow duration-200">
      <div className="flex items-start space-x-4">
        <div className="w-16 h-16 rounded-lg overflow-hidden bg-secondary-100 flex-shrink-0">
          <Image
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-1 min-w-0">
          <button
            onClick={() => onViewDetails(product)}
            className="text-sm font-medium text-text-primary hover:text-primary transition-colors duration-200 text-left block w-full truncate"
          >
            {product.name}
          </button>
          <p className="text-xs text-text-secondary mt-1 line-clamp-2">
            {product.description}
          </p>
          
          <div className="flex items-center justify-between mt-3">
            <div className="flex flex-col space-y-1">
              <span className="text-xs text-text-tertiary">SKU: {product.sku}</span>
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary-100 text-text-secondary">
                {product.category}
              </span>
            </div>
            
            <div className="text-right">
              <div className="flex items-center space-x-2">
                <span className={`text-sm font-medium ${getStockStatusColor(product.currentStock, product.reorderPoint)}`}>
                  {product.currentStock}
                </span>
                <div className={`w-2 h-2 rounded-full ${getStockStatusBg(product.currentStock, product.reorderPoint)}`} />
              </div>
              <span className={`text-xs ${getStockStatusColor(product.currentStock, product.reorderPoint)}`}>
                {getStockStatusText(product.currentStock, product.reorderPoint)}
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
            <span className="text-xs text-text-tertiary">
              Updated: {product.lastUpdated}
            </span>
            
            <div className="flex items-center space-x-1">
              <Button
                variant="ghost"
                onClick={() => onEdit(product)}
                className="p-1"
                title="Edit Product"
              >
                <Icon name="Edit" size={14} />
              </Button>
              <Button
                variant="ghost"
                onClick={() => onDuplicate(product)}
                className="p-1"
                title="Duplicate Product"
              >
                <Icon name="Copy" size={14} />
              </Button>
              <Button
                variant="ghost"
                onClick={() => onDelete(product)}
                className="p-1 text-error hover:text-error"
                title="Delete Product"
              >
                <Icon name="Trash2" size={14} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;