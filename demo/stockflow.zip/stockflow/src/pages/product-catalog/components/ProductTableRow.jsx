import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ProductTableRow = ({ 
  product, 
  isSelected, 
  onSelect, 
  onEdit, 
  onDuplicate, 
  onDelete,
  onViewDetails 
}) => {
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [contextMenuPosition, setContextMenuPosition] = useState({ x: 0, y: 0 });

  const handleContextMenu = (e) => {
    e.preventDefault();
    setContextMenuPosition({ x: e.clientX, y: e.clientY });
    setShowContextMenu(true);
  };

  const handleContextMenuAction = (action) => {
    setShowContextMenu(false);
    switch (action) {
      case 'edit':
        onEdit(product);
        break;
      case 'duplicate':
        onDuplicate(product);
        break;
      case 'delete':
        onDelete(product);
        break;
      case 'view':
        onViewDetails(product);
        break;
    }
  };

  const getStockStatusColor = (stock, reorderPoint) => {
    if (stock === 0) return 'text-error';
    if (stock <= reorderPoint) return 'text-warning';
    return 'text-success';
  };

  const getStockStatusBg = (stock, reorderPoint) => {
    if (stock === 0) return 'bg-error-50';
    if (stock <= reorderPoint) return 'bg-warning-50';
    return 'bg-success-50';
  };

  return (
    <>
      <tr 
        className="hover:bg-secondary-50 transition-colors duration-200 border-b border-border"
        onContextMenu={handleContextMenu}
      >
        <td className="px-4 py-3">
          <input
            type="checkbox"
            checked={isSelected}
            onChange={(e) => onSelect(product.id, e.target.checked)}
            className="w-4 h-4 text-primary bg-surface border-border rounded focus:ring-primary focus:ring-2"
          />
        </td>
        
        <td className="px-4 py-3">
          <div className="w-12 h-12 rounded-lg overflow-hidden bg-secondary-100">
            <Image
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
        </td>
        
        <td className="px-4 py-3">
          <div className="flex flex-col">
            <button
              onClick={() => onViewDetails(product)}
              className="text-sm font-medium text-text-primary hover:text-primary transition-colors duration-200 text-left"
            >
              {product.name}
            </button>
            <span className="text-xs text-text-secondary mt-1">{product.description}</span>
          </div>
        </td>
        
        <td className="px-4 py-3">
          <span className="text-sm font-mono text-text-secondary">{product.sku}</span>
        </td>
        
        <td className="px-4 py-3">
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary-100 text-text-secondary">
            {product.category}
          </span>
        </td>
        
        <td className="px-4 py-3">
          <div className="flex items-center space-x-2">
            <span className={`text-sm font-medium ${getStockStatusColor(product.currentStock, product.reorderPoint)}`}>
              {product.currentStock}
            </span>
            <div className={`w-2 h-2 rounded-full ${getStockStatusBg(product.currentStock, product.reorderPoint)}`} />
          </div>
        </td>
        
        <td className="px-4 py-3">
          <span className="text-sm text-text-secondary">{product.reorderPoint}</span>
        </td>
        
        <td className="px-4 py-3">
          <span className="text-sm text-text-secondary">{product.lastUpdated}</span>
        </td>
        
        <td className="px-4 py-3">
          <div className="flex items-center space-x-1">
            <Button
              variant="ghost"
              onClick={() => onEdit(product)}
              className="p-1"
              title="Edit Product"
            >
              <Icon name="Edit" size={16} />
            </Button>
            <Button
              variant="ghost"
              onClick={() => onDuplicate(product)}
              className="p-1"
              title="Duplicate Product"
            >
              <Icon name="Copy" size={16} />
            </Button>
            <Button
              variant="ghost"
              onClick={() => onDelete(product)}
              className="p-1 text-error hover:text-error"
              title="Delete Product"
            >
              <Icon name="Trash2" size={16} />
            </Button>
          </div>
        </td>
      </tr>

      {/* Context Menu */}
      {showContextMenu && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setShowContextMenu(false)}
          />
          <div
            className="fixed z-50 bg-surface border border-border rounded-lg shadow-dropdown py-2 min-w-[160px]"
            style={{
              left: contextMenuPosition.x,
              top: contextMenuPosition.y,
            }}
          >
            <button
              onClick={() => handleContextMenuAction('view')}
              className="w-full px-4 py-2 text-left text-sm text-text-secondary hover:text-text-primary hover:bg-secondary-100 flex items-center"
            >
              <Icon name="Eye" size={16} className="mr-3" />
              View Details
            </button>
            <button
              onClick={() => handleContextMenuAction('edit')}
              className="w-full px-4 py-2 text-left text-sm text-text-secondary hover:text-text-primary hover:bg-secondary-100 flex items-center"
            >
              <Icon name="Edit" size={16} className="mr-3" />
              Edit Product
            </button>
            <button
              onClick={() => handleContextMenuAction('duplicate')}
              className="w-full px-4 py-2 text-left text-sm text-text-secondary hover:text-text-primary hover:bg-secondary-100 flex items-center"
            >
              <Icon name="Copy" size={16} className="mr-3" />
              Duplicate
            </button>
            <div className="border-t border-border my-1" />
            <button
              onClick={() => handleContextMenuAction('delete')}
              className="w-full px-4 py-2 text-left text-sm text-error hover:bg-error-50 flex items-center"
            >
              <Icon name="Trash2" size={16} className="mr-3" />
              Delete Product
            </button>
          </div>
        </>
      )}
    </>
  );
};

export default ProductTableRow;