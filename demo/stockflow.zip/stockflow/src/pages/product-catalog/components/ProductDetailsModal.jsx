import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ProductDetailsModal = ({ product, isOpen, onClose, onEdit }) => {
  if (!isOpen || !product) return null;

  const getStockStatusColor = (stock, reorderPoint) => {
    if (stock === 0) return 'text-error';
    if (stock <= reorderPoint) return 'text-warning';
    return 'text-success';
  };

  const getStockStatusBg = (stock, reorderPoint) => {
    if (stock === 0) return 'bg-error-50';
    if (stock <= reorderPoint) return 'bg-warning-50';
    return 'bg-success-50';
  };

  const getStockStatusText = (stock, reorderPoint) => {
    if (stock === 0) return 'Out of Stock';
    if (stock <= reorderPoint) return 'Low Stock';
    return 'In Stock';
  };

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-50"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-surface rounded-lg shadow-modal w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-border">
            <h2 className="text-xl font-semibold text-text-primary">Product Details</h2>
            <Button
              variant="ghost"
              onClick={onClose}
              className="p-1"
            >
              <Icon name="X" size={20} />
            </Button>
          </div>

          {/* Content */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Product Image */}
              <div className="space-y-4">
                <div className="w-full h-64 rounded-lg overflow-hidden bg-secondary-100">
                  <Image
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <div className={`px-3 py-1 rounded-full text-sm font-medium ${getStockStatusBg(product.currentStock, product.reorderPoint)} ${getStockStatusColor(product.currentStock, product.reorderPoint)}`}>
                    {getStockStatusText(product.currentStock, product.reorderPoint)}
                  </div>
                  <span className="text-sm text-text-secondary">
                    {product.currentStock} units available
                  </span>
                </div>
              </div>

              {/* Product Information */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-text-primary mb-2">
                    {product.name}
                  </h3>
                  <p className="text-text-secondary">
                    {product.description}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-text-secondary">SKU</label>
                    <p className="text-text-primary font-mono">{product.sku}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-text-secondary">Category</label>
                    <p className="text-text-primary">{product.category}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-text-secondary">Current Stock</label>
                    <p className={`text-lg font-semibold ${getStockStatusColor(product.currentStock, product.reorderPoint)}`}>
                      {product.currentStock}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-text-secondary">Reorder Point</label>
                    <p className="text-text-primary">{product.reorderPoint}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-text-secondary">Unit Price</label>
                    <p className="text-text-primary font-semibold">${product.unitPrice}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-text-secondary">Total Value</label>
                    <p className="text-text-primary font-semibold">
                      ${(product.currentStock * product.unitPrice).toFixed(2)}
                    </p>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-text-secondary">Supplier</label>
                  <p className="text-text-primary">{product.supplier}</p>
                </div>

                <div>
                  <label className="text-sm font-medium text-text-secondary">Last Updated</label>
                  <p className="text-text-primary">{product.lastUpdated}</p>
                </div>

                {product.notes && (
                  <div>
                    <label className="text-sm font-medium text-text-secondary">Notes</label>
                    <p className="text-text-primary">{product.notes}</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end space-x-3 p-6 border-t border-border">
            <Button
              variant="ghost"
              onClick={onClose}
            >
              Close
            </Button>
            <Button
              variant="primary"
              onClick={() => {
                onEdit(product);
                onClose();
              }}
              iconName="Edit"
              iconPosition="left"
            >
              Edit Product
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductDetailsModal;