import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const BulkActionsDropdown = ({ selectedCount, onBulkAction, disabled }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleAction = (action) => {
    onBulkAction(action);
    setIsOpen(false);
  };

  const bulkActions = [
    {
      id: 'export',
      label: 'Export Selected',
      icon: 'Download',
      color: 'text-text-secondary hover:text-text-primary'
    },
    {
      id: 'duplicate',
      label: 'Duplicate Selected',
      icon: 'Copy',
      color: 'text-text-secondary hover:text-text-primary'
    },
    {
      id: 'update-category',
      label: 'Update Category',
      icon: 'Tag',
      color: 'text-text-secondary hover:text-text-primary'
    },
    {
      id: 'update-supplier',
      label: 'Update Supplier',
      icon: 'Truck',
      color: 'text-text-secondary hover:text-text-primary'
    },
    {
      id: 'adjust-stock',
      label: 'Adjust Stock',
      icon: 'Package',
      color: 'text-text-secondary hover:text-text-primary'
    },
    {
      id: 'delete',
      label: 'Delete Selected',
      icon: 'Trash2',
      color: 'text-error hover:text-error',
      separator: true
    }
  ];

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        variant="outline"
        onClick={() => setIsOpen(!isOpen)}
        disabled={disabled || selectedCount === 0}
        iconName="ChevronDown"
        iconPosition="right"
      >
        Bulk Actions {selectedCount > 0 && `(${selectedCount})`}
      </Button>

      {isOpen && (
        <div className="absolute left-0 mt-2 w-56 bg-surface border border-border rounded-lg shadow-dropdown z-50">
          <div className="py-2">
            {bulkActions.map((action) => (
              <div key={action.id}>
                {action.separator && (
                  <div className="border-t border-border my-2" />
                )}
                <button
                  onClick={() => handleAction(action.id)}
                  className={`
                    w-full flex items-center px-4 py-2 text-sm transition-colors duration-200
                    ${action.color} hover:bg-secondary-100
                    ${action.id === 'delete' ? 'hover:bg-error-50' : ''}
                  `}
                >
                  <Icon name={action.icon} size={16} className="mr-3" />
                  {action.label}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default BulkActionsDropdown;