import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ActiveFilters = ({ filters, onRemoveFilter, onClearAll }) => {
  const getFilterChips = () => {
    const chips = [];

    // Category filters
    if (filters.categories && filters.categories.length > 0) {
      filters.categories.forEach(categoryId => {
        const categoryNames = {
          'electronics': 'Electronics',
          'clothing': 'Clothing',
          'books': 'Books',
          'home-garden': 'Home & Garden',
          'sports': 'Sports & Outdoors',
          'toys': 'Toys & Games'
        };
        
        chips.push({
          id: `category-${categoryId}`,
          label: categoryNames[categoryId] || categoryId,
          type: 'category',
          value: categoryId
        });
      });
    }

    // Supplier filters
    if (filters.suppliers && filters.suppliers.length > 0) {
      filters.suppliers.forEach(supplierId => {
        const supplierNames = {
          'supplier-1': 'TechCorp Solutions',
          'supplier-2': 'Fashion Forward Inc',
          'supplier-3': 'BookWorld Publishers',
          'supplier-4': 'HomeStyle Distributors',
          'supplier-5': 'SportMax Wholesale'
        };
        
        chips.push({
          id: `supplier-${supplierId}`,
          label: supplierNames[supplierId] || supplierId,
          type: 'supplier',
          value: supplierId
        });
      });
    }

    // Stock status filters
    if (filters.stockStatus && filters.stockStatus.length > 0) {
      filters.stockStatus.forEach(statusId => {
        const statusNames = {
          'in-stock': 'In Stock',
          'low-stock': 'Low Stock',
          'out-of-stock': 'Out of Stock'
        };
        
        chips.push({
          id: `status-${statusId}`,
          label: statusNames[statusId] || statusId,
          type: 'stockStatus',
          value: statusId
        });
      });
    }

    // Price range filter
    if (filters.priceRange && (filters.priceRange.min || filters.priceRange.max)) {
      const { min, max } = filters.priceRange;
      let label = 'Price: ';
      if (min && max) {
        label += `$${min} - $${max}`;
      } else if (min) {
        label += `≥ $${min}`;
      } else if (max) {
        label += `≤ $${max}`;
      }
      
      chips.push({
        id: 'price-range',
        label,
        type: 'priceRange',
        value: null
      });
    }

    return chips;
  };

  const handleRemoveFilter = (chip) => {
    onRemoveFilter(chip.type, chip.value);
  };

  const filterChips = getFilterChips();

  if (filterChips.length === 0) {
    return null;
  }

  return (
    <div className="flex items-center flex-wrap gap-2 mb-4">
      <span className="text-sm font-medium text-text-secondary">Active Filters:</span>
      
      {filterChips.map(chip => (
        <div
          key={chip.id}
          className="inline-flex items-center px-3 py-1 bg-primary-50 text-primary text-sm rounded-full"
        >
          <span>{chip.label}</span>
          <button
            onClick={() => handleRemoveFilter(chip)}
            className="ml-2 hover:text-primary-700 transition-colors duration-200"
          >
            <Icon name="X" size={14} />
          </button>
        </div>
      ))}
      
      <Button
        variant="ghost"
        onClick={onClearAll}
        className="text-sm text-text-secondary hover:text-text-primary"
      >
        Clear All
      </Button>
    </div>
  );
};

export default ActiveFilters;