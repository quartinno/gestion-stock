import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Sidebar from '../../components/ui/Sidebar';
import Header from '../../components/ui/Header';
import MobileNavigation from '../../components/ui/MobileNavigation';
import ProductTableRow from './components/ProductTableRow';
import ProductCard from './components/ProductCard';
import FilterPanel from './components/FilterPanel';
import ProductDetailsModal from './components/ProductDetailsModal';
import BulkActionsDropdown from './components/BulkActionsDropdown';
import ActiveFilters from './components/ActiveFilters';

const ProductCatalog = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('table'); // 'table' or 'grid'
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [sortConfig, setSortConfig] = useState({ key: 'name', direction: 'asc' });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(20);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [filters, setFilters] = useState({
    categories: [],
    suppliers: [],
    stockStatus: [],
    priceRange: { min: '', max: '' }
  });

  // Mock product data
  const mockProducts = [
    {
      id: 1,
      name: "MacBook Pro 16-inch",
      description: "Apple MacBook Pro with M2 Pro chip, 16GB RAM, 512GB SSD",
      sku: "MBP-16-M2-512",
      category: "Electronics",
      currentStock: 15,
      reorderPoint: 5,
      unitPrice: 2499.00,
      supplier: "TechCorp Solutions",
      lastUpdated: "2024-01-15",
      image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=300&fit=crop",
      notes: "High-performance laptop for professional use"
    },
    {
      id: 2,
      name: "iPhone 15 Pro",
      description: "Latest iPhone with A17 Pro chip, 128GB storage, Titanium design",
      sku: "IP15-PRO-128",
      category: "Electronics",
      currentStock: 3,
      reorderPoint: 10,
      unitPrice: 999.00,
      supplier: "TechCorp Solutions",
      lastUpdated: "2024-01-14",
      image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400&h=300&fit=crop",
      notes: "Premium smartphone with advanced camera system"
    },
    {
      id: 3,
      name: "Nike Air Max 270",
      description: "Comfortable running shoes with Air Max technology",
      sku: "NIKE-AM270-BLK",
      category: "Sports & Outdoors",
      currentStock: 0,
      reorderPoint: 15,
      unitPrice: 150.00,
      supplier: "SportMax Wholesale",
      lastUpdated: "2024-01-13",
      image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=300&fit=crop",
      notes: "Popular athletic footwear"
    },
    {
      id: 4,
      name: "Samsung 4K Smart TV",
      description: "55-inch QLED Smart TV with HDR support",
      sku: "SAM-TV55-QLED",
      category: "Electronics",
      currentStock: 8,
      reorderPoint: 3,
      unitPrice: 899.00,
      supplier: "TechCorp Solutions",
      lastUpdated: "2024-01-12",
      image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=300&fit=crop",
      notes: "Premium entertainment display"
    },
    {
      id: 5,
      name: "Levi\'s 501 Jeans",
      description: "Classic straight-fit denim jeans, size 32x34",
      sku: "LEVI-501-3234",
      category: "Clothing",
      currentStock: 25,
      reorderPoint: 10,
      unitPrice: 89.99,
      supplier: "Fashion Forward Inc",
      lastUpdated: "2024-01-11",
      image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=300&fit=crop",
      notes: "Timeless denim style"
    },
    {
      id: 6,
      name: "The Great Gatsby",
      description: "Classic American novel by F. Scott Fitzgerald",
      sku: "BOOK-GG-FSF",
      category: "Books",
      currentStock: 12,
      reorderPoint: 5,
      unitPrice: 14.99,
      supplier: "BookWorld Publishers",
      lastUpdated: "2024-01-10",
      image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=300&fit=crop",
      notes: "Literary classic"
    },
    {
      id: 7,
      name: "Coffee Maker Deluxe",
      description: "12-cup programmable coffee maker with thermal carafe",
      sku: "CM-DELUXE-12",
      category: "Home & Garden",
      currentStock: 6,
      reorderPoint: 8,
      unitPrice: 129.99,
      supplier: "HomeStyle Distributors",
      lastUpdated: "2024-01-09",
      image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400&h=300&fit=crop",
      notes: "Perfect for morning coffee routine"
    },
    {
      id: 8,
      name: "LEGO Creator Set",
      description: "3-in-1 building set with 500+ pieces",
      sku: "LEGO-CR-500",
      category: "Toys & Games",
      currentStock: 18,
      reorderPoint: 12,
      unitPrice: 49.99,
      supplier: "ToyWorld Distributors",
      lastUpdated: "2024-01-08",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop",
      notes: "Creative building experience"
    }
  ];

  // Filter and search products
  const getFilteredProducts = () => {
    let filtered = mockProducts;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply category filter
    if (filters.categories.length > 0) {
      filtered = filtered.filter(product => {
        const categoryMap = {
          'electronics': 'Electronics',
          'clothing': 'Clothing',
          'books': 'Books',
          'home-garden': 'Home & Garden',
          'sports': 'Sports & Outdoors',
          'toys': 'Toys & Games'
        };
        return filters.categories.some(catId => categoryMap[catId] === product.category);
      });
    }

    // Apply stock status filter
    if (filters.stockStatus.length > 0) {
      filtered = filtered.filter(product => {
        const status = product.currentStock === 0 ? 'out-of-stock' :
                     product.currentStock <= product.reorderPoint ? 'low-stock' : 'in-stock';
        return filters.stockStatus.includes(status);
      });
    }

    // Apply price range filter
    if (filters.priceRange.min || filters.priceRange.max) {
      filtered = filtered.filter(product => {
        const price = product.unitPrice;
        const min = filters.priceRange.min ? parseFloat(filters.priceRange.min) : 0;
        const max = filters.priceRange.max ? parseFloat(filters.priceRange.max) : Infinity;
        return price >= min && price <= max;
      });
    }

    return filtered;
  };

  // Sort products
  const getSortedProducts = (products) => {
    return [...products].sort((a, b) => {
      const aValue = a[sortConfig.key];
      const bValue = b[sortConfig.key];

      if (aValue < bValue) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
  };

  const filteredProducts = getFilteredProducts();
  const sortedProducts = getSortedProducts(filteredProducts);
  const totalPages = Math.ceil(sortedProducts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedProducts = sortedProducts.slice(startIndex, startIndex + itemsPerPage);

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleSelectProduct = (productId, isSelected) => {
    setSelectedProducts(prev => 
      isSelected 
        ? [...prev, productId]
        : prev.filter(id => id !== productId)
    );
  };

  const handleSelectAll = (isSelected) => {
    setSelectedProducts(isSelected ? paginatedProducts.map(p => p.id) : []);
  };

  const handleProductAction = (action, product) => {
    switch (action) {
      case 'edit': navigate('/add-edit-product', { state: { product } });
        break;
      case 'duplicate': navigate('/add-edit-product', { state: { product: { ...product, id: null, name: `${product.name} (Copy)` } } });
        break;
      case 'delete':
        if (window.confirm(`Are you sure you want to delete "${product.name}"?`)) {
          console.log('Delete product:', product.id);
        }
        break;
      case 'view':
        setSelectedProduct(product);
        setIsDetailsModalOpen(true);
        break;
    }
  };

  const handleBulkAction = (action) => {
    console.log('Bulk action:', action, 'Selected products:', selectedProducts);
    // Implement bulk actions here
  };

  const handleRemoveFilter = (type, value) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      
      if (type === 'priceRange') {
        newFilters.priceRange = { min: '', max: '' };
      } else if (value) {
        newFilters[type] = newFilters[type].filter(item => item !== value);
      }
      
      return newFilters;
    });
  };

  const handleClearAllFilters = () => {
    setFilters({
      categories: [],
      suppliers: [],
      stockStatus: [],
      priceRange: { min: '', max: '' }
    });
  };

  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return 'ArrowUpDown';
    return sortConfig.direction === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  const isAllSelected = paginatedProducts.length > 0 && selectedProducts.length === paginatedProducts.length;
  const isIndeterminate = selectedProducts.length > 0 && selectedProducts.length < paginatedProducts.length;

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Header />
      
      <main className="lg:ml-sidebar pt-header">
        <div className="p-4 lg:p-6">
          {/* Page Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-text-primary mb-2">Product Catalog</h1>
            <p className="text-text-secondary">Manage your product inventory and stock levels</p>
          </div>

          {/* Toolbar */}
          <div className="bg-surface border border-border rounded-lg p-4 mb-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
              <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
                {/* Search */}
                <div className="relative flex-1 sm:w-80">
                  <Icon 
                    name="Search" 
                    size={20} 
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-quaternary" 
                  />
                  <Input
                    type="search"
                    placeholder="Search products, SKU, or category..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>

                {/* Filter Button */}
                <Button
                  variant="outline"
                  onClick={() => setIsFilterPanelOpen(true)}
                  iconName="Filter"
                  iconPosition="left"
                  className="sm:w-auto"
                >
                  Filters
                </Button>
              </div>

              <div className="flex items-center space-x-3">
                {/* Bulk Actions */}
                <BulkActionsDropdown
                  selectedCount={selectedProducts.length}
                  onBulkAction={handleBulkAction}
                />

                {/* View Toggle */}
                <div className="hidden sm:flex items-center bg-secondary-100 rounded-lg p-1">
                  <Button
                    variant={viewMode === 'table' ? 'primary' : 'ghost'}
                    onClick={() => setViewMode('table')}
                    className="px-3 py-1"
                  >
                    <Icon name="Table" size={16} />
                  </Button>
                  <Button
                    variant={viewMode === 'grid' ? 'primary' : 'ghost'}
                    onClick={() => setViewMode('grid')}
                    className="px-3 py-1"
                  >
                    <Icon name="Grid3X3" size={16} />
                  </Button>
                </div>

                {/* Add Product Button */}
                <Button
                  variant="primary"
                  onClick={() => navigate('/add-edit-product')}
                  iconName="Plus"
                  iconPosition="left"
                >
                  <span className="hidden sm:inline">Add Product</span>
                  <span className="sm:hidden">Add</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Active Filters */}
          <ActiveFilters
            filters={filters}
            onRemoveFilter={handleRemoveFilter}
            onClearAll={handleClearAllFilters}
          />

          {/* Content Area */}
          <div className="relative">
            {/* Filter Panel */}
            <FilterPanel
              isOpen={isFilterPanelOpen}
              onClose={() => setIsFilterPanelOpen(false)}
              filters={filters}
              onFiltersChange={setFilters}
            />

            {/* Products Display */}
            <div className="bg-surface border border-border rounded-lg">
              {viewMode === 'table' ? (
                // Table View
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-secondary-50 border-b border-border">
                      <tr>
                        <th className="px-4 py-3 text-left">
                          <input
                            type="checkbox"
                            checked={isAllSelected}
                            ref={input => {
                              if (input) input.indeterminate = isIndeterminate;
                            }}
                            onChange={(e) => handleSelectAll(e.target.checked)}
                            className="w-4 h-4 text-primary bg-surface border-border rounded focus:ring-primary focus:ring-2"
                          />
                        </th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-text-secondary">Image</th>
                        <th className="px-4 py-3 text-left">
                          <button
                            onClick={() => handleSort('name')}
                            className="flex items-center space-x-1 text-sm font-medium text-text-secondary hover:text-text-primary"
                          >
                            <span>Product Name</span>
                            <Icon name={getSortIcon('name')} size={14} />
                          </button>
                        </th>
                        <th className="px-4 py-3 text-left">
                          <button
                            onClick={() => handleSort('sku')}
                            className="flex items-center space-x-1 text-sm font-medium text-text-secondary hover:text-text-primary"
                          >
                            <span>SKU</span>
                            <Icon name={getSortIcon('sku')} size={14} />
                          </button>
                        </th>
                        <th className="px-4 py-3 text-left">
                          <button
                            onClick={() => handleSort('category')}
                            className="flex items-center space-x-1 text-sm font-medium text-text-secondary hover:text-text-primary"
                          >
                            <span>Category</span>
                            <Icon name={getSortIcon('category')} size={14} />
                          </button>
                        </th>
                        <th className="px-4 py-3 text-left">
                          <button
                            onClick={() => handleSort('currentStock')}
                            className="flex items-center space-x-1 text-sm font-medium text-text-secondary hover:text-text-primary"
                          >
                            <span>Stock</span>
                            <Icon name={getSortIcon('currentStock')} size={14} />
                          </button>
                        </th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-text-secondary">Reorder Point</th>
                        <th className="px-4 py-3 text-left">
                          <button
                            onClick={() => handleSort('lastUpdated')}
                            className="flex items-center space-x-1 text-sm font-medium text-text-secondary hover:text-text-primary"
                          >
                            <span>Last Updated</span>
                            <Icon name={getSortIcon('lastUpdated')} size={14} />
                          </button>
                        </th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-text-secondary">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedProducts.map(product => (
                        <ProductTableRow
                          key={product.id}
                          product={product}
                          isSelected={selectedProducts.includes(product.id)}
                          onSelect={handleSelectProduct}
                          onEdit={(product) => handleProductAction('edit', product)}
                          onDuplicate={(product) => handleProductAction('duplicate', product)}
                          onDelete={(product) => handleProductAction('delete', product)}
                          onViewDetails={(product) => handleProductAction('view', product)}
                        />
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                // Grid View
                <div className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {paginatedProducts.map(product => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        onEdit={(product) => handleProductAction('edit', product)}
                        onDuplicate={(product) => handleProductAction('duplicate', product)}
                        onDelete={(product) => handleProductAction('delete', product)}
                        onViewDetails={(product) => handleProductAction('view', product)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Empty State */}
              {paginatedProducts.length === 0 && (
                <div className="text-center py-12">
                  <Icon name="Package" size={48} className="mx-auto text-text-quaternary mb-4" />
                  <h3 className="text-lg font-medium text-text-primary mb-2">No products found</h3>
                  <p className="text-text-secondary mb-4">
                    {searchTerm || Object.values(filters).some(f => Array.isArray(f) ? f.length > 0 : f.min || f.max)
                      ? "Try adjusting your search or filters" :"Get started by adding your first product"
                    }
                  </p>
                  <Button
                    variant="primary"
                    onClick={() => navigate('/add-edit-product')}
                    iconName="Plus"
                    iconPosition="left"
                  >
                    Add Product
                  </Button>
                </div>
              )}

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-3 border-t border-border">
                  <div className="text-sm text-text-secondary">
                    Showing {startIndex + 1} to {Math.min(startIndex + itemsPerPage, sortedProducts.length)} of {sortedProducts.length} products
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      iconName="ChevronLeft"
                    >
                      <span className="hidden sm:inline">Previous</span>
                    </Button>
                    
                    <div className="flex items-center space-x-1">
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        const page = i + 1;
                        return (
                          <Button
                            key={page}
                            variant={currentPage === page ? 'primary' : 'ghost'}
                            onClick={() => setCurrentPage(page)}
                            className="w-10 h-10"
                          >
                            {page}
                          </Button>
                        );
                      })}
                    </div>
                    
                    <Button
                      variant="outline"
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      iconName="ChevronRight"
                      iconPosition="right"
                    >
                      <span className="hidden sm:inline">Next</span>
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Product Details Modal */}
      <ProductDetailsModal
        product={selectedProduct}
        isOpen={isDetailsModalOpen}
        onClose={() => {
          setIsDetailsModalOpen(false);
          setSelectedProduct(null);
        }}
        onEdit={(product) => handleProductAction('edit', product)}
      />

      <MobileNavigation />
    </div>
  );
};

export default ProductCatalog;