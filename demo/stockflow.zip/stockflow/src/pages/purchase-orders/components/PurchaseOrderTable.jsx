import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import StatusBadge from './StatusBadge';

const PurchaseOrderTable = ({ purchaseOrders, onRowClick, onBulkAction }) => {
  const [selectedRows, setSelectedRows] = useState([]);
  const [expandedRows, setExpandedRows] = useState([]);
  const [contextMenu, setContextMenu] = useState({ show: false, x: 0, y: 0, poId: null });

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedRows(purchaseOrders.map(po => po.id));
    } else {
      setSelectedRows([]);
    }
  };

  const handleSelectRow = (poId, checked) => {
    if (checked) {
      setSelectedRows([...selectedRows, poId]);
    } else {
      setSelectedRows(selectedRows.filter(id => id !== poId));
    }
  };

  const handleExpandRow = (poId) => {
    if (expandedRows.includes(poId)) {
      setExpandedRows(expandedRows.filter(id => id !== poId));
    } else {
      setExpandedRows([...expandedRows, poId]);
    }
  };

  const handleContextMenu = (e, poId) => {
    e.preventDefault();
    setContextMenu({
      show: true,
      x: e.clientX,
      y: e.clientY,
      poId
    });
  };

  const handleCloseContextMenu = () => {
    setContextMenu({ show: false, x: 0, y: 0, poId: null });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const contextMenuActions = [
    { label: 'View Details', icon: 'Eye', action: 'view' },
    { label: 'Edit', icon: 'Edit', action: 'edit' },
    { label: 'Duplicate', icon: 'Copy', action: 'duplicate' },
    { label: 'Print', icon: 'Printer', action: 'print' },
    { label: 'Email to Supplier', icon: 'Mail', action: 'email' },
    { label: 'Cancel Order', icon: 'X', action: 'cancel', danger: true }
  ];

  React.useEffect(() => {
    const handleClickOutside = () => {
      if (contextMenu.show) {
        handleCloseContextMenu();
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [contextMenu.show]);

  return (
    <div className="bg-surface border border-border rounded-lg overflow-hidden">
      {/* Bulk Actions Bar */}
      {selectedRows.length > 0 && (
        <div className="bg-primary-50 border-b border-border px-6 py-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-primary">
              {selectedRows.length} purchase order{selectedRows.length > 1 ? 's' : ''} selected
            </span>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                onClick={() => onBulkAction('approve', selectedRows)}
                className="text-sm"
              >
                Approve Selected
              </Button>
              <Button
                variant="outline"
                onClick={() => onBulkAction('cancel', selectedRows)}
                className="text-sm"
              >
                Cancel Selected
              </Button>
              <Button
                variant="ghost"
                onClick={() => setSelectedRows([])}
                iconName="X"
                className="text-sm"
              >
                Clear
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Table */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-secondary-50 border-b border-border">
            <tr>
              <th className="w-12 px-6 py-4">
                <input
                  type="checkbox"
                  checked={selectedRows.length === purchaseOrders.length && purchaseOrders.length > 0}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary"
                />
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                PO Number
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Supplier
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Date Created
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Total Amount
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Expected Delivery
              </th>
              <th className="w-12 px-6 py-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {purchaseOrders.map((po) => (
              <React.Fragment key={po.id}>
                <tr
                  className="hover:bg-secondary-50 cursor-pointer"
                  onClick={() => onRowClick(po)}
                  onContextMenu={(e) => handleContextMenu(e, po.id)}
                >
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={selectedRows.includes(po.id)}
                      onChange={(e) => {
                        e.stopPropagation();
                        handleSelectRow(po.id, e.target.checked);
                      }}
                      className="rounded border-border text-primary focus:ring-primary"
                    />
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-sm font-medium text-text-primary">{po.poNumber}</span>
                      {po.isUrgent && (
                        <Icon name="AlertTriangle" size={16} className="ml-2 text-warning" />
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <div className="text-sm font-medium text-text-primary">{po.supplier.name}</div>
                      <div className="text-sm text-text-secondary">{po.supplier.contact}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-text-secondary">
                    {formatDate(po.dateCreated)}
                  </td>
                  <td className="px-6 py-4">
                    <StatusBadge status={po.status} />
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-text-primary">
                    {formatCurrency(po.totalAmount)}
                  </td>
                  <td className="px-6 py-4 text-sm text-text-secondary">
                    {po.expectedDelivery ? formatDate(po.expectedDelivery) : 'TBD'}
                  </td>
                  <td className="px-6 py-4">
                    <Button
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleExpandRow(po.id);
                      }}
                      iconName={expandedRows.includes(po.id) ? "ChevronUp" : "ChevronDown"}
                      className="text-text-secondary hover:text-text-primary"
                    />
                  </td>
                </tr>
                
                {/* Expanded Row - Line Items */}
                {expandedRows.includes(po.id) && (
                  <tr>
                    <td colSpan="8" className="px-6 py-4 bg-secondary-50">
                      <div className="space-y-3">
                        <h4 className="text-sm font-medium text-text-primary mb-3">Line Items</h4>
                        <div className="grid gap-3">
                          {po.lineItems.map((item, index) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-surface rounded-lg border border-border">
                              <div className="flex-1">
                                <div className="text-sm font-medium text-text-primary">{item.productName}</div>
                                <div className="text-sm text-text-secondary">SKU: {item.sku}</div>
                              </div>
                              <div className="text-right">
                                <div className="text-sm font-medium text-text-primary">
                                  Qty: {item.quantity} × {formatCurrency(item.unitPrice)}
                                </div>
                                <div className="text-sm text-text-secondary">
                                  Total: {formatCurrency(item.quantity * item.unitPrice)}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Card Layout */}
      <div className="lg:hidden divide-y divide-border">
        {purchaseOrders.map((po) => (
          <div key={po.id} className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={selectedRows.includes(po.id)}
                  onChange={(e) => handleSelectRow(po.id, e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary"
                />
                <div>
                  <div className="flex items-center">
                    <span className="text-sm font-medium text-text-primary">{po.poNumber}</span>
                    {po.isUrgent && (
                      <Icon name="AlertTriangle" size={14} className="ml-2 text-warning" />
                    )}
                  </div>
                  <div className="text-sm text-text-secondary">{po.supplier.name}</div>
                </div>
              </div>
              <StatusBadge status={po.status} size="sm" />
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-text-secondary">Created:</span>
                <span className="ml-2 text-text-primary">{formatDate(po.dateCreated)}</span>
              </div>
              <div>
                <span className="text-text-secondary">Total:</span>
                <span className="ml-2 font-medium text-text-primary">{formatCurrency(po.totalAmount)}</span>
              </div>
              <div className="col-span-2">
                <span className="text-text-secondary">Expected Delivery:</span>
                <span className="ml-2 text-text-primary">
                  {po.expectedDelivery ? formatDate(po.expectedDelivery) : 'TBD'}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
              <Button
                variant="ghost"
                onClick={() => handleExpandRow(po.id)}
                iconName={expandedRows.includes(po.id) ? "ChevronUp" : "ChevronDown"}
                iconPosition="right"
                className="text-sm"
              >
                {expandedRows.includes(po.id) ? 'Hide' : 'Show'} Items
              </Button>
              <Button
                variant="outline"
                onClick={() => onRowClick(po)}
                className="text-sm"
              >
                View Details
              </Button>
            </div>

            {/* Mobile Expanded Items */}
            {expandedRows.includes(po.id) && (
              <div className="mt-4 space-y-2">
                {po.lineItems.map((item, index) => (
                  <div key={index} className="p-3 bg-secondary-50 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-sm font-medium text-text-primary">{item.productName}</div>
                        <div className="text-xs text-text-secondary">SKU: {item.sku}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-text-primary">
                          {item.quantity} × {formatCurrency(item.unitPrice)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Context Menu */}
      {contextMenu.show && (
        <div
          className="fixed bg-surface border border-border rounded-lg shadow-dropdown z-50 py-2 min-w-48"
          style={{ left: contextMenu.x, top: contextMenu.y }}
        >
          {contextMenuActions.map((action, index) => (
            <button
              key={index}
              onClick={() => {
                console.log(`${action.action} action for PO:`, contextMenu.poId);
                handleCloseContextMenu();
              }}
              className={`
                w-full flex items-center px-4 py-2 text-sm transition-colors duration-200
                ${action.danger 
                  ? 'text-error hover:bg-error-50' :'text-text-secondary hover:text-text-primary hover:bg-secondary-100'
                }
              `}
            >
              <Icon name={action.icon} size={16} className="mr-3" />
              {action.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default PurchaseOrderTable;