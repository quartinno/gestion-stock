import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';

const FilterToolbar = ({ onFilterChange, onClearFilters }) => {
  const [filters, setFilters] = useState({
    supplier: '',
    dateFrom: '',
    dateTo: '',
    status: '',
    amountMin: '',
    amountMax: ''
  });
  const [isExpanded, setIsExpanded] = useState(false);

  const suppliers = [
    { id: 'all', name: 'All Suppliers' },
    { id: 'acme-corp', name: 'ACME Corporation' },
    { id: 'global-supply', name: 'Global Supply Co.' },
    { id: 'tech-solutions', name: 'Tech Solutions Ltd.' },
    { id: 'industrial-parts', name: 'Industrial Parts Inc.' }
  ];

  const statuses = [
    { value: '', label: 'All Status' },
    { value: 'draft', label: 'Draft' },
    { value: 'pending', label: 'Pending' },
    { value: 'approved', label: 'Approved' },
    { value: 'received', label: 'Received' },
    { value: 'cancelled', label: 'Cancelled' }
  ];

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const handleClearFilters = () => {
    const clearedFilters = {
      supplier: '',
      dateFrom: '',
      dateTo: '',
      status: '',
      amountMin: '',
      amountMax: ''
    };
    setFilters(clearedFilters);
    onClearFilters();
  };

  const hasActiveFilters = Object.values(filters).some(value => value !== '');

  return (
    <div className="bg-surface border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-4">
          <h3 className="text-sm font-medium text-text-primary">Filters</h3>
          {hasActiveFilters && (
            <span className="px-2 py-1 bg-primary-100 text-primary-700 text-xs rounded-full">
              {Object.values(filters).filter(value => value !== '').length} active
            </span>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {hasActiveFilters && (
            <Button
              variant="ghost"
              onClick={handleClearFilters}
              className="text-sm"
            >
              Clear All
            </Button>
          )}
          <Button
            variant="ghost"
            onClick={() => setIsExpanded(!isExpanded)}
            iconName={isExpanded ? "ChevronUp" : "ChevronDown"}
            iconPosition="right"
            className="text-sm"
          >
            {isExpanded ? 'Less Filters' : 'More Filters'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Supplier Filter */}
        <div>
          <label className="block text-sm font-medium text-text-secondary mb-2">
            Supplier
          </label>
          <select
            value={filters.supplier}
            onChange={(e) => handleFilterChange('supplier', e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            {suppliers.map(supplier => (
              <option key={supplier.id} value={supplier.id === 'all' ? '' : supplier.id}>
                {supplier.name}
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <label className="block text-sm font-medium text-text-secondary mb-2">
            Status
          </label>
          <select
            value={filters.status}
            onChange={(e) => handleFilterChange('status', e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            {statuses.map(status => (
              <option key={status.value} value={status.value}>
                {status.label}
              </option>
            ))}
          </select>
        </div>

        {/* Date From */}
        <div>
          <label className="block text-sm font-medium text-text-secondary mb-2">
            Date From
          </label>
          <Input
            type="date"
            value={filters.dateFrom}
            onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
            className="w-full"
          />
        </div>

        {/* Date To */}
        <div>
          <label className="block text-sm font-medium text-text-secondary mb-2">
            Date To
          </label>
          <Input
            type="date"
            value={filters.dateTo}
            onChange={(e) => handleFilterChange('dateTo', e.target.value)}
            className="w-full"
          />
        </div>
      </div>

      {isExpanded && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4 pt-4 border-t border-border">
          {/* Amount Min */}
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-2">
              Min Amount ($)
            </label>
            <Input
              type="number"
              placeholder="0.00"
              value={filters.amountMin}
              onChange={(e) => handleFilterChange('amountMin', e.target.value)}
              className="w-full"
            />
          </div>

          {/* Amount Max */}
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-2">
              Max Amount ($)
            </label>
            <Input
              type="number"
              placeholder="0.00"
              value={filters.amountMax}
              onChange={(e) => handleFilterChange('amountMax', e.target.value)}
              className="w-full"
            />
          </div>

          {/* Search */}
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-text-secondary mb-2">
              Search PO Number
            </label>
            <div className="relative">
              <Icon 
                name="Search" 
                size={16} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-quaternary" 
              />
              <Input
                type="text"
                placeholder="Search by PO number..."
                className="w-full pl-10"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterToolbar;