import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';

const CreatePurchaseOrderModal = ({ isOpen, onClose, onSubmit }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    supplier: '',
    expectedDelivery: '',
    notes: '',
    lineItems: [
      { productName: '', sku: '', quantity: 1, unitPrice: 0 }
    ]
  });

  const suppliers = [
    { id: 'acme-corp', name: 'ACME Corporation', contact: 'John Smith - john@acme.com' },
    { id: 'global-supply', name: 'Global Supply Co.', contact: 'Sarah Johnson - sarah@globalsupply.com' },
    { id: 'tech-solutions', name: 'Tech Solutions Ltd.', contact: 'Mike Davis - mike@techsolutions.com' },
    { id: 'industrial-parts', name: 'Industrial Parts Inc.', contact: 'Lisa Wilson - lisa@industrialparts.com' }
  ];

  const products = [
    { sku: 'PROD-001', name: 'Wireless Mouse', price: 25.99 },
    { sku: 'PROD-002', name: 'USB Cable', price: 12.50 },
    { sku: 'PROD-003', name: 'Keyboard', price: 89.99 },
    { sku: 'PROD-004', name: 'Monitor Stand', price: 45.00 },
    { sku: 'PROD-005', name: 'Desk Lamp', price: 35.75 }
  ];

  const steps = [
    { number: 1, title: 'Supplier Info', description: 'Select supplier and delivery details' },
    { number: 2, title: 'Line Items', description: 'Add products to purchase order' },
    { number: 3, title: 'Review', description: 'Review and submit purchase order' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleLineItemChange = (index, field, value) => {
    const updatedItems = [...formData.lineItems];
    updatedItems[index] = {
      ...updatedItems[index],
      [field]: value
    };
    setFormData(prev => ({
      ...prev,
      lineItems: updatedItems
    }));
  };

  const addLineItem = () => {
    setFormData(prev => ({
      ...prev,
      lineItems: [...prev.lineItems, { productName: '', sku: '', quantity: 1, unitPrice: 0 }]
    }));
  };

  const removeLineItem = (index) => {
    if (formData.lineItems.length > 1) {
      const updatedItems = formData.lineItems.filter((_, i) => i !== index);
      setFormData(prev => ({
        ...prev,
        lineItems: updatedItems
      }));
    }
  };

  const handleProductSelect = (index, productSku) => {
    const product = products.find(p => p.sku === productSku);
    if (product) {
      handleLineItemChange(index, 'productName', product.name);
      handleLineItemChange(index, 'sku', product.sku);
      handleLineItemChange(index, 'unitPrice', product.price);
    }
  };

  const calculateTotal = () => {
    return formData.lineItems.reduce((total, item) => {
      return total + (item.quantity * item.unitPrice);
    }, 0);
  };

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    const newPO = {
      id: `PO-${Date.now()}`,
      poNumber: `PO-${String(Date.now()).slice(-6)}`,
      supplier: suppliers.find(s => s.id === formData.supplier),
      dateCreated: new Date().toISOString(),
      status: 'draft',
      totalAmount: calculateTotal(),
      expectedDelivery: formData.expectedDelivery,
      lineItems: formData.lineItems.filter(item => item.productName && item.sku),
      notes: formData.notes,
      isUrgent: false
    };
    
    onSubmit(newPO);
    onClose();
    
    // Reset form
    setCurrentStep(1);
    setFormData({
      supplier: '',
      expectedDelivery: '',
      notes: '',
      lineItems: [{ productName: '', sku: '', quantity: 1, unitPrice: 0 }]
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-surface rounded-lg shadow-modal w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-xl font-semibold text-text-primary">Create Purchase Order</h2>
            <p className="text-sm text-text-secondary mt-1">
              Step {currentStep} of {steps.length}: {steps[currentStep - 1].description}
            </p>
          </div>
          <Button
            variant="ghost"
            onClick={onClose}
            iconName="X"
            className="text-text-secondary hover:text-text-primary"
          />
        </div>

        {/* Progress Steps */}
        <div className="px-6 py-4 border-b border-border">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center">
                <div className={`
                  flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium
                  ${currentStep >= step.number 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-secondary-200 text-text-secondary'
                  }
                `}>
                  {currentStep > step.number ? (
                    <Icon name="Check" size={16} />
                  ) : (
                    step.number
                  )}
                </div>
                <div className="ml-3">
                  <div className={`text-sm font-medium ${currentStep >= step.number ? 'text-text-primary' : 'text-text-secondary'}`}>
                    {step.title}
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-16 h-0.5 mx-4 ${currentStep > step.number ? 'bg-primary' : 'bg-secondary-200'}`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-96">
          {/* Step 1: Supplier Info */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">
                  Select Supplier *
                </label>
                <select
                  value={formData.supplier}
                  onChange={(e) => handleInputChange('supplier', e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  required
                >
                  <option value="">Choose a supplier...</option>
                  {suppliers.map(supplier => (
                    <option key={supplier.id} value={supplier.id}>
                      {supplier.name} - {supplier.contact}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">
                  Expected Delivery Date
                </label>
                <Input
                  type="date"
                  value={formData.expectedDelivery}
                  onChange={(e) => handleInputChange('expectedDelivery', e.target.value)}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">
                  Notes
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  placeholder="Add any special instructions or notes..."
                  rows={4}
                  className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                />
              </div>
            </div>
          )}

          {/* Step 2: Line Items */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-text-primary">Line Items</h3>
                <Button
                  variant="outline"
                  onClick={addLineItem}
                  iconName="Plus"
                  iconPosition="left"
                >
                  Add Item
                </Button>
              </div>

              <div className="space-y-4">
                {formData.lineItems.map((item, index) => (
                  <div key={index} className="p-4 border border-border rounded-lg">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-medium text-text-primary">Item {index + 1}</h4>
                      {formData.lineItems.length > 1 && (
                        <Button
                          variant="ghost"
                          onClick={() => removeLineItem(index)}
                          iconName="Trash2"
                          className="text-error hover:text-error hover:bg-error-50"
                        />
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-text-secondary mb-2">
                          Product
                        </label>
                        <select
                          value={item.sku}
                          onChange={(e) => handleProductSelect(index, e.target.value)}
                          className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        >
                          <option value="">Select product...</option>
                          {products.map(product => (
                            <option key={product.sku} value={product.sku}>
                              {product.name} ({product.sku})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-text-secondary mb-2">
                          Quantity
                        </label>
                        <Input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => handleLineItemChange(index, 'quantity', parseInt(e.target.value) || 1)}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-text-secondary mb-2">
                          Unit Price ($)
                        </label>
                        <Input
                          type="number"
                          step="0.01"
                          min="0"
                          value={item.unitPrice}
                          onChange={(e) => handleLineItemChange(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-text-secondary mb-2">
                          Total
                        </label>
                        <div className="px-3 py-2 bg-secondary-50 border border-border rounded-lg text-sm font-medium text-text-primary">
                          {formatCurrency(item.quantity * item.unitPrice)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end pt-4 border-t border-border">
                <div className="text-right">
                  <div className="text-sm text-text-secondary">Total Amount</div>
                  <div className="text-xl font-semibold text-text-primary">
                    {formatCurrency(calculateTotal())}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Review */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-text-primary">Review Purchase Order</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-text-secondary mb-2">Supplier Information</h4>
                    <div className="p-4 bg-secondary-50 rounded-lg">
                      {formData.supplier && (
                        <div>
                          <div className="font-medium text-text-primary">
                            {suppliers.find(s => s.id === formData.supplier)?.name}
                          </div>
                          <div className="text-sm text-text-secondary">
                            {suppliers.find(s => s.id === formData.supplier)?.contact}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-text-secondary mb-2">Delivery Information</h4>
                    <div className="p-4 bg-secondary-50 rounded-lg">
                      <div className="text-sm">
                        <span className="text-text-secondary">Expected Delivery:</span>
                        <span className="ml-2 text-text-primary">
                          {formData.expectedDelivery || 'Not specified'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-text-secondary mb-2">Order Summary</h4>
                  <div className="p-4 bg-secondary-50 rounded-lg">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">Items:</span>
                        <span className="text-text-primary">{formData.lineItems.length}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">Total Quantity:</span>
                        <span className="text-text-primary">
                          {formData.lineItems.reduce((sum, item) => sum + item.quantity, 0)}
                        </span>
                      </div>
                      <div className="border-t border-border pt-2 mt-2">
                        <div className="flex justify-between font-medium">
                          <span className="text-text-primary">Total Amount:</span>
                          <span className="text-text-primary">{formatCurrency(calculateTotal())}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-text-secondary mb-2">Line Items</h4>
                <div className="space-y-2">
                  {formData.lineItems.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-secondary-50 rounded-lg">
                      <div>
                        <div className="font-medium text-text-primary">{item.productName}</div>
                        <div className="text-sm text-text-secondary">SKU: {item.sku}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-text-primary">
                          {item.quantity} × {formatCurrency(item.unitPrice)}
                        </div>
                        <div className="text-sm text-text-secondary">
                          {formatCurrency(item.quantity * item.unitPrice)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {formData.notes && (
                <div>
                  <h4 className="text-sm font-medium text-text-secondary mb-2">Notes</h4>
                  <div className="p-4 bg-secondary-50 rounded-lg">
                    <p className="text-sm text-text-primary">{formData.notes}</p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-border">
          <div className="flex items-center space-x-3">
            {currentStep > 1 && (
              <Button
                variant="outline"
                onClick={handlePrevious}
                iconName="ChevronLeft"
                iconPosition="left"
              >
                Previous
              </Button>
            )}
          </div>

          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              onClick={onClose}
            >
              Cancel
            </Button>
            
            {currentStep < 3 ? (
              <Button
                variant="primary"
                onClick={handleNext}
                iconName="ChevronRight"
                iconPosition="right"
                disabled={currentStep === 1 && !formData.supplier}
              >
                Next
              </Button>
            ) : (
              <Button
                variant="primary"
                onClick={handleSubmit}
                iconName="Check"
                iconPosition="left"
                disabled={!formData.supplier || formData.lineItems.length === 0}
              >
                Create Purchase Order
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreatePurchaseOrderModal;