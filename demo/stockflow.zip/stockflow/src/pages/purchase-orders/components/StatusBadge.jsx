import React from 'react';

const StatusBadge = ({ status, size = 'md' }) => {
  const getStatusConfig = (status) => {
    const configs = {
      draft: {
        label: 'Draft',
        className: 'bg-secondary-100 text-secondary-700 border-secondary-200'
      },
      pending: {
        label: 'Pending',
        className: 'bg-warning-100 text-warning-700 border-warning-200'
      },
      approved: {
        label: 'Approved',
        className: 'bg-success-100 text-success-700 border-success-200'
      },
      received: {
        label: 'Received',
        className: 'bg-accent-100 text-accent-700 border-accent-200'
      },
      cancelled: {
        label: 'Cancelled',
        className: 'bg-error-100 text-error-700 border-error-200'
      }
    };
    return configs[status?.toLowerCase()] || configs.draft;
  };

  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-1 text-sm',
    lg: 'px-4 py-2 text-base'
  };

  const config = getStatusConfig(status);

  return (
    <span className={`
      inline-flex items-center font-medium rounded-full border
      ${config.className}
      ${sizeClasses[size]}
    `}>
      {config.label}
    </span>
  );
};

export default StatusBadge;