import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Sidebar from '../../components/ui/Sidebar';
import Header from '../../components/ui/Header';
import MobileNavigation from '../../components/ui/MobileNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import StatusBadge from './components/StatusBadge';
import FilterToolbar from './components/FilterToolbar';
import PurchaseOrderTable from './components/PurchaseOrderTable';
import CreatePurchaseOrderModal from './components/CreatePurchaseOrderModal';

const PurchaseOrders = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [filters, setFilters] = useState({});

  // Mock data for purchase orders
  const mockPurchaseOrders = [
    {
      id: 'po-001',
      poNumber: 'PO-001234',
      supplier: {
        name: 'ACME Corporation',
        contact: 'John Smith - john@acme.com'
      },
      dateCreated: '2024-01-15T10:30:00Z',
      status: 'pending',
      totalAmount: 2450.75,
      expectedDelivery: '2024-01-25T00:00:00Z',
      isUrgent: true,
      lineItems: [
        {
          productName: 'Wireless Mouse',
          sku: 'PROD-001',
          quantity: 25,
          unitPrice: 25.99
        },
        {
          productName: 'USB Cable',
          sku: 'PROD-002',
          quantity: 50,
          unitPrice: 12.50
        },
        {
          productName: 'Keyboard',
          sku: 'PROD-003',
          quantity: 15,
          unitPrice: 89.99
        }
      ]
    },
    {
      id: 'po-002',
      poNumber: 'PO-001235',
      supplier: {
        name: 'Global Supply Co.',
        contact: 'Sarah Johnson - sarah@globalsupply.com'
      },
      dateCreated: '2024-01-14T14:20:00Z',
      status: 'approved',
      totalAmount: 1875.50,
      expectedDelivery: '2024-01-22T00:00:00Z',
      isUrgent: false,
      lineItems: [
        {
          productName: 'Monitor Stand',
          sku: 'PROD-004',
          quantity: 30,
          unitPrice: 45.00
        },
        {
          productName: 'Desk Lamp',
          sku: 'PROD-005',
          quantity: 25,
          unitPrice: 35.75
        }
      ]
    },
    {
      id: 'po-003',
      poNumber: 'PO-001236',
      supplier: {
        name: 'Tech Solutions Ltd.',
        contact: 'Mike Davis - mike@techsolutions.com'
      },
      dateCreated: '2024-01-13T09:15:00Z',
      status: 'received',
      totalAmount: 3200.00,
      expectedDelivery: '2024-01-20T00:00:00Z',
      isUrgent: false,
      lineItems: [
        {
          productName: 'Laptop Stand',
          sku: 'PROD-006',
          quantity: 20,
          unitPrice: 75.00
        },
        {
          productName: 'Webcam',
          sku: 'PROD-007',
          quantity: 40,
          unitPrice: 55.00
        }
      ]
    },
    {
      id: 'po-004',
      poNumber: 'PO-001237',
      supplier: {
        name: 'Industrial Parts Inc.',
        contact: 'Lisa Wilson - lisa@industrialparts.com'
      },
      dateCreated: '2024-01-12T16:45:00Z',
      status: 'draft',
      totalAmount: 950.25,
      expectedDelivery: null,
      isUrgent: false,
      lineItems: [
        {
          productName: 'Cable Organizer',
          sku: 'PROD-008',
          quantity: 35,
          unitPrice: 18.50
        },
        {
          productName: 'Power Strip',
          sku: 'PROD-009',
          quantity: 15,
          unitPrice: 28.75
        }
      ]
    },
    {
      id: 'po-005',
      poNumber: 'PO-001238',
      supplier: {
        name: 'ACME Corporation',
        contact: 'John Smith - john@acme.com'
      },
      dateCreated: '2024-01-11T11:30:00Z',
      status: 'cancelled',
      totalAmount: 1200.00,
      expectedDelivery: '2024-01-18T00:00:00Z',
      isUrgent: false,
      lineItems: [
        {
          productName: 'Headphones',
          sku: 'PROD-010',
          quantity: 20,
          unitPrice: 60.00
        }
      ]
    }
  ];

  const tabs = [
    { id: 'all', label: 'All Orders', count: mockPurchaseOrders.length },
    { id: 'draft', label: 'Draft', count: mockPurchaseOrders.filter(po => po.status === 'draft').length },
    { id: 'pending', label: 'Pending', count: mockPurchaseOrders.filter(po => po.status === 'pending').length },
    { id: 'approved', label: 'Approved', count: mockPurchaseOrders.filter(po => po.status === 'approved').length },
    { id: 'received', label: 'Received', count: mockPurchaseOrders.filter(po => po.status === 'received').length }
  ];

  useEffect(() => {
    setPurchaseOrders(mockPurchaseOrders);
    setFilteredOrders(mockPurchaseOrders);
  }, []);

  useEffect(() => {
    let filtered = [...purchaseOrders];

    // Filter by active tab
    if (activeTab !== 'all') {
      filtered = filtered.filter(po => po.status === activeTab);
    }

    // Apply additional filters
    if (filters.supplier) {
      filtered = filtered.filter(po => po.supplier.name.toLowerCase().includes(filters.supplier.toLowerCase()));
    }

    if (filters.status) {
      filtered = filtered.filter(po => po.status === filters.status);
    }

    if (filters.dateFrom) {
      filtered = filtered.filter(po => new Date(po.dateCreated) >= new Date(filters.dateFrom));
    }

    if (filters.dateTo) {
      filtered = filtered.filter(po => new Date(po.dateCreated) <= new Date(filters.dateTo));
    }

    if (filters.amountMin) {
      filtered = filtered.filter(po => po.totalAmount >= parseFloat(filters.amountMin));
    }

    if (filters.amountMax) {
      filtered = filtered.filter(po => po.totalAmount <= parseFloat(filters.amountMax));
    }

    setFilteredOrders(filtered);
  }, [activeTab, purchaseOrders, filters]);

  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
  };

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleClearFilters = () => {
    setFilters({});
  };

  const handleCreatePurchaseOrder = (newPO) => {
    setPurchaseOrders(prev => [newPO, ...prev]);
  };

  const handleRowClick = (purchaseOrder) => {
    console.log('View purchase order details:', purchaseOrder);
  };

  const handleBulkAction = (action, selectedIds) => {
    console.log(`Bulk ${action} action for orders:`, selectedIds);
    
    if (action === 'approve') {
      setPurchaseOrders(prev => 
        prev.map(po => 
          selectedIds.includes(po.id) 
            ? { ...po, status: 'approved' }
            : po
        )
      );
    } else if (action === 'cancel') {
      setPurchaseOrders(prev => 
        prev.map(po => 
          selectedIds.includes(po.id) 
            ? { ...po, status: 'cancelled' }
            : po
        )
      );
    }
  };

  const getStatusCounts = () => {
    const counts = {
      total: purchaseOrders.length,
      pending: purchaseOrders.filter(po => po.status === 'pending').length,
      approved: purchaseOrders.filter(po => po.status === 'approved').length,
      urgent: purchaseOrders.filter(po => po.isUrgent).length
    };
    return counts;
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const getTotalValue = () => {
    return filteredOrders.reduce((sum, po) => sum + po.totalAmount, 0);
  };

  const statusCounts = getStatusCounts();

  return (
    <>
      <Helmet>
        <title>Purchase Orders - StockFlow</title>
        <meta name="description" content="Manage supplier procurement workflow from creation to fulfillment tracking with comprehensive purchase order management." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Sidebar />
        <Header />
        
        <main className="lg:ml-sidebar xl:ml-sidebar pt-header pb-20 lg:pb-8">
          <div className="px-4 lg:px-8 py-6">
            {/* Page Header */}
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
              <div className="mb-4 lg:mb-0">
                <h1 className="text-2xl lg:text-3xl font-bold text-text-primary font-heading">
                  Purchase Orders
                </h1>
                <p className="text-text-secondary mt-2">
                  Manage supplier procurement workflow from creation to fulfillment tracking
                </p>
              </div>
              
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  iconName="Download"
                  iconPosition="left"
                  className="hidden sm:flex"
                >
                  Export
                </Button>
                <Button
                  variant="primary"
                  onClick={() => setIsCreateModalOpen(true)}
                  iconName="Plus"
                  iconPosition="left"
                >
                  Create Purchase Order
                </Button>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <div className="bg-surface border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-text-secondary">Total Orders</p>
                    <p className="text-2xl font-semibold text-text-primary">{statusCounts.total}</p>
                  </div>
                  <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                    <Icon name="ShoppingCart" size={20} className="text-primary" />
                  </div>
                </div>
              </div>

              <div className="bg-surface border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-text-secondary">Pending</p>
                    <p className="text-2xl font-semibold text-text-primary">{statusCounts.pending}</p>
                  </div>
                  <div className="w-10 h-10 bg-warning-100 rounded-lg flex items-center justify-center">
                    <Icon name="Clock" size={20} className="text-warning" />
                  </div>
                </div>
              </div>

              <div className="bg-surface border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-text-secondary">Approved</p>
                    <p className="text-2xl font-semibold text-text-primary">{statusCounts.approved}</p>
                  </div>
                  <div className="w-10 h-10 bg-success-100 rounded-lg flex items-center justify-center">
                    <Icon name="CheckCircle" size={20} className="text-success" />
                  </div>
                </div>
              </div>

              <div className="bg-surface border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-text-secondary">Total Value</p>
                    <p className="text-2xl font-semibold text-text-primary">{formatCurrency(getTotalValue())}</p>
                  </div>
                  <div className="w-10 h-10 bg-accent-100 rounded-lg flex items-center justify-center">
                    <Icon name="DollarSign" size={20} className="text-accent" />
                  </div>
                </div>
              </div>
            </div>

            {/* Status Tabs */}
            <div className="bg-surface border border-border rounded-lg mb-6">
              <div className="border-b border-border">
                <nav className="flex space-x-8 px-6" aria-label="Purchase Order Status Tabs">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => handleTabChange(tab.id)}
                      className={`
                        py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200
                        ${activeTab === tab.id
                          ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-secondary-300'
                        }
                      `}
                    >
                      {tab.label}
                      {tab.count > 0 && (
                        <span className={`
                          ml-2 px-2 py-1 text-xs rounded-full
                          ${activeTab === tab.id
                            ? 'bg-primary-100 text-primary-700' :'bg-secondary-100 text-secondary-700'
                          }
                        `}>
                          {tab.count}
                        </span>
                      )}
                    </button>
                  ))}
                </nav>
              </div>

              {/* Tab Content Summary */}
              <div className="px-6 py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <span className="text-sm text-text-secondary">
                      Showing {filteredOrders.length} of {purchaseOrders.length} purchase orders
                    </span>
                    {activeTab !== 'all' && (
                      <StatusBadge status={activeTab} size="sm" />
                    )}
                  </div>
                  <div className="text-sm text-text-secondary">
                    Total Value: <span className="font-medium text-text-primary">{formatCurrency(getTotalValue())}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Filter Toolbar */}
            <FilterToolbar
              onFilterChange={handleFilterChange}
              onClearFilters={handleClearFilters}
            />

            {/* Purchase Orders Table */}
            <PurchaseOrderTable
              purchaseOrders={filteredOrders}
              onRowClick={handleRowClick}
              onBulkAction={handleBulkAction}
            />

            {/* Empty State */}
            {filteredOrders.length === 0 && (
              <div className="bg-surface border border-border rounded-lg p-12 text-center">
                <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name="ShoppingCart" size={32} className="text-secondary-400" />
                </div>
                <h3 className="text-lg font-medium text-text-primary mb-2">
                  {activeTab === 'all' ? 'No purchase orders found' : `No ${activeTab} purchase orders`}
                </h3>
                <p className="text-text-secondary mb-6">
                  {activeTab === 'all' ?'Get started by creating your first purchase order.'
                    : `There are no purchase orders with ${activeTab} status matching your current filters.`
                  }
                </p>
                {activeTab === 'all' && (
                  <Button
                    variant="primary"
                    onClick={() => setIsCreateModalOpen(true)}
                    iconName="Plus"
                    iconPosition="left"
                  >
                    Create Purchase Order
                  </Button>
                )}
              </div>
            )}
          </div>
        </main>

        <MobileNavigation />

        {/* Create Purchase Order Modal */}
        <CreatePurchaseOrderModal
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
          onSubmit={handleCreatePurchaseOrder}
        />
      </div>
    </>
  );
};

export default PurchaseOrders;