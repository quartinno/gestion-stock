import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';
import { format, subDays } from 'date-fns';

const ClientCreditReport = ({ onExport, isLoading, setIsLoading }) => {
  const [clientData, setClientData] = useState([]);
  const [filterType, setFilterType] = useState('all');
  const [summaryData, setSummaryData] = useState({});

  useEffect(() => {
    generateClientData();
  }, [filterType]);

  const generateClientData = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const today = new Date();
    const mockData = [
      {
        clientName: 'Acme Corporation',
        creditLimit: 50000,
        currentBalance: 15000,
        availableCredit: 35000,
        overdueAmount: 0,
        lastPayment: format(subDays(today, 5), 'yyyy-MM-dd'),
        status: 'Good Standing'
      },
      {
        clientName: 'Global Tech Solutions',
        creditLimit: 75000,
        currentBalance: 45000,
        availableCredit: 30000,
        overdueAmount: 8000,
        lastPayment: format(subDays(today, 35), 'yyyy-MM-dd'),
        status: 'Overdue'
      },
      {
        clientName: 'Sunrise Industries',
        creditLimit: 30000,
        currentBalance: 28000,
        availableCredit: 2000,
        overdueAmount: 0,
        lastPayment: format(subDays(today, 3), 'yyyy-MM-dd'),
        status: 'Near Limit'
      },
      {
        clientName: 'Metro Retail Chain',
        creditLimit: 100000,
        currentBalance: 25000,
        availableCredit: 75000,
        overdueAmount: 0,
        lastPayment: format(subDays(today, 10), 'yyyy-MM-dd'),
        status: 'Good Standing'
      },
      {
        clientName: 'Pacific Logistics',
        creditLimit: 40000,
        currentBalance: 35000,
        availableCredit: 5000,
        overdueAmount: 12000,
        lastPayment: format(subDays(today, 45), 'yyyy-MM-dd'),
        status: 'Overdue'
      },
      {
        clientName: 'Northern Manufacturing',
        creditLimit: 60000,
        currentBalance: 20000,
        availableCredit: 40000,
        overdueAmount: 0,
        lastPayment: format(subDays(today, 7), 'yyyy-MM-dd'),
        status: 'Good Standing'
      },
      {
        clientName: 'Eastern Distributors',
        creditLimit: 25000,
        currentBalance: 23000,
        availableCredit: 2000,
        overdueAmount: 0,
        lastPayment: format(subDays(today, 12), 'yyyy-MM-dd'),
        status: 'Near Limit'
      },
      {
        clientName: 'South Coast Enterprises',
        creditLimit: 80000,
        currentBalance: 55000,
        availableCredit: 25000,
        overdueAmount: 15000,
        lastPayment: format(subDays(today, 60), 'yyyy-MM-dd'),
        status: 'Overdue'
      }
    ];

    const filteredData = filterType === 'all' 
      ? mockData 
      : mockData.filter(client => {
          switch (filterType) {
            case 'good':
              return client.status === 'Good Standing';
            case 'overdue':
              return client.status === 'Overdue';
            case 'near-limit':
              return client.status === 'Near Limit';
            default:
              return true;
          }
        });

    setClientData(filteredData);
    
    // Calculate summary
    const goodStanding = mockData.filter(client => client.status === 'Good Standing');
    const overdue = mockData.filter(client => client.status === 'Overdue');
    const nearLimit = mockData.filter(client => client.status === 'Near Limit');
    
    const summary = {
      totalClients: mockData.length,
      goodStanding: goodStanding.length,
      overdue: overdue.length,
      nearLimit: nearLimit.length,
      totalCreditLimit: mockData.reduce((sum, client) => sum + client.creditLimit, 0),
      totalOutstanding: mockData.reduce((sum, client) => sum + client.currentBalance, 0),
      totalOverdue: mockData.reduce((sum, client) => sum + client.overdueAmount, 0),
      totalAvailableCredit: mockData.reduce((sum, client) => sum + client.availableCredit, 0)
    };

    setSummaryData(summary);
    setIsLoading(false);
  };

  const chartData = clientData.map(client => ({
    name: client.clientName.split(' ')[0], // Use first word for chart readability
    creditLimit: client.creditLimit,
    currentBalance: client.currentBalance,
    availableCredit: client.availableCredit,
    overdueAmount: client.overdueAmount
  }));

  const statusData = [
    { name: 'Good Standing', value: summaryData.goodStanding, color: '#059669' },
    { name: 'Overdue', value: summaryData.overdue, color: '#DC2626' },
    { name: 'Near Limit', value: summaryData.nearLimit, color: '#D97706' }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Good Standing':
        return 'text-success bg-success-50';
      case 'Overdue':
        return 'text-error bg-error-50';
      case 'Near Limit':
        return 'text-warning bg-warning-50';
      default:
        return 'text-text-secondary bg-secondary-50';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Good Standing':
        return 'CheckCircle';
      case 'Overdue':
        return 'AlertCircle';
      case 'Near Limit':
        return 'AlertTriangle';
      default:
        return 'Info';
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(value);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-text-secondary">Loading client credit report...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Total Clients</p>
              <p className="text-2xl font-bold text-text-primary">{summaryData.totalClients}</p>
            </div>
            <div className="w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center">
              <Icon name="Users" size={24} className="text-primary" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Total Outstanding</p>
              <p className="text-2xl font-bold text-text-primary">{formatCurrency(summaryData.totalOutstanding)}</p>
            </div>
            <div className="w-12 h-12 bg-accent-50 rounded-lg flex items-center justify-center">
              <Icon name="DollarSign" size={24} className="text-accent" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Overdue Payments</p>
              <p className="text-2xl font-bold text-error">{formatCurrency(summaryData.totalOverdue)}</p>
            </div>
            <div className="w-12 h-12 bg-error-50 rounded-lg flex items-center justify-center">
              <Icon name="AlertCircle" size={24} className="text-error" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Available Credit</p>
              <p className="text-2xl font-bold text-success">{formatCurrency(summaryData.totalAvailableCredit)}</p>
            </div>
            <div className="w-12 h-12 bg-success-50 rounded-lg flex items-center justify-center">
              <Icon name="CreditCard" size={24} className="text-success" />
            </div>
          </div>
        </div>
      </div>

      {/* Filter Controls */}
      <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">Client Credit Analysis</h3>
          <div className="flex items-center space-x-2">
            <label className="text-sm text-text-secondary">Filter by Status:</label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="all">All Clients</option>
              <option value="good">Good Standing</option>
              <option value="overdue">Overdue</option>
              <option value="near-limit">Near Limit</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Bar Chart */}
          <div>
            <h4 className="text-md font-medium text-text-primary mb-4">Credit Utilization</h4>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip formatter={(value) => formatCurrency(value)} />
                <Bar dataKey="creditLimit" fill="#CBD5E1" name="Credit Limit" />
                <Bar dataKey="currentBalance" fill="#3B82F6" name="Current Balance" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Pie Chart */}
          <div>
            <h4 className="text-md font-medium text-text-primary mb-4">Client Status Distribution</h4>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Client Credit Table */}
      <div className="bg-surface border border-border rounded-lg shadow-card">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-text-primary">Detailed Client Credit Report</h3>
            <button
              onClick={() => onExport('client-credit', clientData)}
              className="flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-700 transition-colors"
            >
              <Icon name="Download" size={16} />
              <span>Export</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary-50">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Client Name</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Credit Limit</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Current Balance</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Available Credit</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Overdue Amount</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Last Payment</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Status</th>
              </tr>
            </thead>
            <tbody>
              {clientData.map((client, index) => (
                <tr key={index} className="border-b border-border hover:bg-secondary-50">
                  <td className="p-4 text-sm text-text-primary font-medium">{client.clientName}</td>
                  <td className="p-4 text-sm text-text-primary">{formatCurrency(client.creditLimit)}</td>
                  <td className="p-4 text-sm text-text-primary">{formatCurrency(client.currentBalance)}</td>
                  <td className="p-4 text-sm text-text-primary">{formatCurrency(client.availableCredit)}</td>
                  <td className="p-4 text-sm text-text-primary">
                    {client.overdueAmount > 0 ? (
                      <span className="text-error font-medium">{formatCurrency(client.overdueAmount)}</span>
                    ) : (
                      <span className="text-text-secondary">-</span>
                    )}
                  </td>
                  <td className="p-4 text-sm text-text-primary">{format(new Date(client.lastPayment), 'MMM dd, yyyy')}</td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Icon name={getStatusIcon(client.status)} size={16} className={
                        client.status === 'Good Standing' ? 'text-success' : 
                        client.status === 'Overdue' ? 'text-error' : 'text-warning'
                      } />
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(client.status)}`}>
                        {client.status}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ClientCreditReport;