import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const ExportModal = ({ isOpen, onClose, reportData }) => {
  const [exportFormat, setExportFormat] = useState('csv');
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      // Simulate export process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const reportType = reportData?.type || 'general';
      const timestamp = new Date().toISOString().split('T')[0];
      const filename = `${reportType}-report-${timestamp}.${exportFormat}`;
      
      if (exportFormat === 'csv') {
        exportToCSV(reportData, filename);
      } else {
        exportToPDF(reportData, filename);
      }
      
      onClose();
    } catch (error) {
      console.error('Export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const exportToCSV = (data, filename) => {
    if (!data?.data) return;
    
    let csvContent = '';
    
    // Generate CSV based on report type
    switch (data.type) {
      case 'stock-levels':
        csvContent = generateStockLevelsCSV(data.data);
        break;
      case 'expiration':
        csvContent = generateExpirationCSV(data.data);
        break;
      case 'sales-performance':
        csvContent = generateSalesPerformanceCSV(data.data);
        break;
      case 'client-credit':
        csvContent = generateClientCreditCSV(data.data);
        break;
      case 'subscription':
        csvContent = generateSubscriptionCSV(data.data);
        break;
      default:
        csvContent = 'No data available';
    }
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    downloadFile(blob, filename);
  };

  const exportToPDF = (data, filename) => {
    // This would typically use a library like jsPDF
    // For now, we'll simulate the PDF export
    const pdfContent = `PDF Report: ${data.type}\nGenerated on: ${new Date().toLocaleString()}\n\nData would be formatted here...`;
    const blob = new Blob([pdfContent], { type: 'application/pdf' });
    downloadFile(blob, filename);
  };

  const generateStockLevelsCSV = (data) => {
    const headers = ['Product', 'Category', 'Current Stock', 'Low Stock Threshold', 'Status'];
    const rows = data.map(item => [
      item.product,
      item.category,
      item.current,
      item.lowStock,
      item.status
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const generateExpirationCSV = (data) => {
    const headers = ['Product', 'Category', 'Expiration Date', 'Quantity', 'Value', 'Status'];
    const rows = data.map(item => [
      item.product,
      item.category,
      item.expirationDate,
      item.quantity,
      item.value,
      item.status
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const generateSalesPerformanceCSV = (data) => {
    const headers = ['Date', 'Sales', 'Orders', 'Avg Order Value'];
    const rows = data.salesData?.map(item => [
      item.date,
      item.sales,
      item.orders,
      item.avgOrderValue
    ]) || [];
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const generateClientCreditCSV = (data) => {
    const headers = ['Client Name', 'Credit Limit', 'Current Balance', 'Available Credit', 'Overdue Amount', 'Status'];
    const rows = data.map(item => [
      item.clientName,
      item.creditLimit,
      item.currentBalance,
      item.availableCredit,
      item.overdueAmount,
      item.status
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const generateSubscriptionCSV = (data) => {
    const headers = ['Subscription ID', 'Client', 'Plan', 'Monthly Fee', 'Start Date', 'Status', 'Total Paid'];
    const rows = data.subscriptionData?.map(item => [
      item.id,
      item.clientName,
      item.plan,
      item.monthlyFee,
      item.startDate,
      item.status,
      item.totalPaid
    ]) || [];
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const downloadFile = (blob, filename) => {
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const getReportTitle = () => {
    switch (reportData?.type) {
      case 'stock-levels':
        return 'Stock Level Report';
      case 'expiration':
        return 'Expiration Report';
      case 'sales-performance':
        return 'Sales Performance Report';
      case 'client-credit':
        return 'Client Credit Report';
      case 'subscription':
        return 'Subscription Report';
      default:
        return 'Inventory Report';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-modal flex items-center justify-center p-4">
      <div className="bg-surface rounded-lg shadow-modal w-full max-w-md">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-text-primary">Export Report</h3>
            <button
              onClick={onClose}
              className="text-text-secondary hover:text-text-primary transition-colors"
            >
              <Icon name="X" size={20} />
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <h4 className="text-md font-medium text-text-primary mb-2">{getReportTitle()}</h4>
            <p className="text-sm text-text-secondary">
              Choose your preferred export format and download the report data.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Export Format
              </label>
              <div className="space-y-2">
                <label className="flex items-center space-x-3">
                  <input
                    type="radio"
                    value="csv"
                    checked={exportFormat === 'csv'}
                    onChange={(e) => setExportFormat(e.target.value)}
                    className="w-4 h-4 text-primary focus:ring-primary border-border"
                  />
                  <div className="flex items-center space-x-2">
                    <Icon name="FileText" size={16} className="text-text-secondary" />
                    <span className="text-sm text-text-primary">CSV (Comma Separated Values)</span>
                  </div>
                </label>
                <label className="flex items-center space-x-3">
                  <input
                    type="radio"
                    value="pdf"
                    checked={exportFormat === 'pdf'}
                    onChange={(e) => setExportFormat(e.target.value)}
                    className="w-4 h-4 text-primary focus:ring-primary border-border"
                  />
                  <div className="flex items-center space-x-2">
                    <Icon name="File" size={16} className="text-text-secondary" />
                    <span className="text-sm text-text-primary">PDF (Portable Document Format)</span>
                  </div>
                </label>
              </div>
            </div>

            <div className="bg-secondary-50 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <Icon name="Info" size={16} className="text-primary mt-0.5" />
                <div>
                  <p className="text-sm text-text-primary font-medium">Export Information</p>
                  <p className="text-xs text-text-secondary mt-1">
                    {exportFormat === 'csv' ?'CSV files can be opened in spreadsheet applications like Excel or Google Sheets.' :'PDF files are formatted for printing and sharing with consistent formatting.'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-border bg-secondary-50">
          <div className="flex items-center justify-end space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-text-secondary hover:text-text-primary transition-colors"
              disabled={isExporting}
            >
              Cancel
            </button>
            <button
              onClick={handleExport}
              disabled={isExporting}
              className="flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-700 transition-colors disabled:opacity-50"
            >
              {isExporting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Exporting...</span>
                </>
              ) : (
                <>
                  <Icon name="Download" size={16} />
                  <span>Export {exportFormat.toUpperCase()}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExportModal;