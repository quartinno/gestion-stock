import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';
import { format, subDays, subMonths } from 'date-fns';

const SubscriptionReport = ({ onExport, isLoading, setIsLoading }) => {
  const [subscriptionData, setSubscriptionData] = useState([]);
  const [paymentHistory, setPaymentHistory] = useState([]);
  const [summaryData, setSummaryData] = useState({});
  const [selectedPeriod, setSelectedPeriod] = useState('6months');

  useEffect(() => {
    generateSubscriptionData();
  }, [selectedPeriod]);

  const generateSubscriptionData = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const today = new Date();
    
    // Mock subscription data
    const mockSubscriptions = [
      {
        id: 'SUB001',
        clientName: 'Acme Corporation',
        plan: 'Enterprise',
        startDate: format(subMonths(today, 18), 'yyyy-MM-dd'),
        endDate: format(subMonths(today, -6), 'yyyy-MM-dd'),
        monthlyFee: 499,
        status: 'Active',
        paymentMethod: 'Credit Card',
        lastPayment: format(subDays(today, 15), 'yyyy-MM-dd'),
        totalPaid: 8984
      },
      {
        id: 'SUB002',
        clientName: 'Global Tech Solutions',
        plan: 'Professional',
        startDate: format(subMonths(today, 12), 'yyyy-MM-dd'),
        endDate: format(subMonths(today, -12), 'yyyy-MM-dd'),
        monthlyFee: 299,
        status: 'Active',
        paymentMethod: 'Bank Transfer',
        lastPayment: format(subDays(today, 8), 'yyyy-MM-dd'),
        totalPaid: 3588
      },
      {
        id: 'SUB003',
        clientName: 'Sunrise Industries',
        plan: 'Basic',
        startDate: format(subMonths(today, 8), 'yyyy-MM-dd'),
        endDate: format(subMonths(today, -4), 'yyyy-MM-dd'),
        monthlyFee: 99,
        status: 'Expired',
        paymentMethod: 'Credit Card',
        lastPayment: format(subDays(today, 125), 'yyyy-MM-dd'),
        totalPaid: 792
      },
      {
        id: 'SUB004',
        clientName: 'Metro Retail Chain',
        plan: 'Enterprise',
        startDate: format(subMonths(today, 24), 'yyyy-MM-dd'),
        endDate: format(subMonths(today, -12), 'yyyy-MM-dd'),
        monthlyFee: 499,
        status: 'Active',
        paymentMethod: 'Credit Card',
        lastPayment: format(subDays(today, 5), 'yyyy-MM-dd'),
        totalPaid: 11976
      },
      {
        id: 'SUB005',
        clientName: 'Pacific Logistics',
        plan: 'Professional',
        startDate: format(subMonths(today, 6), 'yyyy-MM-dd'),
        endDate: format(subMonths(today, -6), 'yyyy-MM-dd'),
        monthlyFee: 299,
        status: 'Cancelled',
        paymentMethod: 'Bank Transfer',
        lastPayment: format(subDays(today, 90), 'yyyy-MM-dd'),
        totalPaid: 1794
      },
      {
        id: 'SUB006',
        clientName: 'Northern Manufacturing',
        plan: 'Professional',
        startDate: format(subMonths(today, 15), 'yyyy-MM-dd'),
        endDate: format(subMonths(today, -9), 'yyyy-MM-dd'),
        monthlyFee: 299,
        status: 'Active',
        paymentMethod: 'Credit Card',
        lastPayment: format(subDays(today, 12), 'yyyy-MM-dd'),
        totalPaid: 4485
      }
    ];

    // Generate payment history chart data
    const months = selectedPeriod === '6months' ? 6 : selectedPeriod === '12months' ? 12 : 24;
    const paymentData = [];
    
    for (let i = months - 1; i >= 0; i--) {
      const date = subMonths(today, i);
      const monthlyRevenue = mockSubscriptions
        .filter(sub => sub.status === 'Active' || (sub.status === 'Expired' && new Date(sub.endDate) >= date))
        .reduce((sum, sub) => sum + sub.monthlyFee, 0);
      
      paymentData.push({
        month: format(date, 'MMM yyyy'),
        revenue: monthlyRevenue,
        subscriptions: mockSubscriptions.filter(sub => sub.status === 'Active').length
      });
    }

    setSubscriptionData(mockSubscriptions);
    setPaymentHistory(paymentData);
    
    // Calculate summary
    const activeSubscriptions = mockSubscriptions.filter(sub => sub.status === 'Active');
    const expiredSubscriptions = mockSubscriptions.filter(sub => sub.status === 'Expired');
    const cancelledSubscriptions = mockSubscriptions.filter(sub => sub.status === 'Cancelled');
    
    const summary = {
      totalSubscriptions: mockSubscriptions.length,
      activeSubscriptions: activeSubscriptions.length,
      expiredSubscriptions: expiredSubscriptions.length,
      cancelledSubscriptions: cancelledSubscriptions.length,
      monthlyRevenue: activeSubscriptions.reduce((sum, sub) => sum + sub.monthlyFee, 0),
      totalRevenue: mockSubscriptions.reduce((sum, sub) => sum + sub.totalPaid, 0),
      averageSubscriptionValue: mockSubscriptions.reduce((sum, sub) => sum + sub.monthlyFee, 0) / mockSubscriptions.length,
      churnRate: (cancelledSubscriptions.length / mockSubscriptions.length * 100).toFixed(1)
    };

    setSummaryData(summary);
    setIsLoading(false);
  };

  const planDistributionData = [
    { name: 'Enterprise', value: subscriptionData.filter(sub => sub.plan === 'Enterprise').length, color: '#3B82F6' },
    { name: 'Professional', value: subscriptionData.filter(sub => sub.plan === 'Professional').length, color: '#10B981' },
    { name: 'Basic', value: subscriptionData.filter(sub => sub.plan === 'Basic').length, color: '#F59E0B' }
  ];

  const statusData = [
    { name: 'Active', value: subscriptionData.filter(sub => sub.status === 'Active').length, color: '#059669' },
    { name: 'Expired', value: subscriptionData.filter(sub => sub.status === 'Expired').length, color: '#DC2626' },
    { name: 'Cancelled', value: subscriptionData.filter(sub => sub.status === 'Cancelled').length, color: '#6B7280' }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'text-success bg-success-50';
      case 'Expired':
        return 'text-error bg-error-50';
      case 'Cancelled':
        return 'text-text-secondary bg-secondary-50';
      default:
        return 'text-text-secondary bg-secondary-50';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Active':
        return 'CheckCircle';
      case 'Expired':
        return 'XCircle';
      case 'Cancelled':
        return 'MinusCircle';
      default:
        return 'Circle';
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(value);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-text-secondary">Loading subscription report...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Admin Only Banner */}
      <div className="bg-primary-50 border border-primary-200 rounded-lg p-4">
        <div className="flex items-center space-x-2">
          <Icon name="Shield" size={20} className="text-primary" />
          <p className="text-sm text-primary font-medium">Admin Only Report</p>
          <span className="text-xs text-primary-600">This report contains sensitive subscription and payment data</span>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Total Subscriptions</p>
              <p className="text-2xl font-bold text-text-primary">{summaryData.totalSubscriptions}</p>
            </div>
            <div className="w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center">
              <Icon name="Users" size={24} className="text-primary" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Active Subscriptions</p>
              <p className="text-2xl font-bold text-success">{summaryData.activeSubscriptions}</p>
            </div>
            <div className="w-12 h-12 bg-success-50 rounded-lg flex items-center justify-center">
              <Icon name="CheckCircle" size={24} className="text-success" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Monthly Revenue</p>
              <p className="text-2xl font-bold text-text-primary">{formatCurrency(summaryData.monthlyRevenue)}</p>
            </div>
            <div className="w-12 h-12 bg-accent-50 rounded-lg flex items-center justify-center">
              <Icon name="DollarSign" size={24} className="text-accent" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Churn Rate</p>
              <p className="text-2xl font-bold text-error">{summaryData.churnRate}%</p>
            </div>
            <div className="w-12 h-12 bg-error-50 rounded-lg flex items-center justify-center">
              <Icon name="TrendingDown" size={24} className="text-error" />
            </div>
          </div>
        </div>
      </div>

      {/* Revenue Trend */}
      <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">Revenue Trend</h3>
          <div className="flex items-center space-x-2">
            <label className="text-sm text-text-secondary">Period:</label>
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="6months">Last 6 Months</option>
              <option value="12months">Last 12 Months</option>
              <option value="24months">Last 24 Months</option>
            </select>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={paymentHistory}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" tick={{ fontSize: 12 }} />
            <YAxis />
            <Tooltip formatter={(value) => formatCurrency(value)} />
            <Line type="monotone" dataKey="revenue" stroke="#3B82F6" strokeWidth={2} name="Monthly Revenue" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Plan and Status Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <h3 className="text-lg font-semibold text-text-primary mb-4">Plan Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={planDistributionData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {planDistributionData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <h3 className="text-lg font-semibold text-text-primary mb-4">Subscription Status</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={statusData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Subscription Details Table */}
      <div className="bg-surface border border-border rounded-lg shadow-card">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-text-primary">Detailed Subscription Report</h3>
            <button
              onClick={() => onExport('subscription', { subscriptionData, paymentHistory, summary: summaryData })}
              className="flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-700 transition-colors"
            >
              <Icon name="Download" size={16} />
              <span>Export</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary-50">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Subscription ID</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Client</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Plan</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Monthly Fee</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Start Date</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Last Payment</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Total Paid</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Status</th>
              </tr>
            </thead>
            <tbody>
              {subscriptionData.map((subscription, index) => (
                <tr key={index} className="border-b border-border hover:bg-secondary-50">
                  <td className="p-4 text-sm text-text-primary font-medium">{subscription.id}</td>
                  <td className="p-4 text-sm text-text-primary">{subscription.clientName}</td>
                  <td className="p-4 text-sm text-text-primary">{subscription.plan}</td>
                  <td className="p-4 text-sm text-text-primary">{formatCurrency(subscription.monthlyFee)}</td>
                  <td className="p-4 text-sm text-text-primary">{format(new Date(subscription.startDate), 'MMM dd, yyyy')}</td>
                  <td className="p-4 text-sm text-text-primary">{format(new Date(subscription.lastPayment), 'MMM dd, yyyy')}</td>
                  <td className="p-4 text-sm text-text-primary font-medium">{formatCurrency(subscription.totalPaid)}</td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Icon name={getStatusIcon(subscription.status)} size={16} className={
                        subscription.status === 'Active' ? 'text-success' : 
                        subscription.status === 'Expired' ? 'text-error' : 'text-text-secondary'
                      } />
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(subscription.status)}`}>
                        {subscription.status}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionReport;