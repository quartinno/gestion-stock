import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import Icon from '../../../components/AppIcon';
import { format, addDays } from 'date-fns';

const ExpirationReport = ({ onExport, isLoading, setIsLoading }) => {
  const [expirationData, setExpirationData] = useState([]);
  const [filterType, setFilterType] = useState('all');
  const [summaryData, setSummaryData] = useState({});

  useEffect(() => {
    generateExpirationData();
  }, [filterType]);

  const generateExpirationData = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const today = new Date();
    const mockData = [
      { 
        product: 'Milk - Organic', 
        category: 'Dairy', 
        expirationDate: format(addDays(today, -2), 'yyyy-MM-dd'), 
        quantity: 15, 
        value: 450,
        status: 'Expired' 
      },
      { 
        product: 'Bread - Whole Wheat', 
        category: 'Bakery', 
        expirationDate: format(addDays(today, -1), 'yyyy-MM-dd'), 
        quantity: 8, 
        value: 160,
        status: 'Expired' 
      },
      { 
        product: 'Yogurt - Greek', 
        category: 'Dairy', 
        expirationDate: format(addDays(today, 1), 'yyyy-MM-dd'), 
        quantity: 25, 
        value: 625,
        status: 'Expires Soon' 
      },
      { 
        product: 'Cheese - Cheddar', 
        category: 'Dairy', 
        expirationDate: format(addDays(today, 3), 'yyyy-MM-dd'), 
        quantity: 12, 
        value: 360,
        status: 'Expires Soon' 
      },
      { 
        product: 'Cookies - Chocolate', 
        category: 'Bakery', 
        expirationDate: format(addDays(today, 5), 'yyyy-MM-dd'), 
        quantity: 20, 
        value: 400,
        status: 'Expires Soon' 
      },
      { 
        product: 'Butter - Unsalted', 
        category: 'Dairy', 
        expirationDate: format(addDays(today, 7), 'yyyy-MM-dd'), 
        quantity: 18, 
        value: 540,
        status: 'Expires Soon' 
      }
    ];

    const filteredData = filterType === 'all' 
      ? mockData 
      : mockData.filter(item => item.status.toLowerCase().includes(filterType.toLowerCase()));

    setExpirationData(filteredData);
    
    // Calculate summary
    const expired = mockData.filter(item => item.status === 'Expired');
    const expiringSoon = mockData.filter(item => item.status === 'Expires Soon');
    
    const summary = {
      totalExpired: expired.length,
      totalExpiringSoon: expiringSoon.length,
      expiredValue: expired.reduce((sum, item) => sum + item.value, 0),
      expiringSoonValue: expiringSoon.reduce((sum, item) => sum + item.value, 0),
      totalLoss: expired.reduce((sum, item) => sum + item.value, 0)
    };

    setSummaryData(summary);
    setIsLoading(false);
  };

  const chartData = expirationData.reduce((acc, item) => {
    const date = format(new Date(item.expirationDate), 'MMM dd');
    const existingEntry = acc.find(entry => entry.date === date);
    
    if (existingEntry) {
      existingEntry.quantity += item.quantity;
      existingEntry.value += item.value;
    } else {
      acc.push({
        date,
        quantity: item.quantity,
        value: item.value
      });
    }
    
    return acc;
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case 'Expired':
        return 'text-error bg-error-50';
      case 'Expires Soon':
        return 'text-warning bg-warning-50';
      default:
        return 'text-text-secondary bg-secondary-50';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Expired':
        return 'XCircle';
      case 'Expires Soon':
        return 'AlertTriangle';
      default:
        return 'Info';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-text-secondary">Loading expiration report...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Expired Items</p>
              <p className="text-2xl font-bold text-error">{summaryData.totalExpired}</p>
            </div>
            <div className="w-12 h-12 bg-error-50 rounded-lg flex items-center justify-center">
              <Icon name="XCircle" size={24} className="text-error" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Expiring Soon</p>
              <p className="text-2xl font-bold text-warning">{summaryData.totalExpiringSoon}</p>
            </div>
            <div className="w-12 h-12 bg-warning-50 rounded-lg flex items-center justify-center">
              <Icon name="AlertTriangle" size={24} className="text-warning" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Expired Value</p>
              <p className="text-2xl font-bold text-error">${summaryData.expiredValue}</p>
            </div>
            <div className="w-12 h-12 bg-error-50 rounded-lg flex items-center justify-center">
              <Icon name="DollarSign" size={24} className="text-error" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">At Risk Value</p>
              <p className="text-2xl font-bold text-warning">${summaryData.expiringSoonValue}</p>
            </div>
            <div className="w-12 h-12 bg-warning-50 rounded-lg flex items-center justify-center">
              <Icon name="TrendingDown" size={24} className="text-warning" />
            </div>
          </div>
        </div>
      </div>

      {/* Filter Controls */}
      <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">Expiration Analysis</h3>
          <div className="flex items-center space-x-2">
            <label className="text-sm text-text-secondary">Filter by Status:</label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="all">All Items</option>
              <option value="expired">Expired Only</option>
              <option value="soon">Expiring Soon</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Bar Chart */}
          <div>
            <h4 className="text-md font-medium text-text-primary mb-4">Expiration Timeline</h4>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="quantity" fill="#D97706" name="Quantity" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Line Chart */}
          <div>
            <h4 className="text-md font-medium text-text-primary mb-4">Value at Risk</h4>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#DC2626" strokeWidth={2} name="Value ($)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Expiration Table */}
      <div className="bg-surface border border-border rounded-lg shadow-card">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-text-primary">Detailed Expiration Report</h3>
            <button
              onClick={() => onExport('expiration', expirationData)}
              className="flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-700 transition-colors"
            >
              <Icon name="Download" size={16} />
              <span>Export</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary-50">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Product</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Category</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Expiration Date</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Quantity</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Value</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Status</th>
              </tr>
            </thead>
            <tbody>
              {expirationData.map((item, index) => (
                <tr key={index} className="border-b border-border hover:bg-secondary-50">
                  <td className="p-4 text-sm text-text-primary font-medium">{item.product}</td>
                  <td className="p-4 text-sm text-text-secondary">{item.category}</td>
                  <td className="p-4 text-sm text-text-primary">{format(new Date(item.expirationDate), 'MMM dd, yyyy')}</td>
                  <td className="p-4 text-sm text-text-primary">{item.quantity}</td>
                  <td className="p-4 text-sm text-text-primary">${item.value}</td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Icon name={getStatusIcon(item.status)} size={16} className={item.status === 'Expired' ? 'text-error' : 'text-warning'} />
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`}>
                        {item.status}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ExpirationReport;