import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';
import { format, subDays, startOfWeek, startOfMonth } from 'date-fns';

const SalesPerformanceReport = ({ onExport, isLoading, setIsLoading }) => {
  const [salesData, setSalesData] = useState([]);
  const [timePeriod, setTimePeriod] = useState('daily');
  const [summaryData, setSummaryData] = useState({});
  const [categoryData, setCategoryData] = useState([]);

  useEffect(() => {
    generateSalesData();
  }, [timePeriod]);

  const generateSalesData = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const today = new Date();
    let mockData = [];
    
    if (timePeriod === 'daily') {
      // Generate daily data for the last 30 days
      for (let i = 29; i >= 0; i--) {
        const date = subDays(today, i);
        mockData.push({
          date: format(date, 'MMM dd'),
          sales: Math.floor(Math.random() * 5000) + 1000,
          orders: Math.floor(Math.random() * 50) + 10,
          avgOrderValue: Math.floor(Math.random() * 200) + 50
        });
      }
    } else if (timePeriod === 'weekly') {
      // Generate weekly data for the last 12 weeks
      for (let i = 11; i >= 0; i--) {
        const date = startOfWeek(subDays(today, i * 7));
        mockData.push({
          date: format(date, 'MMM dd'),
          sales: Math.floor(Math.random() * 30000) + 10000,
          orders: Math.floor(Math.random() * 300) + 100,
          avgOrderValue: Math.floor(Math.random() * 200) + 50
        });
      }
    } else {
      // Generate monthly data for the last 12 months
      for (let i = 11; i >= 0; i--) {
        const date = startOfMonth(subDays(today, i * 30));
        mockData.push({
          date: format(date, 'MMM yyyy'),
          sales: Math.floor(Math.random() * 100000) + 50000,
          orders: Math.floor(Math.random() * 1000) + 500,
          avgOrderValue: Math.floor(Math.random() * 200) + 50
        });
      }
    }

    // Generate category performance data
    const categories = [
      { name: 'Electronics', sales: 125000, orders: 450, color: '#3B82F6' },
      { name: 'Furniture', sales: 85000, orders: 320, color: '#10B981' },
      { name: 'Office Supplies', sales: 65000, orders: 280, color: '#F59E0B' },
      { name: 'Food & Beverages', sales: 45000, orders: 200, color: '#EF4444' },
      { name: 'Clothing', sales: 35000, orders: 150, color: '#8B5CF6' }
    ];

    setSalesData(mockData);
    setCategoryData(categories);
    
    // Calculate summary
    const totalSales = mockData.reduce((sum, item) => sum + item.sales, 0);
    const totalOrders = mockData.reduce((sum, item) => sum + item.orders, 0);
    const avgOrderValue = totalSales / totalOrders;
    const growth = mockData.length > 1 ? ((mockData[mockData.length - 1].sales - mockData[0].sales) / mockData[0].sales * 100) : 0;
    
    const summary = {
      totalSales,
      totalOrders,
      avgOrderValue: Math.round(avgOrderValue),
      growth: Math.round(growth * 100) / 100,
      topCategory: categories[0].name
    };

    setSummaryData(summary);
    setIsLoading(false);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(value);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-text-secondary">Loading sales performance report...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Total Sales</p>
              <p className="text-2xl font-bold text-text-primary">{formatCurrency(summaryData.totalSales)}</p>
            </div>
            <div className="w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center">
              <Icon name="DollarSign" size={24} className="text-primary" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Total Orders</p>
              <p className="text-2xl font-bold text-text-primary">{summaryData.totalOrders?.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-success-50 rounded-lg flex items-center justify-center">
              <Icon name="ShoppingCart" size={24} className="text-success" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Avg Order Value</p>
              <p className="text-2xl font-bold text-text-primary">{formatCurrency(summaryData.avgOrderValue)}</p>
            </div>
            <div className="w-12 h-12 bg-accent-50 rounded-lg flex items-center justify-center">
              <Icon name="TrendingUp" size={24} className="text-accent" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Growth Rate</p>
              <p className={`text-2xl font-bold ${summaryData.growth >= 0 ? 'text-success' : 'text-error'}`}>
                {summaryData.growth >= 0 ? '+' : ''}{summaryData.growth}%
              </p>
            </div>
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${summaryData.growth >= 0 ? 'bg-success-50' : 'bg-error-50'}`}>
              <Icon name={summaryData.growth >= 0 ? 'TrendingUp' : 'TrendingDown'} size={24} className={summaryData.growth >= 0 ? 'text-success' : 'text-error'} />
            </div>
          </div>
        </div>
      </div>

      {/* Time Period Filter */}
      <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">Sales Trend Analysis</h3>
          <div className="flex items-center space-x-2">
            <label className="text-sm text-text-secondary">Time Period:</label>
            <select
              value={timePeriod}
              onChange={(e) => setTimePeriod(e.target.value)}
              className="px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
            </select>
          </div>
        </div>

        {/* Sales Trend Chart */}
        <div className="mb-6">
          <h4 className="text-md font-medium text-text-primary mb-4">Sales Trend</h4>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis />
              <Tooltip formatter={(value) => formatCurrency(value)} />
              <Line type="monotone" dataKey="sales" stroke="#3B82F6" strokeWidth={2} name="Sales" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Orders Chart */}
        <div>
          <h4 className="text-md font-medium text-text-primary mb-4">Order Volume</h4>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="orders" fill="#10B981" name="Orders" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Category Performance */}
      <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
        <h3 className="text-lg font-semibold text-text-primary mb-4">Category Performance</h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Category Sales Chart */}
          <div>
            <h4 className="text-md font-medium text-text-primary mb-4">Sales by Category</h4>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="sales"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatCurrency(value)} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Category Table */}
          <div>
            <h4 className="text-md font-medium text-text-primary mb-4">Category Details</h4>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-secondary-50">
                  <tr>
                    <th className="text-left p-3 text-sm font-medium text-text-primary">Category</th>
                    <th className="text-left p-3 text-sm font-medium text-text-primary">Sales</th>
                    <th className="text-left p-3 text-sm font-medium text-text-primary">Orders</th>
                  </tr>
                </thead>
                <tbody>
                  {categoryData.map((category, index) => (
                    <tr key={index} className="border-b border-border">
                      <td className="p-3 text-sm text-text-primary font-medium">{category.name}</td>
                      <td className="p-3 text-sm text-text-primary">{formatCurrency(category.sales)}</td>
                      <td className="p-3 text-sm text-text-primary">{category.orders}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Export Button */}
      <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-text-primary">Export Sales Report</h3>
            <p className="text-sm text-text-secondary mt-1">Download detailed sales performance data</p>
          </div>
          <button
            onClick={() => onExport('sales-performance', { salesData, categoryData, summary: summaryData })}
            className="flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-700 transition-colors"
          >
            <Icon name="Download" size={16} />
            <span>Export Report</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SalesPerformanceReport;