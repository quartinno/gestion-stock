import React from 'react';
import Icon from '../../../components/AppIcon';
import { useNavigate } from 'react-router-dom';

const ReportHeader = ({ onExport, activeTab }) => {
  const navigate = useNavigate();

  const getReportTitle = () => {
    switch (activeTab) {
      case 'stock-levels':
        return 'Stock Level Reports';
      case 'expiration':
        return 'Expiration Reports';
      case 'sales-performance':
        return 'Sales Performance Reports';
      case 'client-credit':
        return 'Client Credit Reports';
      case 'subscription':
        return 'Subscription Reports';
      default:
        return 'Inventory Reports';
    }
  };

  return (
    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold text-text-primary mb-2">
          {getReportTitle()}
        </h1>
        <p className="text-text-secondary">
          Generate comprehensive inventory reports with detailed analytics
        </p>
      </div>
      <div className="flex items-center space-x-4 mt-4 lg:mt-0">
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center space-x-2 px-4 py-2 bg-secondary-100 text-text-primary rounded-lg hover:bg-secondary-200 transition-colors duration-200"
        >
          <Icon name="ArrowLeft" size={16} />
          <span className="hidden sm:inline">Back to Dashboard</span>
        </button>
        <button
          onClick={onExport}
          className="flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-700 transition-colors duration-200"
        >
          <Icon name="Download" size={16} />
          <span className="hidden sm:inline">Export Report</span>
        </button>
      </div>
    </div>
  );
};

export default ReportHeader;