import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';

const StockLevelReport = ({ onExport, isLoading, setIsLoading }) => {
  const [stockData, setStockData] = useState([]);
  const [summaryData, setSummaryData] = useState({});
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    generateStockData();
  }, [selectedCategory]);

  const generateStockData = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockData = [
      { product: 'Laptop Pro 15"', category: 'Electronics', current: 45, lowStock: 15, outOfStock: 0, status: 'Good' },
      { product: 'Office Chair', category: 'Furniture', current: 12, lowStock: 5, outOfStock: 0, status: 'Low' },
      { product: 'Wireless Mouse', category: 'Electronics', current: 78, lowStock: 10, outOfStock: 0, status: 'Good' },
      { product: 'Desk Lamp', category: 'Furniture', current: 0, lowStock: 0, outOfStock: 25, status: 'Out of Stock' },
      { product: 'Notebook A4', category: 'Office Supplies', current: 150, lowStock: 50, outOfStock: 0, status: 'Good' },
      { product: 'Printer Paper', category: 'Office Supplies', current: 8, lowStock: 5, outOfStock: 0, status: 'Low' },
      { product: 'Monitor 24"', category: 'Electronics', current: 32, lowStock: 10, outOfStock: 0, status: 'Good' },
      { product: 'Filing Cabinet', category: 'Furniture', current: 0, lowStock: 0, outOfStock: 15, status: 'Out of Stock' }
    ];

    const filteredData = selectedCategory === 'all' 
      ? mockData 
      : mockData.filter(item => item.category === selectedCategory);

    setStockData(filteredData);
    
    // Calculate summary
    const summary = {
      totalProducts: filteredData.length,
      goodStock: filteredData.filter(item => item.status === 'Good').length,
      lowStock: filteredData.filter(item => item.status === 'Low').length,
      outOfStock: filteredData.filter(item => item.status === 'Out of Stock').length,
      totalValue: filteredData.reduce((sum, item) => sum + (item.current * 50), 0) // Assuming $50 per unit
    };

    setSummaryData(summary);
    setIsLoading(false);
  };

  const chartData = stockData.map(item => ({
    name: item.product,
    current: item.current,
    lowStock: item.lowStock,
    outOfStock: item.outOfStock
  }));

  const pieData = [
    { name: 'Good Stock', value: summaryData.goodStock, color: '#059669' },
    { name: 'Low Stock', value: summaryData.lowStock, color: '#D97706' },
    { name: 'Out of Stock', value: summaryData.outOfStock, color: '#DC2626' }
  ];

  const categories = ['all', 'Electronics', 'Furniture', 'Office Supplies'];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Good':
        return 'text-success bg-success-50';
      case 'Low':
        return 'text-warning bg-warning-50';
      case 'Out of Stock':
        return 'text-error bg-error-50';
      default:
        return 'text-text-secondary bg-secondary-50';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-text-secondary">Loading stock level report...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Total Products</p>
              <p className="text-2xl font-bold text-text-primary">{summaryData.totalProducts}</p>
            </div>
            <div className="w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center">
              <Icon name="Package" size={24} className="text-primary" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Good Stock</p>
              <p className="text-2xl font-bold text-success">{summaryData.goodStock}</p>
            </div>
            <div className="w-12 h-12 bg-success-50 rounded-lg flex items-center justify-center">
              <Icon name="CheckCircle" size={24} className="text-success" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Low Stock</p>
              <p className="text-2xl font-bold text-warning">{summaryData.lowStock}</p>
            </div>
            <div className="w-12 h-12 bg-warning-50 rounded-lg flex items-center justify-center">
              <Icon name="AlertTriangle" size={24} className="text-warning" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Out of Stock</p>
              <p className="text-2xl font-bold text-error">{summaryData.outOfStock}</p>
            </div>
            <div className="w-12 h-12 bg-error-50 rounded-lg flex items-center justify-center">
              <Icon name="XCircle" size={24} className="text-error" />
            </div>
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">Stock Level Analysis</h3>
          <div className="flex items-center space-x-2">
            <label className="text-sm text-text-secondary">Filter by Category:</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary"
            >
              {categories.map(category => (
                <option key={category} value={category}>
                  {category === 'all' ? 'All Categories' : category}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Bar Chart */}
          <div>
            <h4 className="text-md font-medium text-text-primary mb-4">Stock Levels by Product</h4>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="current" fill="#3B82F6" name="Current Stock" />
                <Bar dataKey="lowStock" fill="#D97706" name="Low Stock Threshold" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Pie Chart */}
          <div>
            <h4 className="text-md font-medium text-text-primary mb-4">Stock Status Distribution</h4>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Stock Table */}
      <div className="bg-surface border border-border rounded-lg shadow-card">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-text-primary">Detailed Stock Report</h3>
            <button
              onClick={() => onExport('stock-levels', stockData)}
              className="flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-700 transition-colors"
            >
              <Icon name="Download" size={16} />
              <span>Export</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary-50">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Product</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Category</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Current Stock</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Low Stock Threshold</th>
                <th className="text-left p-4 text-sm font-medium text-text-primary">Status</th>
              </tr>
            </thead>
            <tbody>
              {stockData.map((item, index) => (
                <tr key={index} className="border-b border-border hover:bg-secondary-50">
                  <td className="p-4 text-sm text-text-primary font-medium">{item.product}</td>
                  <td className="p-4 text-sm text-text-secondary">{item.category}</td>
                  <td className="p-4 text-sm text-text-primary">{item.current}</td>
                  <td className="p-4 text-sm text-text-secondary">{item.lowStock}</td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`}>
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StockLevelReport;