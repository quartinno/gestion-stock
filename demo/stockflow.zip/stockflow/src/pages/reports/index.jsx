import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import StockLevelReport from './components/StockLevelReport';
import ExpirationReport from './components/ExpirationReport';
import SalesPerformanceReport from './components/SalesPerformanceReport';
import ClientCreditReport from './components/ClientCreditReport';
import SubscriptionReport from './components/SubscriptionReport';
import ReportHeader from './components/ReportHeader';
import ExportModal from './components/ExportModal';

const Reports = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('stock-levels');
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [selectedReportData, setSelectedReportData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const reportTabs = [
    {
      id: 'stock-levels',
      label: 'Stock Levels',
      icon: 'Package',
      description: 'Current stock, low stock, and out-of-stock items'
    },
    {
      id: 'expiration',
      label: 'Expiration',
      icon: 'Calendar',
      description: 'Expired and soon-to-expire products'
    },
    {
      id: 'sales-performance',
      label: 'Sales Performance',
      icon: 'TrendingUp',
      description: 'Sales analysis by product, category, and time period'
    },
    {
      id: 'client-credit',
      label: 'Client Credit',
      icon: 'CreditCard',
      description: 'Client balances and overdue payments'
    },
    {
      id: 'subscription',
      label: 'Subscription',
      icon: 'Users',
      description: 'Subscription and payment history (Admin only)'
    }
  ];

  const handleExportReport = (reportType, data) => {
    setSelectedReportData({ type: reportType, data });
    setIsExportModalOpen(true);
  };

  const renderActiveReport = () => {
    const commonProps = {
      onExport: handleExportReport,
      isLoading,
      setIsLoading
    };

    switch (activeTab) {
      case 'stock-levels':
        return <StockLevelReport {...commonProps} />;
      case 'expiration':
        return <ExpirationReport {...commonProps} />;
      case 'sales-performance':
        return <SalesPerformanceReport {...commonProps} />;
      case 'client-credit':
        return <ClientCreditReport {...commonProps} />;
      case 'subscription':
        return <SubscriptionReport {...commonProps} />;
      default:
        return <StockLevelReport {...commonProps} />;
    }
  };

  return (
    <div className="min-h-screen bg-background pt-header pl-0 lg:pl-sidebar pb-16 lg:pb-0">
      <div className="p-4 lg:p-8">
        <ReportHeader 
          onExport={() => handleExportReport(activeTab, null)}
          activeTab={activeTab}
        />

        {/* Report Tabs */}
        <div className="bg-surface border border-border rounded-lg shadow-card mb-6">
          <div className="border-b border-border">
            <div className="flex overflow-x-auto scrollbar-hide">
              {reportTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-shrink-0 flex items-center space-x-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors duration-200 ${
                    activeTab === tab.id
                      ? 'border-primary text-primary bg-primary-50' :'border-transparent text-text-secondary hover:text-text-primary hover:bg-secondary-50'
                  }`}
                >
                  <Icon name={tab.icon} size={16} />
                  <span className="whitespace-nowrap">{tab.label}</span>
                </button>
              ))}
            </div>
          </div>
          
          <div className="p-4 border-b border-border bg-secondary-50">
            <p className="text-sm text-text-secondary">
              {reportTabs.find(tab => tab.id === activeTab)?.description}
            </p>
          </div>
        </div>

        {/* Report Content */}
        <div className="space-y-6">
          {renderActiveReport()}
        </div>

        {/* Export Modal */}
        <ExportModal
          isOpen={isExportModalOpen}
          onClose={() => setIsExportModalOpen(false)}
          reportData={selectedReportData}
        />
      </div>
    </div>
  );
};

export default Reports;