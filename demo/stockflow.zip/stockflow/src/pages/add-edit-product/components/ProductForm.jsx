import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ProductForm = ({ 
  formData, 
  setFormData, 
  errors, 
  setErrors, 
  activeTab, 
  setActiveTab,
  onSave,
  onCancel,
  isEditing = false
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [showBarcodeScanner, setShowBarcodeScanner] = useState(false);
  const fileInputRef = useRef(null);

  const tabs = [
    { id: 'basic', label: 'Basic Information', icon: 'Info' },
    { id: 'inventory', label: 'Inventory Details', icon: 'Package' },
    { id: 'pricing', label: 'Pricing', icon: 'DollarSign' },
    { id: 'additional', label: 'Additional Data', icon: 'Settings' }
  ];

  const categories = [
    { id: 1, name: 'Electronics', subcategories: ['Smartphones', 'Laptops', 'Accessories'] },
    { id: 2, name: 'Clothing', subcategories: ['Men\'s Wear', 'Women\'s Wear', 'Kids Wear'] },
    { id: 3, name: 'Home & Garden', subcategories: ['Furniture', 'Decor', 'Tools'] },
    { id: 4, name: 'Sports', subcategories: ['Fitness', 'Outdoor', 'Team Sports'] }
  ];

  const suppliers = [
    { id: 1, name: 'TechSupply Co.', contact: 'contact@techsupply.com' },
    { id: 2, name: 'Global Electronics', contact: 'sales@globalelec.com' },
    { id: 3, name: 'Premium Goods Ltd.', contact: 'orders@premiumgoods.com' }
  ];

  const locations = [
    { id: 1, name: 'Main Warehouse', code: 'MW-001' },
    { id: 2, name: 'Store Front', code: 'SF-001' },
    { id: 3, name: 'Distribution Center', code: 'DC-001' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const handleImageUpload = (files) => {
    const file = files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFormData(prev => ({
          ...prev,
          image: e.target.result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    handleImageUpload(files);
  };

  const handleBarcodeScanned = (barcode) => {
    setFormData(prev => ({
      ...prev,
      barcode: barcode
    }));
    setShowBarcodeScanner(false);
  };

  const renderBasicInformation = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Product Name *
          </label>
          <Input
            type="text"
            placeholder="Enter product name"
            value={formData.name}
            onChange={(e) => handleInputChange('name', e.target.value)}
            className={errors.name ? 'border-error' : ''}
          />
          {errors.name && (
            <p className="mt-1 text-sm text-error">{errors.name}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            SKU *
          </label>
          <Input
            type="text"
            placeholder="Enter SKU"
            value={formData.sku}
            onChange={(e) => handleInputChange('sku', e.target.value)}
            className={errors.sku ? 'border-error' : ''}
          />
          {errors.sku && (
            <p className="mt-1 text-sm text-error">{errors.sku}</p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Description
        </label>
        <textarea
          rows={4}
          placeholder="Enter product description"
          value={formData.description}
          onChange={(e) => handleInputChange('description', e.target.value)}
          className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Category *
          </label>
          <select
            value={formData.category}
            onChange={(e) => handleInputChange('category', e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            <option value="">Select category</option>
            {categories.map(category => (
              <option key={category.id} value={category.name}>
                {category.name}
              </option>
            ))}
          </select>
          {errors.category && (
            <p className="mt-1 text-sm text-error">{errors.category}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Subcategory
          </label>
          <select
            value={formData.subcategory}
            onChange={(e) => handleInputChange('subcategory', e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
            disabled={!formData.category}
          >
            <option value="">Select subcategory</option>
            {formData.category && categories
              .find(cat => cat.name === formData.category)
              ?.subcategories.map(sub => (
                <option key={sub} value={sub}>{sub}</option>
              ))}
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Product Image
        </label>
        <div
          className={`
            border-2 border-dashed rounded-lg p-6 text-center transition-colors duration-200
            ${isDragOver ? 'border-primary bg-primary-50' : 'border-border'}
            ${formData.image ? 'bg-secondary-50' : ''}
          `}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {formData.image ? (
            <div className="space-y-4">
              <img
                src={formData.image}
                alt="Product preview"
                className="w-32 h-32 object-cover rounded-lg mx-auto"
              />
              <div className="flex justify-center space-x-2">
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Icon name="Upload" size={16} className="mr-2" />
                  Change Image
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => handleInputChange('image', '')}
                >
                  <Icon name="Trash2" size={16} className="mr-2" />
                  Remove
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <Icon name="Upload" size={48} className="mx-auto text-text-quaternary" />
              <div>
                <p className="text-text-primary font-medium">
                  Drag and drop an image here, or click to select
                </p>
                <p className="text-sm text-text-secondary mt-1">
                  PNG, JPG, GIF up to 10MB
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
              >
                Select Image
              </Button>
            </div>
          )}
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={(e) => handleImageUpload(e.target.files)}
          className="hidden"
        />
      </div>
    </div>
  );

  const renderInventoryDetails = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Current Stock *
          </label>
          <Input
            type="number"
            placeholder="0"
            value={formData.currentStock}
            onChange={(e) => handleInputChange('currentStock', e.target.value)}
            className={errors.currentStock ? 'border-error' : ''}
          />
          {errors.currentStock && (
            <p className="mt-1 text-sm text-error">{errors.currentStock}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Reorder Point *
          </label>
          <Input
            type="number"
            placeholder="0"
            value={formData.reorderPoint}
            onChange={(e) => handleInputChange('reorderPoint', e.target.value)}
            className={errors.reorderPoint ? 'border-error' : ''}
          />
          {errors.reorderPoint && (
            <p className="mt-1 text-sm text-error">{errors.reorderPoint}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Supplier
          </label>
          <select
            value={formData.supplier}
            onChange={(e) => handleInputChange('supplier', e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            <option value="">Select supplier</option>
            {suppliers.map(supplier => (
              <option key={supplier.id} value={supplier.name}>
                {supplier.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Location *
          </label>
          <select
            value={formData.location}
            onChange={(e) => handleInputChange('location', e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            <option value="">Select location</option>
            {locations.map(location => (
              <option key={location.id} value={location.name}>
                {location.name} ({location.code})
              </option>
            ))}
          </select>
          {errors.location && (
            <p className="mt-1 text-sm text-error">{errors.location}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Unit of Measure
          </label>
          <select
            value={formData.unitOfMeasure}
            onChange={(e) => handleInputChange('unitOfMeasure', e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            <option value="">Select unit</option>
            <option value="pieces">Pieces</option>
            <option value="kg">Kilograms</option>
            <option value="lbs">Pounds</option>
            <option value="liters">Liters</option>
            <option value="meters">Meters</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Maximum Stock Level
          </label>
          <Input
            type="number"
            placeholder="0"
            value={formData.maxStock}
            onChange={(e) => handleInputChange('maxStock', e.target.value)}
          />
        </div>
      </div>
    </div>
  );

  const renderPricing = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Cost Price *
          </label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary">
              $
            </span>
            <Input
              type="number"
              placeholder="0.00"
              value={formData.costPrice}
              onChange={(e) => handleInputChange('costPrice', e.target.value)}
              className={`pl-8 ${errors.costPrice ? 'border-error' : ''}`}
              step="0.01"
            />
          </div>
          {errors.costPrice && (
            <p className="mt-1 text-sm text-error">{errors.costPrice}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Selling Price *
          </label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary">
              $
            </span>
            <Input
              type="number"
              placeholder="0.00"
              value={formData.sellingPrice}
              onChange={(e) => handleInputChange('sellingPrice', e.target.value)}
              className={`pl-8 ${errors.sellingPrice ? 'border-error' : ''}`}
              step="0.01"
            />
          </div>
          {errors.sellingPrice && (
            <p className="mt-1 text-sm text-error">{errors.sellingPrice}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Tax Category
          </label>
          <select
            value={formData.taxCategory}
            onChange={(e) => handleInputChange('taxCategory', e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            <option value="">Select tax category</option>
            <option value="standard">Standard Rate (10%)</option>
            <option value="reduced">Reduced Rate (5%)</option>
            <option value="zero">Zero Rate (0%)</option>
            <option value="exempt">Tax Exempt</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Profit Margin
          </label>
          <div className="relative">
            <Input
              type="number"
              placeholder="0.00"
              value={formData.profitMargin}
              onChange={(e) => handleInputChange('profitMargin', e.target.value)}
              className="pr-8"
              step="0.01"
              readOnly
            />
            <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary">
              %
            </span>
          </div>
          <p className="mt-1 text-xs text-text-secondary">
            Calculated automatically based on cost and selling price
          </p>
        </div>
      </div>

      <div className="bg-secondary-50 p-4 rounded-lg">
        <h4 className="text-sm font-medium text-text-primary mb-2">Price Summary</h4>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-text-secondary">Cost Price:</span>
            <span className="float-right font-medium">${formData.costPrice || '0.00'}</span>
          </div>
          <div>
            <span className="text-text-secondary">Selling Price:</span>
            <span className="float-right font-medium">${formData.sellingPrice || '0.00'}</span>
          </div>
          <div>
            <span className="text-text-secondary">Tax Amount:</span>
            <span className="float-right font-medium">$0.00</span>
          </div>
          <div className="border-t border-border pt-2">
            <span className="text-text-primary font-medium">Final Price:</span>
            <span className="float-right font-semibold">${formData.sellingPrice || '0.00'}</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAdditionalData = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Barcode
        </label>
        <div className="flex space-x-2">
          <Input
            type="text"
            placeholder="Enter or scan barcode"
            value={formData.barcode}
            onChange={(e) => handleInputChange('barcode', e.target.value)}
            className="flex-1"
          />
          <Button
            variant="outline"
            onClick={() => setShowBarcodeScanner(true)}
          >
            <Icon name="Scan" size={16} className="mr-2" />
            Scan
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={formData.serialTracking}
              onChange={(e) => handleInputChange('serialTracking', e.target.checked)}
              className="rounded border-border text-primary focus:ring-primary"
            />
            <span className="text-sm font-medium text-text-primary">
              Enable Serial Number Tracking
            </span>
          </label>
        </div>

        <div>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={formData.batchTracking}
              onChange={(e) => handleInputChange('batchTracking', e.target.checked)}
              className="rounded border-border text-primary focus:ring-primary"
            />
            <span className="text-sm font-medium text-text-primary">
              Enable Batch Tracking
            </span>
          </label>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Notes
        </label>
        <textarea
          rows={4}
          placeholder="Additional notes about this product"
          value={formData.notes}
          onChange={(e) => handleInputChange('notes', e.target.value)}
          className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Weight (kg)
          </label>
          <Input
            type="number"
            placeholder="0.00"
            value={formData.weight}
            onChange={(e) => handleInputChange('weight', e.target.value)}
            step="0.01"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Dimensions (L x W x H cm)
          </label>
          <Input
            type="text"
            placeholder="e.g., 10 x 5 x 3"
            value={formData.dimensions}
            onChange={(e) => handleInputChange('dimensions', e.target.value)}
          />
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'basic':
        return renderBasicInformation();
      case 'inventory':
        return renderInventoryDetails();
      case 'pricing':
        return renderPricing();
      case 'additional':
        return renderAdditionalData();
      default:
        return renderBasicInformation();
    }
  };

  return (
    <div className="bg-surface rounded-lg border border-border">
      {/* Tab Navigation */}
      <div className="border-b border-border">
        <nav className="flex space-x-8 px-6" aria-label="Tabs">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200
                ${activeTab === tab.id
                  ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-secondary-300'
                }
              `}
            >
              <Icon name={tab.icon} size={16} className="mr-2" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="p-6">
        {renderTabContent()}
      </div>

      {/* Form Actions */}
      <div className="border-t border-border px-6 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={onCancel}>
              Cancel
            </Button>
            <Button variant="outline">
              Save as Draft
            </Button>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <Icon name="Download" size={16} className="mr-2" />
              Import CSV
            </Button>
            <Button variant="primary" onClick={onSave}>
              <Icon name="Save" size={16} className="mr-2" />
              {isEditing ? 'Update Product' : 'Save Product'}
            </Button>
          </div>
        </div>
      </div>

      {/* Barcode Scanner Modal */}
      {showBarcodeScanner && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-surface rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-text-primary">
                Scan Barcode
              </h3>
              <Button
                variant="ghost"
                onClick={() => setShowBarcodeScanner(false)}
              >
                <Icon name="X" size={20} />
              </Button>
            </div>
            <div className="bg-secondary-100 rounded-lg p-8 text-center">
              <Icon name="Scan" size={64} className="mx-auto text-text-quaternary mb-4" />
              <p className="text-text-secondary mb-4">
                Position the barcode within the camera frame
              </p>
              <div className="space-y-3">
                <Button
                  variant="primary"
                  onClick={() => handleBarcodeScanned('1234567890123')}
                  className="w-full"
                >
                  Simulate Scan (Demo)
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowBarcodeScanner(false)}
                  className="w-full"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductForm;