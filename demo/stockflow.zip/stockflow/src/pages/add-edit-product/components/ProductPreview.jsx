import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const ProductPreview = ({ formData }) => {
  const getStockStatus = () => {
    const current = parseInt(formData.currentStock) || 0;
    const reorder = parseInt(formData.reorderPoint) || 0;
    
    if (current === 0) return { status: 'Out of Stock', color: 'text-error', bg: 'bg-error-50' };
    if (current <= reorder) return { status: 'Low Stock', color: 'text-warning', bg: 'bg-warning-50' };
    return { status: 'In Stock', color: 'text-success', bg: 'bg-success-50' };
  };

  const calculateProfitMargin = () => {
    const cost = parseFloat(formData.costPrice) || 0;
    const selling = parseFloat(formData.sellingPrice) || 0;
    
    if (cost === 0 || selling === 0) return 0;
    return (((selling - cost) / cost) * 100).toFixed(2);
  };

  const stockStatus = getStockStatus();
  const profitMargin = calculateProfitMargin();

  return (
    <div className="space-y-6">
      {/* Product Preview Card */}
      <div className="bg-surface rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4 flex items-center">
          <Icon name="Eye" size={20} className="mr-2" />
          Product Preview
        </h3>
        
        <div className="space-y-4">
          {/* Product Image */}
          <div className="flex justify-center">
            <div className="w-32 h-32 bg-secondary-100 rounded-lg overflow-hidden">
              {formData.image ? (
                <Image
                  src={formData.image}
                  alt={formData.name || 'Product preview'}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Icon name="Package" size={32} className="text-text-quaternary" />
                </div>
              )}
            </div>
          </div>

          {/* Product Details */}
          <div className="space-y-3">
            <div>
              <h4 className="font-medium text-text-primary">
                {formData.name || 'Product Name'}
              </h4>
              <p className="text-sm text-text-secondary">
                SKU: {formData.sku || 'Not specified'}
              </p>
            </div>

            {formData.description && (
              <p className="text-sm text-text-secondary line-clamp-3">
                {formData.description}
              </p>
            )}

            {/* Category & Location */}
            <div className="flex flex-wrap gap-2">
              {formData.category && (
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary-100 text-primary-700">
                  {formData.category}
                </span>
              )}
              {formData.location && (
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary-100 text-secondary-700">
                  <Icon name="MapPin" size={12} className="mr-1" />
                  {formData.location}
                </span>
              )}
            </div>

            {/* Stock Status */}
            <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${stockStatus.bg} ${stockStatus.color}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${stockStatus.color.replace('text-', 'bg-')}`} />
              {stockStatus.status}
            </div>

            {/* Pricing */}
            {(formData.costPrice || formData.sellingPrice) && (
              <div className="bg-secondary-50 p-3 rounded-lg">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {formData.costPrice && (
                    <div>
                      <span className="text-text-secondary">Cost:</span>
                      <span className="float-right font-medium">${formData.costPrice}</span>
                    </div>
                  )}
                  {formData.sellingPrice && (
                    <div>
                      <span className="text-text-secondary">Price:</span>
                      <span className="float-right font-medium">${formData.sellingPrice}</span>
                    </div>
                  )}
                  {profitMargin > 0 && (
                    <div className="col-span-2 border-t border-border pt-2">
                      <span className="text-text-secondary">Margin:</span>
                      <span className="float-right font-medium text-success">{profitMargin}%</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Stock Information */}
            {(formData.currentStock || formData.reorderPoint) && (
              <div className="space-y-2">
                {formData.currentStock && (
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">Current Stock:</span>
                    <span className="font-medium">{formData.currentStock}</span>
                  </div>
                )}
                {formData.reorderPoint && (
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">Reorder Point:</span>
                    <span className="font-medium">{formData.reorderPoint}</span>
                  </div>
                )}
              </div>
            )}

            {/* Additional Info */}
            {(formData.barcode || formData.weight || formData.dimensions) && (
              <div className="border-t border-border pt-3 space-y-2">
                {formData.barcode && (
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">Barcode:</span>
                    <span className="font-mono text-xs">{formData.barcode}</span>
                  </div>
                )}
                {formData.weight && (
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">Weight:</span>
                    <span className="font-medium">{formData.weight} kg</span>
                  </div>
                )}
                {formData.dimensions && (
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">Dimensions:</span>
                    <span className="font-medium">{formData.dimensions} cm</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="bg-surface rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4 flex items-center">
          <Icon name="BarChart3" size={20} className="mr-2" />
          Quick Stats
        </h3>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-primary-50 rounded-lg">
            <div className="text-2xl font-bold text-primary">
              {formData.currentStock || 0}
            </div>
            <div className="text-xs text-text-secondary">Current Stock</div>
          </div>
          
          <div className="text-center p-3 bg-success-50 rounded-lg">
            <div className="text-2xl font-bold text-success">
              ${formData.sellingPrice || '0.00'}
            </div>
            <div className="text-xs text-text-secondary">Selling Price</div>
          </div>
          
          <div className="text-center p-3 bg-warning-50 rounded-lg">
            <div className="text-2xl font-bold text-warning">
              {formData.reorderPoint || 0}
            </div>
            <div className="text-xs text-text-secondary">Reorder Point</div>
          </div>
          
          <div className="text-center p-3 bg-accent-50 rounded-lg">
            <div className="text-2xl font-bold text-accent">
              {profitMargin}%
            </div>
            <div className="text-xs text-text-secondary">Profit Margin</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductPreview;