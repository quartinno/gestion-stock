import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HelpPanel = ({ activeTab }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const helpContent = {
    basic: {
      title: 'Basic Information Help',
      sections: [
        {
          title: 'Product Name',
          content: 'Enter a clear, descriptive name for your product. This will be displayed to customers and used in search results.'
        },
        {
          title: 'SKU (Stock Keeping Unit)',
          content: 'A unique identifier for your product. Use a consistent naming convention like CATEGORY-BRAND-MODEL-SIZE.'
        },
        {
          title: 'Description',
          content: 'Provide detailed information about the product features, specifications, and benefits.'
        },
        {
          title: 'Category & Subcategory',
          content: 'Organize your products into logical categories for better inventory management and reporting.'
        },
        {
          title: 'Product Image',
          content: 'Upload high-quality images (PNG, JPG, GIF) up to 10MB. Good product images improve identification and customer experience.'
        }
      ]
    },
    inventory: {
      title: 'Inventory Management Help',
      sections: [
        {
          title: 'Current Stock',
          content: 'Enter the actual quantity available in your inventory. This number will be updated automatically as sales and purchases occur.'
        },
        {
          title: 'Reorder Point',
          content: 'Set the minimum stock level that triggers a reorder alert. Consider lead times and demand patterns when setting this value.'
        },
        {
          title: 'Supplier',
          content: 'Select the primary supplier for this product. This helps with purchase order generation and supplier management.'
        },
        {
          title: 'Location',
          content: 'Specify where the product is stored. This is essential for multi-location inventory tracking.'
        },
        {
          title: 'Unit of Measure',
          content: 'Choose the unit used for counting this product (pieces, kg, liters, etc.). This affects how quantities are displayed and calculated.'
        }
      ]
    },
    pricing: {
      title: 'Pricing Strategy Help',
      sections: [
        {
          title: 'Cost Price',
          content: 'Enter the actual cost you pay for this product, including shipping and handling. This is used for profit calculations.'
        },
        {
          title: 'Selling Price',
          content: 'Set the price at which you sell this product. Consider market conditions, competition, and desired profit margins.'
        },
        {
          title: 'Tax Category',
          content: 'Select the appropriate tax rate for this product based on local tax regulations and product type.'
        },
        {
          title: 'Profit Margin',
          content: 'This is calculated automatically based on cost and selling price. Monitor this to ensure healthy profitability.'
        }
      ]
    },
    additional: {
      title: 'Additional Data Help',
      sections: [
        {
          title: 'Barcode',
          content: 'Enter the product barcode or use the scanner to capture it. Barcodes speed up inventory operations and reduce errors.'
        },
        {
          title: 'Serial Number Tracking',
          content: 'Enable this for high-value items that need individual tracking. Each unit will have a unique serial number.'
        },
        {
          title: 'Batch Tracking',
          content: 'Use for products with expiration dates or manufacturing batches. Helps with quality control and recalls.'
        },
        {
          title: 'Physical Attributes',
          content: 'Record weight and dimensions for shipping calculations and storage planning.'
        }
      ]
    }
  };

  const tips = [
    {
      icon: 'Lightbulb',
      title: 'Pro Tip',
      content: 'Use consistent naming conventions for SKUs to make inventory management easier.'
    },
    {
      icon: 'AlertCircle',
      title: 'Important',
      content: 'Always double-check stock quantities before saving to avoid inventory discrepancies.'
    },
    {
      icon: 'TrendingUp',
      title: 'Best Practice',
      content: 'Set reorder points based on average sales velocity and supplier lead times.'
    }
  ];

  const currentHelp = helpContent[activeTab] || helpContent.basic;

  return (
    <div className="space-y-6">
      {/* Help Content */}
      <div className="bg-surface rounded-lg border border-border">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h3 className="text-lg font-semibold text-text-primary flex items-center">
            <Icon name="HelpCircle" size={20} className="mr-2" />
            {currentHelp.title}
          </h3>
          <Button
            variant="ghost"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="lg:hidden"
          >
            <Icon name={isCollapsed ? "ChevronDown" : "ChevronUp"} size={16} />
          </Button>
        </div>
        
        {!isCollapsed && (
          <div className="p-4 space-y-4">
            {currentHelp.sections.map((section, index) => (
              <div key={index} className="space-y-2">
                <h4 className="font-medium text-text-primary text-sm">
                  {section.title}
                </h4>
                <p className="text-sm text-text-secondary leading-relaxed">
                  {section.content}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Tips & Best Practices */}
      <div className="bg-surface rounded-lg border border-border p-4">
        <h3 className="text-lg font-semibold text-text-primary mb-4 flex items-center">
          <Icon name="Star" size={20} className="mr-2" />
          Tips & Best Practices
        </h3>
        
        <div className="space-y-3">
          {tips.map((tip, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-secondary-50 rounded-lg">
              <Icon 
                name={tip.icon} 
                size={16} 
                className="text-primary flex-shrink-0 mt-0.5" 
              />
              <div>
                <h4 className="font-medium text-text-primary text-sm">
                  {tip.title}
                </h4>
                <p className="text-sm text-text-secondary mt-1">
                  {tip.content}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-surface rounded-lg border border-border p-4">
        <h3 className="text-lg font-semibold text-text-primary mb-4 flex items-center">
          <Icon name="Zap" size={20} className="mr-2" />
          Quick Actions
        </h3>
        
        <div className="space-y-2">
          <Button variant="outline" className="w-full justify-start">
            <Icon name="Download" size={16} className="mr-2" />
            Download CSV Template
          </Button>
          <Button variant="outline" className="w-full justify-start">
            <Icon name="Upload" size={16} className="mr-2" />
            Bulk Import Products
          </Button>
          <Button variant="outline" className="w-full justify-start">
            <Icon name="Copy" size={16} className="mr-2" />
            Duplicate Product
          </Button>
          <Button variant="outline" className="w-full justify-start">
            <Icon name="FileText" size={16} className="mr-2" />
            View Product History
          </Button>
        </div>
      </div>

      {/* Contact Support */}
      <div className="bg-primary-50 rounded-lg border border-primary-200 p-4">
        <div className="flex items-start space-x-3">
          <Icon name="MessageCircle" size={20} className="text-primary flex-shrink-0" />
          <div>
            <h4 className="font-medium text-primary mb-1">
              Need Help?
            </h4>
            <p className="text-sm text-primary-700 mb-3">
              Our support team is here to help you with any questions about product management.
            </p>
            <Button variant="primary" size="sm">
              Contact Support
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HelpPanel;