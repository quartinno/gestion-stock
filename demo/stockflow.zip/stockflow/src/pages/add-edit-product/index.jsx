import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Sidebar from '../../components/ui/Sidebar';
import Header from '../../components/ui/Header';
import MobileNavigation from '../../components/ui/MobileNavigation';
import ProductForm from './components/ProductForm';
import ProductPreview from './components/ProductPreview';
import HelpPanel from './components/HelpPanel';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const AddEditProduct = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState('basic');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [showExitConfirmation, setShowExitConfirmation] = useState(false);
  const [isAutoSaving, setIsAutoSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState(null);

  // Check if we're editing an existing product
  const isEditing = location.state?.product || false;
  const existingProduct = location.state?.product || null;

  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    description: '',
    category: '',
    subcategory: '',
    image: '',
    currentStock: '',
    reorderPoint: '',
    supplier: '',
    location: '',
    unitOfMeasure: '',
    maxStock: '',
    costPrice: '',
    sellingPrice: '',
    taxCategory: '',
    profitMargin: '',
    barcode: '',
    serialTracking: false,
    batchTracking: false,
    notes: '',
    weight: '',
    dimensions: '',
    ...existingProduct
  });

  const [errors, setErrors] = useState({});

  // Auto-save functionality
  useEffect(() => {
    if (hasUnsavedChanges) {
      const autoSaveTimer = setTimeout(() => {
        handleAutoSave();
      }, 30000); // Auto-save every 30 seconds

      return () => clearTimeout(autoSaveTimer);
    }
  }, [formData, hasUnsavedChanges]);

  // Track form changes
  useEffect(() => {
    const hasChanges = Object.keys(formData).some(key => {
      if (existingProduct) {
        return formData[key] !== existingProduct[key];
      }
      return formData[key] !== '';
    });
    setHasUnsavedChanges(hasChanges);
  }, [formData, existingProduct]);

  // Calculate profit margin when prices change
  useEffect(() => {
    const cost = parseFloat(formData.costPrice) || 0;
    const selling = parseFloat(formData.sellingPrice) || 0;
    
    if (cost > 0 && selling > 0) {
      const margin = (((selling - cost) / cost) * 100).toFixed(2);
      setFormData(prev => ({
        ...prev,
        profitMargin: margin
      }));
    }
  }, [formData.costPrice, formData.sellingPrice]);

  // Prevent navigation with unsaved changes
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges]);

  const validateForm = () => {
    const newErrors = {};

    // Required fields validation
    if (!formData.name.trim()) {
      newErrors.name = 'Product name is required';
    }

    if (!formData.sku.trim()) {
      newErrors.sku = 'SKU is required';
    }

    if (!formData.category) {
      newErrors.category = 'Category is required';
    }

    if (!formData.currentStock || formData.currentStock < 0) {
      newErrors.currentStock = 'Valid current stock is required';
    }

    if (!formData.reorderPoint || formData.reorderPoint < 0) {
      newErrors.reorderPoint = 'Valid reorder point is required';
    }

    if (!formData.location) {
      newErrors.location = 'Location is required';
    }

    if (!formData.costPrice || formData.costPrice <= 0) {
      newErrors.costPrice = 'Valid cost price is required';
    }

    if (!formData.sellingPrice || formData.sellingPrice <= 0) {
      newErrors.sellingPrice = 'Valid selling price is required';
    }

    // Business logic validation
    if (formData.costPrice && formData.sellingPrice) {
      const cost = parseFloat(formData.costPrice);
      const selling = parseFloat(formData.sellingPrice);
      
      if (selling <= cost) {
        newErrors.sellingPrice = 'Selling price must be higher than cost price';
      }
    }

    if (formData.currentStock && formData.reorderPoint) {
      const current = parseInt(formData.currentStock);
      const reorder = parseInt(formData.reorderPoint);
      
      if (reorder >= current && current > 0) {
        newErrors.reorderPoint = 'Reorder point should be less than current stock';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAutoSave = async () => {
    if (!hasUnsavedChanges) return;

    setIsAutoSaving(true);
    
    // Simulate auto-save API call
    setTimeout(() => {
      setLastSaved(new Date());
      setIsAutoSaving(false);
      console.log('Auto-saved draft:', formData);
    }, 1000);
  };

  const handleSave = async () => {
    if (!validateForm()) {
      // Find the first tab with errors
      const errorFields = Object.keys(errors);
      if (errorFields.includes('name') || errorFields.includes('sku') || errorFields.includes('category')) {
        setActiveTab('basic');
      } else if (errorFields.includes('currentStock') || errorFields.includes('reorderPoint') || errorFields.includes('location')) {
        setActiveTab('inventory');
      } else if (errorFields.includes('costPrice') || errorFields.includes('sellingPrice')) {
        setActiveTab('pricing');
      }
      return;
    }

    try {
      // Simulate API call
      console.log(isEditing ? 'Updating product:' : 'Creating product:', formData);
      
      // Show success message and navigate
      setTimeout(() => {
        setHasUnsavedChanges(false);
        navigate('/product-catalog', {
          state: {
            message: isEditing ? 'Product updated successfully!' : 'Product created successfully!',
            type: 'success'
          }
        });
      }, 1000);
    } catch (error) {
      console.error('Error saving product:', error);
    }
  };

  const handleCancel = () => {
    if (hasUnsavedChanges) {
      setShowExitConfirmation(true);
    } else {
      navigate('/product-catalog');
    }
  };

  const handleConfirmExit = () => {
    setHasUnsavedChanges(false);
    setShowExitConfirmation(false);
    navigate('/product-catalog');
  };

  const handleCancelExit = () => {
    setShowExitConfirmation(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Header />
      <MobileNavigation />
      
      <main className="lg:ml-sidebar pt-header pb-20 lg:pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-text-primary font-heading">
                  {isEditing ? 'Edit Product' : 'Add New Product'}
                </h1>
                <p className="text-text-secondary mt-1">
                  {isEditing 
                    ? 'Update product information and inventory details'
                    : 'Create a new product with complete information and inventory details'
                  }
                </p>
              </div>
              
              {/* Auto-save Status */}
              <div className="hidden lg:flex items-center space-x-4">
                {isAutoSaving && (
                  <div className="flex items-center text-sm text-text-secondary">
                    <Icon name="Loader2" size={16} className="mr-2 animate-spin" />
                    Saving draft...
                  </div>
                )}
                {lastSaved && !isAutoSaving && (
                  <div className="flex items-center text-sm text-text-secondary">
                    <Icon name="Check" size={16} className="mr-2 text-success" />
                    Last saved: {lastSaved.toLocaleTimeString()}
                  </div>
                )}
                {hasUnsavedChanges && !isAutoSaving && (
                  <div className="flex items-center text-sm text-warning">
                    <Icon name="AlertCircle" size={16} className="mr-2" />
                    Unsaved changes
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
            {/* Form Section */}
            <div className="xl:col-span-8">
              <ProductForm
                formData={formData}
                setFormData={setFormData}
                errors={errors}
                setErrors={setErrors}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                onSave={handleSave}
                onCancel={handleCancel}
                isEditing={isEditing}
              />
            </div>

            {/* Preview & Help Section */}
            <div className="xl:col-span-4 space-y-6">
              {/* Mobile Auto-save Status */}
              <div className="lg:hidden">
                {isAutoSaving && (
                  <div className="flex items-center justify-center p-3 bg-secondary-50 rounded-lg">
                    <Icon name="Loader2" size={16} className="mr-2 animate-spin" />
                    <span className="text-sm text-text-secondary">Saving draft...</span>
                  </div>
                )}
                {lastSaved && !isAutoSaving && (
                  <div className="flex items-center justify-center p-3 bg-success-50 rounded-lg">
                    <Icon name="Check" size={16} className="mr-2 text-success" />
                    <span className="text-sm text-success">
                      Last saved: {lastSaved.toLocaleTimeString()}
                    </span>
                  </div>
                )}
                {hasUnsavedChanges && !isAutoSaving && (
                  <div className="flex items-center justify-center p-3 bg-warning-50 rounded-lg">
                    <Icon name="AlertCircle" size={16} className="mr-2 text-warning" />
                    <span className="text-sm text-warning">Unsaved changes</span>
                  </div>
                )}
              </div>

              <ProductPreview formData={formData} />
              <HelpPanel activeTab={activeTab} />
            </div>
          </div>
        </div>
      </main>

      {/* Exit Confirmation Modal */}
      {showExitConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-surface rounded-lg max-w-md w-full p-6">
            <div className="flex items-center mb-4">
              <Icon name="AlertTriangle" size={24} className="text-warning mr-3" />
              <h3 className="text-lg font-semibold text-text-primary">
                Unsaved Changes
              </h3>
            </div>
            
            <p className="text-text-secondary mb-6">
              You have unsaved changes that will be lost if you leave this page. 
              Are you sure you want to continue?
            </p>
            
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={handleCancelExit}>
                Stay on Page
              </Button>
              <Button variant="danger" onClick={handleConfirmExit}>
                Leave Without Saving
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AddEditProduct;