import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import MetricCard from './components/MetricCard';
import StockLevelChart from './components/StockLevelChart';
import ActivityFeed from './components/ActivityFeed';
import QuickActionTile from './components/QuickActionTile';
import Icon from '../../components/AppIcon';

const Dashboard = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Mock real-time data simulation
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);

    // Simulate real-time updates
    const updateInterval = setInterval(() => {
      setLastUpdated(new Date());
    }, 30000); // Update every 30 seconds

    return () => {
      clearTimeout(timer);
      clearInterval(updateInterval);
    };
  }, []);

  const metricsData = [
    {
      title: "Total Products",
      value: "1,247",
      change: "+12%",
      changeType: "positive",
      icon: "Package",
      iconColor: "bg-primary",
      onClick: () => navigate('/product-catalog')
    },
    {
      title: "Low Stock Alerts",
      value: "23",
      change: "+5",
      changeType: "negative",
      icon: "AlertTriangle",
      iconColor: "bg-warning",
      onClick: () => navigate('/stock-movements')
    },
    {
      title: "Recent Movements",
      value: "156",
      change: "+8%",
      changeType: "positive",
      icon: "TrendingUp",
      iconColor: "bg-success",
      onClick: () => navigate('/stock-movements')
    },
    {
      title: "Inventory Value",
      value: "$2.4M",
      change: "+15%",
      changeType: "positive",
      icon: "DollarSign",
      iconColor: "bg-accent"
    }
  ];

  const quickActions = [
    {
      title: "Add Product",
      description: "Add new products to your inventory",
      icon: "Plus",
      iconColor: "bg-primary",
      onClick: () => navigate('/add-edit-product')
    },
    {
      title: "Create Purchase Order",
      description: "Generate new purchase orders",
      icon: "ShoppingCart",
      iconColor: "bg-success",
      onClick: () => navigate('/purchase-orders')
    },
    {
      title: "Stock Adjustment",
      description: "Adjust inventory levels and reconcile",
      icon: "Edit",
      iconColor: "bg-warning",
      onClick: () => navigate('/stock-movements')
    },
    {
      title: "Generate Report",
      description: "Create detailed inventory reports",
      icon: "FileText",
      iconColor: "bg-accent",
      onClick: () => navigate('/reports')
    }
  ];

  const handleRefresh = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setLastUpdated(new Date());
    }, 1000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pt-header pl-0 lg:pl-sidebar">
        <div className="p-6 lg:p-8">
          <div className="flex items-center justify-center h-96">
            <div className="flex flex-col items-center space-y-4">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              <p className="text-text-secondary">Loading dashboard...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-header pl-0 lg:pl-sidebar pb-16 lg:pb-0">
      <div className="p-4 lg:p-8">
        {/* Header Section */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-text-primary mb-2">
              Dashboard Overview
            </h1>
            <p className="text-text-secondary">
              Monitor your inventory performance and key metrics
            </p>
          </div>
          <div className="flex items-center space-x-4 mt-4 lg:mt-0">
            <div className="flex items-center space-x-2 text-sm text-text-secondary">
              <Icon name="Clock" size={16} />
              <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
            </div>
            <button
              onClick={handleRefresh}
              className="flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-700 transition-colors duration-200"
            >
              <Icon name="RefreshCw" size={16} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {metricsData.map((metric, index) => (
            <MetricCard
              key={index}
              title={metric.title}
              value={metric.value}
              change={metric.change}
              changeType={metric.changeType}
              icon={metric.icon}
              iconColor={metric.iconColor}
              onClick={metric.onClick}
            />
          ))}
        </div>

        {/* Chart and Activity Section */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 mb-8">
          <div className="xl:col-span-8">
            <StockLevelChart />
          </div>
          <div className="xl:col-span-4">
            <ActivityFeed />
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-text-primary mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {quickActions.map((action, index) => (
              <QuickActionTile
                key={index}
                title={action.title}
                description={action.description}
                icon={action.icon}
                iconColor={action.iconColor}
                onClick={action.onClick}
              />
            ))}
          </div>
        </div>

        {/* Status Indicators */}
        <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
          <h2 className="text-lg font-semibold text-text-primary mb-4">System Status</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
              <div>
                <p className="text-sm font-medium text-text-primary">Real-time Sync</p>
                <p className="text-xs text-text-secondary">Connected</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-success rounded-full"></div>
              <div>
                <p className="text-sm font-medium text-text-primary">Database</p>
                <p className="text-xs text-text-secondary">Operational</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-warning rounded-full"></div>
              <div>
                <p className="text-sm font-medium text-text-primary">Backup</p>
                <p className="text-xs text-text-secondary">Scheduled in 2h</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;