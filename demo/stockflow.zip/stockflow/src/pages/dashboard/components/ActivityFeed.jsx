import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const ActivityFeed = () => {
  const [filter, setFilter] = useState('all');

  const activities = [
    {
      id: 1,
      type: 'stock_movement',
      title: 'Stock Added',
      description: 'iPhone 14 Pro - 25 units added to inventory',
      timestamp: new Date(Date.now() - 300000),
      icon: 'Plus',
      iconColor: 'bg-success'
    },
    {
      id: 2,
      type: 'purchase_order',
      title: 'Purchase Order Created',
      description: 'PO #12345 for Samsung Electronics - $15,000',
      timestamp: new Date(Date.now() - 900000),
      icon: 'ShoppingCart',
      iconColor: 'bg-primary'
    },
    {
      id: 3,
      type: 'alert',
      title: 'Low Stock Alert',
      description: 'MacBook Air M2 - Only 3 units remaining',
      timestamp: new Date(Date.now() - 1800000),
      icon: 'AlertTriangle',
      iconColor: 'bg-warning'
    },
    {
      id: 4,
      type: 'stock_movement',
      title: 'Stock Sold',
      description: 'Dell XPS 13 - 2 units sold',
      timestamp: new Date(Date.now() - 3600000),
      icon: 'Minus',
      iconColor: 'bg-error'
    },
    {
      id: 5,
      type: 'purchase_order',
      title: 'Purchase Order Received',
      description: 'PO #12340 delivered - 50 units of wireless headphones',
      timestamp: new Date(Date.now() - 7200000),
      icon: 'Package',
      iconColor: 'bg-accent'
    },
    {
      id: 6,
      type: 'alert',
      title: 'Stock Adjustment',
      description: 'Inventory count adjusted for Office Supplies category',
      timestamp: new Date(Date.now() - 10800000),
      icon: 'Edit',
      iconColor: 'bg-secondary-600'
    }
  ];

  const filterOptions = [
    { value: 'all', label: 'All Activities' },
    { value: 'stock_movement', label: 'Stock Movements' },
    { value: 'purchase_order', label: 'Purchase Orders' },
    { value: 'alert', label: 'Alerts' }
  ];

  const filteredActivities = filter === 'all' 
    ? activities 
    : activities.filter(activity => activity.type === filter);

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (minutes < 60) {
      return `${minutes}m ago`;
    } else {
      return `${hours}h ago`;
    }
  };

  return (
    <div className="bg-surface border border-border rounded-lg p-6 shadow-card">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-text-primary">Recent Activity</h2>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="text-sm border border-border rounded-lg px-3 py-1 bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
        >
          {filterOptions.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto scrollbar-hide">
        {filteredActivities.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-secondary-50 transition-colors duration-200">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${activity.iconColor}`}>
              <Icon name={activity.icon} size={16} color="white" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-medium text-text-primary">{activity.title}</h3>
              <p className="text-sm text-text-secondary mt-1 line-clamp-2">{activity.description}</p>
              <p className="text-xs text-text-quaternary mt-2">{formatTimeAgo(activity.timestamp)}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-border">
        <button className="w-full text-sm text-primary hover:text-primary-700 font-medium transition-colors duration-200">
          View All Activities
        </button>
      </div>
    </div>
  );
};

export default ActivityFeed;