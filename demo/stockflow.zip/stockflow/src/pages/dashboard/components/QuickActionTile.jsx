import React from 'react';
import Icon from '../../../components/AppIcon';

const QuickActionTile = ({ title, description, icon, iconColor, onClick }) => {
  return (
    <button
      onClick={onClick}
      className="bg-surface border border-border rounded-lg p-6 shadow-card hover:shadow-modal hover:border-primary-200 transition-all duration-200 text-left w-full group"
    >
      <div className="flex items-center space-x-4">
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${iconColor} group-hover:scale-105 transition-transform duration-200`}>
          <Icon name={icon} size={24} color="white" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-text-primary group-hover:text-primary transition-colors duration-200">
            {title}
          </h3>
          <p className="text-sm text-text-secondary mt-1">{description}</p>
        </div>
        <Icon name="ArrowRight" size={20} className="text-text-quaternary group-hover:text-primary transition-colors duration-200" />
      </div>
    </button>
  );
};

export default QuickActionTile;