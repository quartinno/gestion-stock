import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import SecurityBadges from './components/SecurityBadges';

const Login = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already authenticated
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (isAuthenticated === 'true') {
      navigate('/dashboard');
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-background to-accent-50 flex flex-col">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      
      {/* Main Content */}
      <div className="relative flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md">
          {/* Login Form */}
          <LoginForm />
          
          {/* Security Badges */}
          <SecurityBadges />
        </div>
      </div>
      
      {/* Footer */}
      <footer className="relative py-6 px-4 text-center border-t border-border bg-surface-secondary">
        <div className="max-w-4xl mx-auto">
          <p className="text-sm text-text-secondary mb-2">
            © {new Date().getFullYear()} StockFlow. All rights reserved.
          </p>
          <div className="flex items-center justify-center space-x-6 text-xs text-text-tertiary">
            <a href="#" className="hover:text-primary transition-colors duration-200">
              Privacy Policy
            </a>
            <span>•</span>
            <a href="#" className="hover:text-primary transition-colors duration-200">
              Terms of Service
            </a>
            <span>•</span>
            <a href="#" className="hover:text-primary transition-colors duration-200">
              Support
            </a>
          </div>
        </div>
      </footer>
      
      {/* Custom Styles for Background Pattern */}
      <style jsx>{`
        .bg-grid-pattern {
          background-image: 
            linear-gradient(rgba(30, 58, 138, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(30, 58, 138, 0.1) 1px, transparent 1px);
          background-size: 20px 20px;
        }
      `}</style>
    </div>
  );
};

export default Login;