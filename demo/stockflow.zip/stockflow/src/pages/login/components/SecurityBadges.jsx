import React from 'react';
import Icon from '../../../components/AppIcon';

const SecurityBadges = () => {
  const securityFeatures = [
    {
      icon: 'Shield',
      title: 'SSL Encrypted',
      description: 'Your data is protected with 256-bit SSL encryption'
    },
    {
      icon: 'Lock',
      title: 'Secure Authentication',
      description: 'Multi-layer security protocols protect your account'
    },
    {
      icon: 'Database',
      title: 'Data Backup',
      description: 'Automatic backups ensure your inventory data is safe'
    }
  ];

  return (
    <div className="mt-8 space-y-4">
      <div className="text-center">
        <h3 className="text-sm font-medium text-text-primary mb-4">
          Your Security is Our Priority
        </h3>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {securityFeatures.map((feature, index) => (
          <div
            key={index}
            className="flex flex-col items-center text-center p-4 bg-surface-secondary rounded-lg border border-border"
          >
            <div className="flex items-center justify-center w-10 h-10 bg-success-100 rounded-full mb-3">
              <Icon name={feature.icon} size={20} className="text-success" />
            </div>
            <h4 className="text-sm font-medium text-text-primary mb-1">
              {feature.title}
            </h4>
            <p className="text-xs text-text-secondary leading-relaxed">
              {feature.description}
            </p>
          </div>
        ))}
      </div>
      
      {/* Trust Indicators */}
      <div className="flex items-center justify-center space-x-6 pt-4 border-t border-border">
        <div className="flex items-center space-x-2">
          <Icon name="Shield" size={16} className="text-success" />
          <span className="text-xs text-text-secondary">SSL Secured</span>
        </div>
        <div className="flex items-center space-x-2">
          <Icon name="Eye" size={16} className="text-primary" />
          <span className="text-xs text-text-secondary">Privacy Protected</span>
        </div>
        <div className="flex items-center space-x-2">
          <Icon name="Clock" size={16} className="text-accent" />
          <span className="text-xs text-text-secondary">24/7 Monitoring</span>
        </div>
      </div>
    </div>
  );
};

export default SecurityBadges;