import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const Breadcrumb = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const routeLabels = {
    '/dashboard': 'Dashboard',
    '/product-catalog': 'Product Catalog',
    '/add-edit-product': 'Add Product',
    '/stock-movements': 'Stock Movements',
    '/purchase-orders': 'Purchase Orders'
  };

  const generateBreadcrumbs = () => {
    const pathSegments = location.pathname.split('/').filter(segment => segment);
    const breadcrumbs = [{ label: 'Home', path: '/dashboard' }];

    let currentPath = '';
    pathSegments.forEach((segment, index) => {
      currentPath += `/${segment}`;
      const label = routeLabels[currentPath] || segment.charAt(0).toUpperCase() + segment.slice(1);
      
      if (currentPath !== '/dashboard') {
        breadcrumbs.push({
          label,
          path: currentPath,
          isLast: index === pathSegments.length - 1
        });
      }
    });

    return breadcrumbs;
  };

  const handleBreadcrumbClick = (path) => {
    navigate(path);
  };

  const breadcrumbs = generateBreadcrumbs();

  if (location.pathname === '/login' || breadcrumbs.length <= 1) {
    return null;
  }

  return (
    <nav className="flex items-center space-x-2 text-sm mb-6" aria-label="Breadcrumb">
      {breadcrumbs.map((crumb, index) => (
        <div key={crumb.path} className="flex items-center">
          {index > 0 && (
            <Icon 
              name="ChevronRight" 
              size={16} 
              className="mx-2 text-text-quaternary flex-shrink-0" 
            />
          )}
          <button
            onClick={() => handleBreadcrumbClick(crumb.path)}
            className={`
              transition-colors duration-200 hover:text-primary
              ${crumb.isLast 
                ? 'text-text-primary font-medium cursor-default' :'text-text-secondary hover:text-primary cursor-pointer'
              }
            `}
            disabled={crumb.isLast}
            aria-current={crumb.isLast ? 'page' : undefined}
          >
            {crumb.label}
          </button>
        </div>
      ))}
    </nav>
  );
};

export default Breadcrumb;