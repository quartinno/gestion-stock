import React, { useState, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const userMenuRef = useRef(null);
  const notificationRef = useRef(null);
  const location = useLocation();
  const navigate = useNavigate();

  const routeLabels = {
    '/dashboard': 'Dashboard',
    '/product-catalog': 'Product Catalog',
    '/add-edit-product': 'Add Product',
    '/stock-movements': 'Stock Movements',
    '/purchase-orders': 'Purchase Orders',
    '/login': 'Login'
  };

  const notifications = [
    {
      id: 1,
      title: 'Low Stock Alert',
      message: '5 products are running low on stock',
      type: 'warning',
      time: '2 minutes ago',
      unread: true
    },
    {
      id: 2,
      title: 'Purchase Order Approved',
      message: 'PO #12345 has been approved',
      type: 'success',
      time: '1 hour ago',
      unread: true
    },
    {
      id: 3,
      title: 'Stock Movement Recorded',
      message: 'New stock movement for Product ABC',
      type: 'info',
      time: '3 hours ago',
      unread: false
    }
  ];

  const unreadCount = notifications.filter(n => n.unread).length;

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setIsUserMenuOpen(false);
      }
      if (notificationRef.current && !notificationRef.current.contains(event.target)) {
        setIsNotificationOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const generateBreadcrumbs = () => {
    const pathSegments = location.pathname.split('/').filter(segment => segment);
    const breadcrumbs = [{ label: 'Home', path: '/dashboard' }];

    let currentPath = '';
    pathSegments.forEach((segment, index) => {
      currentPath += `/${segment}`;
      const label = routeLabels[currentPath] || segment.charAt(0).toUpperCase() + segment.slice(1);
      
      if (currentPath !== '/dashboard') {
        breadcrumbs.push({
          label,
          path: currentPath,
          isLast: index === pathSegments.length - 1
        });
      }
    });

    return breadcrumbs;
  };

  const handleBreadcrumbClick = (path) => {
    navigate(path);
  };

  const handleLogout = () => {
    navigate('/login');
    setIsUserMenuOpen(false);
  };

  const handleNotificationClick = (notification) => {
    console.log('Notification clicked:', notification);
    setIsNotificationOpen(false);
  };

  const breadcrumbs = generateBreadcrumbs();
  const currentPageTitle = routeLabels[location.pathname] || 'Page';

  if (location.pathname === '/login') {
    return null;
  }

  return (
    <header className="fixed top-0 right-0 left-0 lg:left-sidebar xl:left-sidebar z-header bg-surface border-b border-border">
      <div className="flex items-center justify-between h-header px-4 lg:px-6">
        <div className="flex items-center space-x-4 flex-1 min-w-0">
          <div className="lg:hidden">
            <h1 className="text-lg font-semibold text-text-primary font-heading truncate">
              {currentPageTitle}
            </h1>
          </div>
          
          <div className="hidden lg:block flex-1 min-w-0">
            <nav className="flex items-center space-x-2 text-sm">
              {breadcrumbs.map((crumb, index) => (
                <div key={crumb.path} className="flex items-center">
                  {index > 0 && (
                    <Icon 
                      name="ChevronRight" 
                      size={16} 
                      className="mx-2 text-text-quaternary flex-shrink-0" 
                    />
                  )}
                  <button
                    onClick={() => handleBreadcrumbClick(crumb.path)}
                    className={`
                      truncate transition-colors duration-200 hover:text-primary
                      ${crumb.isLast 
                        ? 'text-text-primary font-medium cursor-default' :'text-text-secondary hover:text-primary cursor-pointer'
                      }
                    `}
                    disabled={crumb.isLast}
                  >
                    {crumb.label}
                  </button>
                </div>
              ))}
            </nav>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {/* Search Button */}
          <Button
            variant="ghost"
            className="hidden md:flex"
            onClick={() => console.log('Search clicked')}
          >
            <Icon name="Search" size={18} />
          </Button>

          {/* Notifications */}
          <div className="relative" ref={notificationRef}>
            <Button
              variant="ghost"
              onClick={() => setIsNotificationOpen(!isNotificationOpen)}
              className="relative"
            >
              <Icon name="Bell" size={18} />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-error text-error-foreground text-xs rounded-full flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </Button>

            {isNotificationOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-surface border border-border rounded-lg shadow-dropdown z-50">
                <div className="p-4 border-b border-border">
                  <h3 className="text-sm font-semibold text-text-primary">Notifications</h3>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  {notifications.map((notification) => (
                    <button
                      key={notification.id}
                      onClick={() => handleNotificationClick(notification)}
                      className="w-full p-4 text-left hover:bg-secondary-50 border-b border-border last:border-b-0 transition-colors duration-200"
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`
                          w-2 h-2 rounded-full mt-2 flex-shrink-0
                          ${notification.type === 'warning' ? 'bg-warning' : ''}
                          ${notification.type === 'success' ? 'bg-success' : ''}
                          ${notification.type === 'info' ? 'bg-accent' : ''}
                        `} />
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium ${notification.unread ? 'text-text-primary' : 'text-text-secondary'}`}>
                            {notification.title}
                          </p>
                          <p className="text-xs text-text-secondary mt-1 line-clamp-2">
                            {notification.message}
                          </p>
                          <p className="text-xs text-text-quaternary mt-1">
                            {notification.time}
                          </p>
                        </div>
                        {notification.unread && (
                          <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0 mt-2" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
                <div className="p-3 border-t border-border">
                  <Button variant="ghost" className="w-full text-sm">
                    View All Notifications
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* User Menu */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              className="flex items-center space-x-2 p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-200"
            >
              <div className="w-8 h-8 bg-secondary-300 rounded-full flex items-center justify-center">
                <Icon name="User" size={16} color="var(--color-text-secondary)" />
              </div>
              <div className="hidden md:block text-left">
                <p className="text-sm font-medium text-text-primary">Admin User</p>
                <p className="text-xs text-text-secondary">Administrator</p>
              </div>
              <Icon 
                name="ChevronDown" 
                size={16} 
                className={`text-text-secondary transition-transform duration-200 ${isUserMenuOpen ? 'rotate-180' : ''}`}
              />
            </button>

            {isUserMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-surface border border-border rounded-lg shadow-dropdown z-50">
                <div className="p-2">
                  <button
                    onClick={() => {
                      console.log('Profile clicked');
                      setIsUserMenuOpen(false);
                    }}
                    className="w-full flex items-center px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-secondary-100 rounded-lg transition-colors duration-200"
                  >
                    <Icon name="User" size={16} className="mr-3" />
                    Profile
                  </button>
                  <button
                    onClick={() => {
                      console.log('Settings clicked');
                      setIsUserMenuOpen(false);
                    }}
                    className="w-full flex items-center px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-secondary-100 rounded-lg transition-colors duration-200"
                  >
                    <Icon name="Settings" size={16} className="mr-3" />
                    Settings
                  </button>
                  <div className="border-t border-border my-2" />
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center px-3 py-2 text-sm text-error hover:bg-error-50 rounded-lg transition-colors duration-200"
                  >
                    <Icon name="LogOut" size={16} className="mr-3" />
                    Logout
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;