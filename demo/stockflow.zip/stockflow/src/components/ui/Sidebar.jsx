import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const Sidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/dashboard',
      icon: 'LayoutDashboard',
      badge: null
    },
    {
      label: 'Products',
      icon: 'Package',
      children: [
        {
          label: 'Product Catalog',
          path: '/product-catalog',
          icon: 'Grid3X3'
        },
        {
          label: 'Add Product',
          path: '/add-edit-product',
          icon: 'Plus'
        }
      ]
    },
    {
      label: 'Inventory',
      path: '/stock-movements',
      icon: 'TrendingUp',
      badge: null
    },
    {
      label: 'Purchasing',
      path: '/purchase-orders',
      icon: 'ShoppingCart',
      badge: null
    },
    {
      label: 'Reports',
      path: '/reports',
      icon: 'FileText',
      badge: null
    }
  ];

  useEffect(() => {
    const savedCollapsed = localStorage.getItem('sidebar-collapsed');
    if (savedCollapsed !== null) {
      setIsCollapsed(JSON.parse(savedCollapsed));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('sidebar-collapsed', JSON.stringify(isCollapsed));
  }, [isCollapsed]);

  useEffect(() => {
    if (isMobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMobileOpen]);

  const toggleCollapsed = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleMobile = () => {
    setIsMobileOpen(!isMobileOpen);
  };

  const handleNavigation = (path) => {
    navigate(path);
    setIsMobileOpen(false);
  };

  const isActiveRoute = (path) => {
    return location.pathname === path;
  };

  const isParentActive = (children) => {
    return children.some(child => location.pathname === child.path);
  };

  const renderNavItem = (item, isChild = false) => {
    const hasChildren = item.children && item.children.length > 0;
    const isActive = item.path ? isActiveRoute(item.path) : isParentActive(item.children);
    
    if (hasChildren) {
      return (
        <div key={item.label} className="mb-1">
          <div className={`
            flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200
            ${isActive 
              ? 'bg-primary text-primary-foreground' 
              : 'text-text-secondary hover:bg-secondary-100 hover:text-text-primary'
            }
            ${isChild ? 'ml-4' : ''}
          `}>
            <Icon 
              name={item.icon} 
              size={20} 
              className={`${isCollapsed && !isChild ? 'mx-auto' : 'mr-3'} flex-shrink-0`}
            />
            {(!isCollapsed || isChild) && (
              <>
                <span className="flex-1">{item.label}</span>
                {item.badge && (
                  <span className="ml-2 px-2 py-1 text-xs bg-error text-error-foreground rounded-full">
                    {item.badge}
                  </span>
                )}
              </>
            )}
          </div>
          {(!isCollapsed || isChild) && (
            <div className="mt-1 space-y-1">
              {item.children.map(child => renderNavItem(child, true))}
            </div>
          )}
        </div>
      );
    }

    return (
      <button
        key={item.label}
        onClick={() => handleNavigation(item.path)}
        className={`
          w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200
          ${isActive 
            ? 'bg-primary text-primary-foreground' 
            : 'text-text-secondary hover:bg-secondary-100 hover:text-text-primary'
          }
          ${isChild ? 'ml-4' : ''}
        `}
      >
        <Icon 
          name={item.icon} 
          size={20} 
          className={`${isCollapsed && !isChild ? 'mx-auto' : 'mr-3'} flex-shrink-0`}
        />
        {(!isCollapsed || isChild) && (
          <>
            <span className="flex-1 text-left">{item.label}</span>
            {item.badge && (
              <span className="ml-2 px-2 py-1 text-xs bg-error text-error-foreground rounded-full">
                {item.badge}
              </span>
            )}
          </>
        )}
      </button>
    );
  };

  const sidebarContent = (
    <>
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className={`flex items-center ${isCollapsed ? 'justify-center' : ''}`}>
          <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
            <Icon name="Package" size={20} color="white" />
          </div>
          {!isCollapsed && (
            <div className="ml-3">
              <h1 className="text-lg font-semibold text-text-primary font-heading">
                StockFlow
              </h1>
            </div>
          )}
        </div>
        <button
          onClick={toggleCollapsed}
          className="hidden lg:flex items-center justify-center w-8 h-8 text-text-secondary hover:text-text-primary hover:bg-secondary-100 rounded-lg transition-colors duration-200"
        >
          <Icon name={isCollapsed ? "ChevronRight" : "ChevronLeft"} size={16} />
        </button>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto scrollbar-hide">
        {navigationItems.map(item => renderNavItem(item))}
      </nav>

      <div className="p-4 border-t border-border">
        <div className={`flex items-center ${isCollapsed ? 'justify-center' : ''}`}>
          <div className="w-8 h-8 bg-secondary-300 rounded-full flex items-center justify-center">
            <Icon name="User" size={16} color="var(--color-text-secondary)" />
          </div>
          {!isCollapsed && (
            <div className="ml-3 flex-1 min-w-0">
              <p className="text-sm font-medium text-text-primary truncate">Admin User</p>
              <p className="text-xs text-text-secondary truncate">admin@stockflow.com</p>
            </div>
          )}
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-drawer lg:hidden"
          onClick={toggleMobile}
        />
      )}

      {/* Mobile Hamburger Button */}
      <button
        onClick={toggleMobile}
        className="fixed top-4 left-4 z-header lg:hidden flex items-center justify-center w-10 h-10 bg-surface text-text-primary rounded-lg shadow-card"
      >
        <Icon name="Menu" size={20} />
      </button>

      {/* Desktop Sidebar */}
      <aside className={`
        hidden lg:flex lg:fixed lg:inset-y-0 lg:left-0 lg:z-sidebar
        flex-col bg-surface border-r border-border sidebar-transition
        ${isCollapsed ? 'lg:w-sidebar-collapsed' : 'lg:w-sidebar'}
      `}>
        {sidebarContent}
      </aside>

      {/* Mobile Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-drawer lg:hidden
        flex flex-col w-sidebar bg-surface border-r border-border
        transform transition-transform duration-300 ease-out
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
              <Icon name="Package" size={20} color="white" />
            </div>
            <div className="ml-3">
              <h1 className="text-lg font-semibold text-text-primary font-heading">
                StockFlow
              </h1>
            </div>
          </div>
          <button
            onClick={toggleMobile}
            className="flex items-center justify-center w-8 h-8 text-text-secondary hover:text-text-primary hover:bg-secondary-100 rounded-lg transition-colors duration-200"
          >
            <Icon name="X" size={16} />
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto scrollbar-hide">
          {navigationItems.map(item => renderNavItem(item))}
        </nav>

        <div className="p-4 border-t border-border">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-secondary-300 rounded-full flex items-center justify-center">
              <Icon name="User" size={16} color="var(--color-text-secondary)" />
            </div>
            <div className="ml-3 flex-1 min-w-0">
              <p className="text-sm font-medium text-text-primary truncate">Admin User</p>
              <p className="text-xs text-text-secondary truncate">admin@stockflow.com</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;