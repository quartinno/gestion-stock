import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const MobileNavigation = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const location = useLocation();
  const navigate = useNavigate();

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/dashboard',
      icon: 'LayoutDashboard'
    },
    {
      label: 'Products',
      path: '/product-catalog',
      icon: 'Package'
    },
    {
      label: 'Inventory',
      path: '/stock-movements',
      icon: 'TrendingUp'
    },
    {
      label: 'Orders',
      path: '/purchase-orders',
      icon: 'ShoppingCart'
    }
  ];

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsVisible(false);
      } else {
        setIsVisible(true);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const handleNavigation = (path) => {
    navigate(path);
  };

  const isActiveRoute = (path) => {
    if (path === '/product-catalog') {
      return location.pathname === '/product-catalog' || location.pathname === '/add-edit-product';
    }
    return location.pathname === path;
  };

  if (location.pathname === '/login') {
    return null;
  }

  return (
    <nav className={`
      fixed bottom-0 left-0 right-0 z-header lg:hidden
      bg-surface border-t border-border
      transform transition-transform duration-300 ease-out
      ${isVisible ? 'translate-y-0' : 'translate-y-full'}
    `}>
      <div className="flex items-center justify-around px-2 py-2 safe-area-pb">
        {navigationItems.map((item) => {
          const isActive = isActiveRoute(item.path);
          
          return (
            <button
              key={item.path}
              onClick={() => handleNavigation(item.path)}
              className={`
                flex flex-col items-center justify-center px-3 py-2 rounded-lg
                transition-colors duration-200 min-w-0 flex-1
                ${isActive 
                  ? 'text-primary bg-primary-50' :'text-text-secondary hover:text-text-primary hover:bg-secondary-100'
                }
              `}
            >
              <Icon 
                name={item.icon} 
                size={20} 
                className="mb-1 flex-shrink-0"
              />
              <span className="text-xs font-medium truncate w-full text-center">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default MobileNavigation;