import svgPaths from "./svg-nv4n27ot92";
import imgPypl1 from "figma:asset/6b6e75c9704b577a838bcbeb5e0969353cca8ded.png";
import imgDesignSansTitre181 from "figma:asset/c240209f2df501626a7e94b1f9faaf4285a1e3c0.png";
import imgImage26 from "figma:asset/20c768ec7eeef8c8970bb6f543765fe7b3dedd48.png";

function Logo() {
  return (
    <div
      className="absolute bottom-0 left-0 right-[77.985%] top-0"
      data-name="LOGO"
    >
      <div className="absolute bottom-0 left-0 right-[-8.475%] top-0">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 64 59"
        >
          <g id="LOGO">
            <circle
              cx="29.5"
              cy="29.5"
              fill="url(#paint0_linear_1_3115)"
              id="shape"
              r="29.5"
            />
            <g filter="url(#filter0_d_1_3115)" id="shape_2">
              <circle
                cx="45.1176"
                cy="17.3529"
                fill="url(#paint1_linear_1_3115)"
                r="13.8824"
              />
            </g>
          </g>
          <defs>
            <filter
              colorInterpolationFilters="sRGB"
              filterUnits="userSpaceOnUse"
              height="35.7647"
              id="filter0_d_1_3115"
              width="35.7647"
              x="28.2353"
              y="3.47059"
            >
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix
                in="SourceAlpha"
                result="hardAlpha"
                type="matrix"
                values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
              />
              <feOffset dx="1" dy="4" />
              <feGaussianBlur stdDeviation="2" />
              <feColorMatrix
                type="matrix"
                values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"
              />
              <feBlend
                in2="BackgroundImageFix"
                mode="normal"
                result="effect1_dropShadow_1_3115"
              />
              <feBlend
                in="SourceGraphic"
                in2="effect1_dropShadow_1_3115"
                mode="normal"
                result="shape"
              />
            </filter>
            <linearGradient
              gradientUnits="userSpaceOnUse"
              id="paint0_linear_1_3115"
              x1="3.35402"
              x2="56.615"
              y1="70.9033"
              y2="43.6757"
            >
              <stop stopColor="#0D65D2" />
              <stop offset="1" stopColor="#00214D" />
            </linearGradient>
            <linearGradient
              gradientUnits="userSpaceOnUse"
              id="paint1_linear_1_3115"
              x1="41.4941"
              x2="62.9218"
              y1="35.9105"
              y2="28.0668"
            >
              <stop stopColor="#00F0CA" />
              <stop offset="1" stopColor="#02A189" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Logo1() {
  return (
    <div
      className="h-[59px] overflow-clip relative shrink-0 w-[268px]"
      data-name="LOGO"
    >
      <div
        className="absolute flex flex-col font-['Archivo:Bold',_sans-serif] font-bold h-[59px] justify-center leading-[0] text-[#00193b] text-[32px] text-left top-1/2 translate-y-[-50%] w-[193px]"
        style={{
          left: "calc(50% - 59px)",
          fontVariationSettings: "'wdth' 100",
        }}
      >
        <p className="block leading-[normal]">Quantixa</p>
      </div>
      <Logo />
    </div>
  );
}

function Frame1000002572() {
  return (
    <div className="box-border content-stretch flex flex-row font-['Inter:Regular',_sans-serif] font-normal gap-10 items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#040404] text-[18px] text-left text-nowrap">
      <div className="relative shrink-0">
        <p className="block leading-[normal] text-nowrap whitespace-pre">
          Home
        </p>
      </div>
      <div className="relative shrink-0">
        <p className="block leading-[normal] text-nowrap whitespace-pre">{`Plans & Pricing`}</p>
      </div>
      <div className="relative shrink-0">
        <p className="block leading-[normal] text-nowrap whitespace-pre">
          Shop
        </p>
      </div>
      <div className="relative shrink-0">
        <p className="block leading-[normal] text-nowrap whitespace-pre">
          Contact
        </p>
      </div>
    </div>
  );
}

function Frame1000002574() {
  return (
    <div className="bg-[#007aff] box-border content-stretch flex flex-row gap-4 items-center justify-start px-6 py-3 relative rounded-[40px] shrink-0">
      <div className="font-['Inter:Regular',_sans-serif] font-normal leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[18px] text-left text-nowrap">
        <p className="block leading-[normal] whitespace-pre">Subscribe</p>
      </div>
    </div>
  );
}

function Frame1000002573() {
  return (
    <div className="bg-[rgba(255,255,255,0)] box-border content-stretch flex flex-row gap-4 items-center justify-start px-6 py-3 relative rounded-[40px] shrink-0">
      <div className="absolute border border-[#000000] border-solid inset-0 pointer-events-none rounded-[40px]" />
      <div className="font-['Inter:Regular',_sans-serif] font-normal leading-[0] not-italic relative shrink-0 text-[#000000] text-[18px] text-left text-nowrap">
        <p className="block leading-[normal] whitespace-pre">Get Started</p>
      </div>
    </div>
  );
}

function Frame1000002575() {
  return (
    <div className="absolute box-border content-stretch flex flex-row items-center justify-between left-0 px-[124px] py-6 top-0 w-[1440px]">
      <Logo1 />
      <Frame1000002572 />
      <Frame1000002574 />
      <Frame1000002573 />
    </div>
  );
}

function Footer() {
  return (
    <div
      className="absolute h-[353px] left-0 top-[5318px] w-[1440px]"
      data-name="Footer"
    />
  );
}

function Logo2() {
  return (
    <div
      className="absolute bottom-0 left-0 right-[77.985%] top-0"
      data-name="LOGO"
    >
      <div className="absolute bottom-0 left-0 right-[-8.475%] top-0">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 64 59"
        >
          <g id="LOGO">
            <circle
              cx="29.5"
              cy="29.5"
              fill="url(#paint0_linear_1_3115)"
              id="shape"
              r="29.5"
            />
            <g filter="url(#filter0_d_1_3115)" id="shape_2">
              <circle
                cx="45.1176"
                cy="17.3529"
                fill="url(#paint1_linear_1_3115)"
                r="13.8824"
              />
            </g>
          </g>
          <defs>
            <filter
              colorInterpolationFilters="sRGB"
              filterUnits="userSpaceOnUse"
              height="35.7647"
              id="filter0_d_1_3115"
              width="35.7647"
              x="28.2353"
              y="3.47059"
            >
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix
                in="SourceAlpha"
                result="hardAlpha"
                type="matrix"
                values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
              />
              <feOffset dx="1" dy="4" />
              <feGaussianBlur stdDeviation="2" />
              <feColorMatrix
                type="matrix"
                values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"
              />
              <feBlend
                in2="BackgroundImageFix"
                mode="normal"
                result="effect1_dropShadow_1_3115"
              />
              <feBlend
                in="SourceGraphic"
                in2="effect1_dropShadow_1_3115"
                mode="normal"
                result="shape"
              />
            </filter>
            <linearGradient
              gradientUnits="userSpaceOnUse"
              id="paint0_linear_1_3115"
              x1="3.35402"
              x2="56.615"
              y1="70.9033"
              y2="43.6757"
            >
              <stop stopColor="#0D65D2" />
              <stop offset="1" stopColor="#00214D" />
            </linearGradient>
            <linearGradient
              gradientUnits="userSpaceOnUse"
              id="paint1_linear_1_3115"
              x1="41.4941"
              x2="62.9218"
              y1="35.9105"
              y2="28.0668"
            >
              <stop stopColor="#00F0CA" />
              <stop offset="1" stopColor="#02A189" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Logo3() {
  return (
    <div
      className="h-[59px] overflow-clip relative shrink-0 w-[268px]"
      data-name="LOGO"
    >
      <div
        className="absolute flex flex-col font-['Archivo:Bold',_sans-serif] font-bold h-[59px] justify-center leading-[0] text-[#00193b] text-[32px] text-left top-1/2 translate-y-[-50%] w-[193px]"
        style={{
          left: "calc(50% - 59px)",
          fontVariationSettings: "'wdth' 100",
        }}
      >
        <p className="block leading-[normal]">Quantixa</p>
      </div>
      <Logo2 />
    </div>
  );
}

function Div() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0"
      data-name="div"
    >
      <div className="font-['Inter:Medium',_sans-serif] font-medium leading-[0] not-italic relative shrink-0 text-[#040404] text-[18px] text-left text-nowrap">
        <p className="block leading-[1.5] whitespace-pre">
          Smart Subscription. Premium Shopping.
          <br />
          Join a trusted platform where subscriptions unlock exclusive shopping
          experiences.
        </p>
      </div>
    </div>
  );
}

function Div1() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-4 items-start justify-start p-0 relative shrink-0"
      data-name="div"
    >
      <Div />
    </div>
  );
}

function Frame1000002908() {
  return (
    <div className="box-border content-stretch flex flex-col gap-10 items-start justify-start p-0 relative shrink-0">
      <Logo3 />
      <Div1 />
    </div>
  );
}

function Frame1000002909() {
  return (
    <div className="absolute box-border content-stretch flex flex-row h-[332px] items-center justify-between left-0 px-[124px] py-[100px] top-[1279px] w-[1440px]">
      <Frame1000002908 />
    </div>
  );
}

function ArrowCircleRight() {
  return (
    <div className="relative shrink-0 size-6" data-name="ArrowCircleRight">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="ArrowCircleRight">
          <path
            d={svgPaths.p1caa1d00}
            id="Vector"
            stroke="var(--stroke-0, white)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.2"
          />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div
      className="basis-0 bg-[#007aff] grow min-h-px min-w-px relative shrink-0 w-full"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-1 items-center justify-center px-4 py-2 relative size-full">
          <div className="font-['Inter:Medium',_sans-serif] font-medium leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[14px] text-left text-nowrap tracking-[-0.14px]">
            <p className="adjustLetterSpacing block leading-[normal] whitespace-pre">
              Next
            </p>
          </div>
          <ArrowCircleRight />
        </div>
      </div>
    </div>
  );
}

function NavigationButton() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-col gap-1 h-10 items-center justify-center left-[1212px] overflow-clip p-0 rounded-[88px] top-[946px] w-[104px]"
      data-name="Navigation Button"
    >
      <Button />
    </div>
  );
}

function ArrowCircleRight1() {
  return (
    <div className="relative size-6" data-name="ArrowCircleRight">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="ArrowCircleRight">
          <path
            d={svgPaths.p1caa1d00}
            id="Vector"
            stroke="var(--stroke-0, white)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.2"
          />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div
      className="basis-0 bg-[#007aff] grow min-h-px min-w-px relative shrink-0 w-full"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-1 items-center justify-center px-4 py-2 relative size-full">
          <div className="flex items-center justify-center relative shrink-0">
            <div className="flex-none rotate-[180deg] scale-y-[-100%]">
              <ArrowCircleRight1 />
            </div>
          </div>
          <div className="font-['Inter:Medium',_sans-serif] font-medium leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[14px] text-left text-nowrap tracking-[-0.14px]">
            <p className="adjustLetterSpacing block leading-[normal] whitespace-pre">
              Previous
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function NavigationButton1() {
  return (
    <div
      className="absolute h-10 left-[115px] rounded-[88px] top-[946px] w-[104px]"
      data-name="Navigation Button"
    >
      <div className="box-border content-stretch flex flex-col gap-1 h-10 items-center justify-center overflow-clip p-0 relative w-[104px]">
        <Button1 />
      </div>
      <div className="absolute border-2 border-[#f0d7d0] border-solid inset-[-2px] pointer-events-none rounded-[90px]" />
    </div>
  );
}

function BankCard() {
  return (
    <div className="relative shrink-0 size-5" data-name="Bank Card">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="Bank Card">
          <path
            clipRule="evenodd"
            d={svgPaths.p38315200}
            fill="var(--fill-0, black)"
            fillRule="evenodd"
            id="Vector"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p35361a60}
            fill="var(--fill-0, black)"
            fillRule="evenodd"
            id="Vector_2"
          />
        </g>
      </svg>
    </div>
  );
}

function Cta() {
  return (
    <div
      className="basis-0 bg-[#ffffff] grow min-h-px min-w-px relative rounded-2xl shrink-0"
      data-name="CTA"
    >
      <div className="absolute border border-[#000000] border-solid inset-0 pointer-events-none rounded-2xl" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-2.5 py-3.5 relative w-full">
          <BankCard />
          <div
            className="font-['DM_Sans:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#000000] text-[14px] text-left text-nowrap tracking-[0.28px]"
            style={{ fontVariationSettings: "'opsz' 14" }}
          >
            <p className="adjustLetterSpacing block leading-[20px] whitespace-pre">
              Credit/Debit Card
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Cta1() {
  return (
    <div
      className="basis-0 bg-[#00a4ff] grow min-h-px min-w-px relative rounded-2xl shrink-0"
      data-name="CTA"
    >
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-2.5 py-3.5 relative w-full">
          <div
            className="bg-center bg-cover bg-no-repeat h-5 shrink-0 w-[17px]"
            data-name="PYPL 1"
            style={{ backgroundImage: `url('${imgPypl1}')` }}
          />
          <div
            className="font-['DM_Sans:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#ffffff] text-[14px] text-left text-nowrap tracking-[0.28px]"
            style={{ fontVariationSettings: "'opsz' 14" }}
          >
            <p className="adjustLetterSpacing block leading-[20px] whitespace-pre">
              PayPal
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function CtaSs() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-3 items-start justify-start left-[392px] p-0 top-[228px] w-[582px]"
      data-name="CTA  SS"
    >
      <Cta />
      <Cta1 />
    </div>
  );
}

function BankCard1() {
  return (
    <div className="relative shrink-0 size-5" data-name="Bank Card">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="Bank Card">
          <path
            clipRule="evenodd"
            d={svgPaths.p38315200}
            fill="var(--fill-0, black)"
            fillRule="evenodd"
            id="Vector"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p35361a60}
            fill="var(--fill-0, black)"
            fillRule="evenodd"
            id="Vector_2"
          />
        </g>
      </svg>
    </div>
  );
}

function Cta2() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-2.5 items-center justify-center left-[266px] px-2.5 py-3.5 rounded-2xl top-[779px] w-[186px]"
      data-name="CTA"
    >
      <div className="absolute border border-[#000000] border-solid inset-0 pointer-events-none rounded-2xl" />
      <BankCard1 />
      <div
        className="font-['DM_Sans:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#000000] text-[14px] text-left text-nowrap tracking-[0.28px]"
        style={{ fontVariationSettings: "'opsz' 14" }}
      >
        <p className="adjustLetterSpacing block leading-[20px] whitespace-pre">
          Confirm
        </p>
      </div>
    </div>
  );
}

function Cta3() {
  return (
    <div
      className="absolute bg-[#00a4ff] box-border content-stretch flex flex-row gap-2.5 items-center justify-center left-[612px] px-2.5 py-3.5 rounded-2xl top-[779px] w-[186px]"
      data-name="CTA"
    >
      <div
        className="bg-center bg-cover bg-no-repeat h-5 shrink-0 w-[17px]"
        data-name="PYPL 1"
        style={{ backgroundImage: `url('${imgPypl1}')` }}
      />
      <div
        className="font-['DM_Sans:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#ffffff] text-[14px] text-left text-nowrap tracking-[0.28px]"
        style={{ fontVariationSettings: "'opsz' 14" }}
      >
        <p className="adjustLetterSpacing block leading-[20px] whitespace-pre">
          Pay With PayPal
        </p>
      </div>
    </div>
  );
}

function Frame1000003065() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-2.5 items-start justify-center leading-[0] left-[103px] not-italic p-0 text-[#1f2026] text-left top-[324px]">
      <div className="font-['Inter:Semi_Bold',_sans-serif] font-semibold relative shrink-0 text-[20px] text-nowrap tracking-[-0.2px]">
        <p className="adjustLetterSpacing block leading-[26px] whitespace-pre">
          Payment Detail
        </p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',_sans-serif] font-normal justify-center relative shrink-0 text-[12px] tracking-[-0.24px] w-[617px]">
        <p className="adjustLetterSpacing block leading-[18px]">
          Please fill out the form below. Enter your card account details.
        </p>
      </div>
    </div>
  );
}

function Field() {
  return (
    <div
      className="absolute bg-[rgba(255,255,255,0)] box-border content-stretch flex flex-row gap-3 items-center justify-start left-3.5 p-0 translate-y-[-50%] w-[173px]"
      data-name="Field"
      style={{ top: "calc(50% + 13px)" }}
    >
      <div className="font-['Inter:Regular',_sans-serif] font-normal leading-[0] not-italic relative shrink-0 text-[#1f2026] text-[14px] text-left text-nowrap tracking-[-0.14px]">
        <p className="adjustLetterSpacing block leading-[22px] whitespace-pre">{`1243  _  2133  _ 9832 _ 3200`}</p>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="absolute contents left-0 top-[26px]" data-name="Content">
      <div
        className="absolute bg-[rgba(255,255,255,0)] bottom-0 left-0 right-0 rounded-md top-[26px]"
        data-name="bg"
      >
        <div className="absolute border border-[#b3b3b3] border-solid inset-0 pointer-events-none rounded-md shadow-[0px_1px_2px_0px_rgba(0,0,0,0.07)]" />
      </div>
      <Field />
    </div>
  );
}

function Frame7() {
  return (
    <div className="absolute h-7 left-[706px] top-[34px] w-[42px]">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 42 28"
      >
        <g id="Group 13410">
          <rect
            fill="var(--fill-0, #F6F7FA)"
            height="27"
            id="BASE"
            rx="3.5"
            stroke="var(--stroke-0, #E6E6E6)"
            width="41"
            x="0.5"
            y="0.5"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p4b40780}
            fill="var(--fill-0, #8298FF)"
            fillRule="evenodd"
            id="visa-logo"
          />
        </g>
      </svg>
    </div>
  );
}

function Inputs() {
  return (
    <div
      className="absolute h-[70px] left-[103px] top-[407px] w-[756px]"
      data-name="Inputs"
    >
      <Content />
      <div className="absolute font-['Inter:Semi_Bold',_sans-serif] font-semibold leading-[0] left-0 not-italic text-[#1e2238] text-[14px] text-left text-nowrap top-0 tracking-[-0.14px]">
        <p className="adjustLetterSpacing block leading-[22px] whitespace-pre">
          Card Number
        </p>
      </div>
      <Frame7 />
    </div>
  );
}

function Field1() {
  return (
    <div
      className="absolute bg-[rgba(255,255,255,0)] box-border content-stretch flex flex-row gap-3 items-center justify-start left-3.5 p-0 translate-y-[-50%] w-[173px]"
      data-name="Field"
      style={{ top: "calc(50% + 13px)" }}
    >
      <div className="font-['Inter:Regular',_'Noto_Sans:Regular',_sans-serif] font-normal leading-[0] not-italic relative shrink-0 text-[#1f2026] text-[14px] text-left text-nowrap tracking-[-0.14px]">
        <p className="adjustLetterSpacing block leading-[22px] whitespace-pre">{`Enter the name exactly as it appears on your payment card. `}</p>
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div className="absolute contents left-0 top-[26px]" data-name="Content">
      <div
        className="absolute bg-[rgba(255,255,255,0)] bottom-0 left-0 right-0 rounded-md top-[26px]"
        data-name="bg"
      >
        <div className="absolute border border-[#e3e3e3] border-solid inset-0 pointer-events-none rounded-md shadow-[0px_1px_2px_0px_rgba(0,0,0,0.07)]" />
      </div>
      <Field1 />
    </div>
  );
}

function Inputs1() {
  return (
    <div
      className="absolute h-[70px] left-[103px] top-[642px] w-[756px]"
      data-name="Inputs"
    >
      <Content1 />
      <div className="absolute font-['Inter:Semi_Bold',_sans-serif] font-semibold leading-[0] left-0 not-italic text-[#1e2238] text-[14px] text-left text-nowrap top-0 tracking-[-0.14px]">
        <p className="adjustLetterSpacing block leading-[22px] whitespace-pre">
          Full name
        </p>
      </div>
    </div>
  );
}

function Field2() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-3 items-center justify-start left-3.5 p-0 translate-y-[-50%] w-[173px]"
      data-name="Field"
      style={{ top: "calc(50% + 13px)" }}
    >
      <div className="font-['Inter:Regular',_sans-serif] font-normal leading-[0] not-italic relative shrink-0 text-[#1f2026] text-[14px] text-left text-nowrap tracking-[-0.14px]">
        <p className="adjustLetterSpacing block leading-[22px] whitespace-pre">
          12
        </p>
      </div>
    </div>
  );
}

function IconFrame() {
  return (
    <div
      className="absolute left-1/2 size-6 top-1/2 translate-x-[-50%] translate-y-[-50%]"
      data-name="Icon Frame"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="Icon Frame">
          <g id="Base"></g>
          <path
            d="M7 10L12 15"
            id="Vector"
            stroke="var(--stroke-0, #767A85)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
          <path
            d="M12 15L17 10"
            id="Vector_2"
            stroke="var(--stroke-0, #767A85)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
        </g>
      </svg>
    </div>
  );
}

function ArrowArrowDown2() {
  return (
    <div
      className="absolute inset-0 overflow-clip"
      data-name="Arrow / Arrow Down 2"
    >
      <IconFrame />
    </div>
  );
}

function ArrowArrowDown3() {
  return (
    <div
      className="absolute bottom-[14.286%] right-2.5 top-[51.429%] w-6"
      data-name="Arrow / Arrow Down 2"
    >
      <ArrowArrowDown2 />
    </div>
  );
}

function Content2() {
  return (
    <div className="absolute contents left-0 top-[26px]" data-name="Content">
      <div
        className="absolute bg-[rgba(255,255,255,0)] bottom-0 left-0 right-0 rounded-md top-[26px]"
        data-name="bg"
      >
        <div className="absolute border border-[#e5e6eb] border-solid inset-0 pointer-events-none rounded-md shadow-[0px_1px_2px_0px_rgba(0,0,0,0.07)]" />
      </div>
      <Field2 />
      <ArrowArrowDown3 />
    </div>
  );
}

function Inputs2() {
  return (
    <div className="h-[70px] relative shrink-0 w-[180px]" data-name="Inputs">
      <Content2 />
      <div className="absolute font-['Inter:Semi_Bold',_sans-serif] font-semibold leading-[0] left-0 not-italic text-[#1e2238] text-[14px] text-left text-nowrap top-0 tracking-[-0.14px]">
        <p className="adjustLetterSpacing block leading-[22px] whitespace-pre">
          Expire Date
        </p>
      </div>
    </div>
  );
}

function Field3() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-3 items-center justify-start left-3.5 p-0 top-1/2 translate-y-[-50%] w-[296px]"
      data-name="Field"
    >
      <div className="font-['Inter:Regular',_sans-serif] font-normal leading-[0] not-italic relative shrink-0 text-[#1f2026] text-[14px] text-left text-nowrap tracking-[-0.14px]">
        <p className="adjustLetterSpacing block leading-[22px] whitespace-pre">
          2030
        </p>
      </div>
    </div>
  );
}

function IconFrame1() {
  return (
    <div
      className="absolute left-1/2 size-6 top-1/2 translate-x-[-50%] translate-y-[-50%]"
      data-name="Icon Frame"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="Icon Frame">
          <g id="Base"></g>
          <path
            d="M7 10L12 15"
            id="Vector"
            stroke="var(--stroke-0, #767A85)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
          <path
            d="M12 15L17 10"
            id="Vector_2"
            stroke="var(--stroke-0, #767A85)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
        </g>
      </svg>
    </div>
  );
}

function ArrowArrowDown4() {
  return (
    <div
      className="absolute inset-0 overflow-clip"
      data-name="Arrow / Arrow Down 2"
    >
      <IconFrame1 />
    </div>
  );
}

function ArrowArrowDown5() {
  return (
    <div
      className="absolute bottom-[22.727%] right-2.5 top-[22.727%] w-6"
      data-name="Arrow / Arrow Down 2"
    >
      <ArrowArrowDown4 />
    </div>
  );
}

function Content3() {
  return (
    <div className="absolute contents left-0 top-0" data-name="Content">
      <div
        className="absolute bg-[rgba(255,255,255,0)] inset-0 rounded-md"
        data-name="bg"
      >
        <div className="absolute border border-[#e5e6eb] border-solid inset-0 pointer-events-none rounded-md shadow-[0px_1px_2px_0px_rgba(0,0,0,0.07)]" />
      </div>
      <Field3 />
      <ArrowArrowDown5 />
    </div>
  );
}

function Inputs3() {
  return (
    <div className="h-11 relative shrink-0 w-[180px]" data-name="Inputs">
      <Content3 />
    </div>
  );
}

function Field4() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-4 items-center justify-start left-3.5 p-0 top-[38px] w-[180px]"
      data-name="Field"
    >
      <div className="font-['Inter:Regular',_sans-serif] font-normal leading-[0] not-italic relative shrink-0 text-[#1f2026] text-[14px] text-left text-nowrap tracking-[-0.14px]">
        <p className="adjustLetterSpacing block leading-[22px] whitespace-pre">
          453
        </p>
      </div>
    </div>
  );
}

function Content4() {
  return (
    <div className="absolute contents left-0 top-[26px]" data-name="Content">
      <div
        className="absolute bg-[#ffffff] bottom-0 left-0 right-0 rounded-md top-[26px]"
        data-name="bg"
      >
        <div className="absolute border border-[rgba(255,255,255,0)] border-solid inset-0 pointer-events-none rounded-md shadow-[0px_1px_2px_0px_rgba(0,0,0,0.07)]" />
      </div>
      <Field4 />
    </div>
  );
}

function Inputs4() {
  return (
    <div className="h-[70px] relative shrink-0 w-[348px]" data-name="Inputs">
      <Content4 />
      <div className="absolute font-['Inter:Semi_Bold',_sans-serif] font-semibold leading-[0] left-0 not-italic text-[#1e2238] text-[14px] text-left text-nowrap top-0 tracking-[-0.14px]">
        <p className="adjustLetterSpacing block leading-[22px] whitespace-pre">
          CVC/CVV
        </p>
      </div>
    </div>
  );
}

function Frame1000003170() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-6 items-end justify-start left-[103px] p-0 top-[538px]">
      <Inputs2 />
      <Inputs3 />
      <Inputs4 />
    </div>
  );
}

function Heading() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start leading-[0] p-0 relative shrink-0"
      data-name="Heading"
    >
      <div className="font-['Urbanist:Bold',_sans-serif] font-bold relative shrink-0 text-[24px] text-center text-nowrap text-slate-800">
        <p className="block leading-[1.2] whitespace-pre">Plus Plan</p>
      </div>
      <div className="font-['Urbanist:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] text-left text-slate-500 w-[300px]">
        <p className="block leading-[1.4]">
          Built for power users and professional resellers
        </p>
      </div>
    </div>
  );
}

function Price() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start leading-[0] p-0 relative shrink-0"
      data-name="Price"
    >
      <div className="font-['Urbanist:Bold',_sans-serif] font-bold relative shrink-0 text-[32px] text-center text-nowrap text-slate-800">
        <p className="block leading-[1.2] whitespace-pre">$19.99/month</p>
      </div>
      <div className="font-['Urbanist:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] text-left text-slate-500 w-[300px]">
        <p className="block leading-[1.4]">User will billed Monthly</p>
      </div>
    </div>
  );
}

function Benefit() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="Benefit"
    >
      <div className="relative shrink-0 size-4">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 16 16"
        >
          <circle
            cx="8"
            cy="8"
            fill="var(--fill-0, #3898D3)"
            id="Ellipse 277"
            r="8"
          />
        </svg>
      </div>
      <div className="font-['Urbanist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-left text-nowrap text-slate-500">
        <p className="block leading-[1.4] whitespace-pre">Max Users: 5</p>
      </div>
    </div>
  );
}

function Benefit1() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="Benefit"
    >
      <div className="relative shrink-0 size-4">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 16 16"
        >
          <circle
            cx="8"
            cy="8"
            fill="var(--fill-0, #3898D3)"
            id="Ellipse 277"
            r="8"
          />
        </svg>
      </div>
      <div className="font-['Urbanist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-left text-nowrap text-slate-500">
        <p className="block leading-[1.4] whitespace-pre">Max Products: 200</p>
      </div>
    </div>
  );
}

function Benefit2() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="Benefit"
    >
      <div className="relative shrink-0 size-4">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 16 16"
        >
          <circle
            cx="8"
            cy="8"
            fill="var(--fill-0, #3898D3)"
            id="Ellipse 277"
            r="8"
          />
        </svg>
      </div>
      <div className="font-['Urbanist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-left text-nowrap text-slate-500">
        <p className="block leading-[1.4] mb-0 whitespace-pre">Features:</p>
        <ul className="css-ed5n1g list-disc">
          <li className="mb-0 ms-6">
            <span className="leading-[1.4]">{`Full Dashboard & Order Tracking`}</span>
          </li>
          <li className="mb-0 ms-6">
            <span className="leading-[1.4]">Smart Recommendations</span>
          </li>
          <li className="mb-0 ms-6">
            <span className="leading-[1.4]">Priority Processing</span>
          </li>
          <li className="ms-6">
            <span className="leading-[1.4]">Live Chat Support</span>
          </li>
        </ul>
      </div>
    </div>
  );
}

function List() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-4 items-start justify-start p-0 relative shrink-0"
      data-name="List"
    >
      <Benefit />
      <Benefit1 />
      <Benefit2 />
    </div>
  );
}

function WhatYouGet() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-6 items-start justify-start p-0 relative shrink-0"
      data-name="What you Get"
    >
      <div className="font-['Urbanist:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[20px] text-center text-nowrap text-slate-800">
        <p className="block leading-[1.2] whitespace-pre">What you get</p>
      </div>
      <List />
    </div>
  );
}

function Free() {
  return (
    <div
      className="absolute bg-[#ffffff] box-border content-stretch flex flex-col gap-8 items-start justify-start left-[942px] p-[32px] rounded-2xl top-[347px]"
      data-name="Free"
    >
      <div className="absolute border-2 border-[#b2e6ff] border-solid inset-0 pointer-events-none rounded-2xl" />
      <Heading />
      <div className="h-0 relative shrink-0 w-[422px]">
        <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 422 2"
          >
            <path
              d="M0 1H422"
              id="Vector 2541"
              opacity="0.1"
              stroke="var(--stroke-0, black)"
            />
          </svg>
        </div>
      </div>
      <Price />
      <WhatYouGet />
    </div>
  );
}

function Check() {
  return (
    <div
      className="absolute left-[82px] size-[22px] top-[733px]"
      data-name="check"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 22 22"
      >
        <g id="check">
          <rect fill="var(--fill-0, #58B039)" height="22" rx="11" width="22" />
          <path
            d={svgPaths.pf96bcc0}
            id="Vector"
            stroke="var(--stroke-0, white)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1597881555() {
  return (
    <div className="absolute h-[1055px] left-0 overflow-clip top-56 w-[1440px]">
      <NavigationButton />
      <NavigationButton1 />
      <div className="absolute font-['Plus_Jakarta_Sans:Bold',_sans-serif] font-bold leading-[0] left-[720px] text-[#007aff] text-[96px] text-center top-[26px] translate-x-[-50%] w-[1440px]">
        <p className="block leading-[103px]">{`Enter Your Payment Details `}</p>
      </div>
      <div
        className="absolute font-['Archivo:Regular',_sans-serif] font-normal leading-[0] left-[655.5px] text-[24px] text-[rgba(33,25,4,0.73)] text-center top-[151px] translate-x-[-50%] w-[1063px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[32px]">
          Your payment is 100% secure and encrypted.
        </p>
      </div>
      <div
        className="absolute bg-center bg-cover bg-no-repeat left-[903px] size-[77px] top-[129px]"
        data-name="Design sans titre (18) 1"
        style={{ backgroundImage: `url('${imgDesignSansTitre181}')` }}
      />
      <CtaSs />
      <Cta2 />
      <Cta3 />
      <Frame1000003065 />
      <Inputs />
      <Inputs1 />
      <Frame1000003170 />
      <Free />
      <div className="absolute font-['Plus_Jakarta_Sans:Bold',_sans-serif] font-bold h-[95px] leading-[0] left-[1186.5px] text-[#007aff] text-[36px] text-center top-[262px] translate-x-[-50%] w-[453px]">
        <p className="block leading-[103px]">Subscription Summary</p>
      </div>
      <div className="absolute font-['Urbanist:Bold',_sans-serif] font-bold leading-[0] left-[330px] text-[24px] text-center text-slate-800 top-[729px] translate-x-[-50%] w-[452px]">
        <p className="block leading-[1.2]">
          I agree to the Terms and Privacy Policy
        </p>
      </div>
      <Check />
    </div>
  );
}

export default function QuantixaCheckoutPage() {
  return (
    <div
      className="bg-[#ffffff] overflow-clip relative rounded-xl size-full"
      data-name="Quantixa -  Checkout Page"
    >
      <div
        className="absolute flex h-[720.978px] items-center justify-center top-[-380px] w-[819.787px]"
        style={{ left: "calc(58.333% - 18px)" }}
      >
        <div className="flex-none rotate-[115deg]">
          <div
            className="h-[681.857px] relative w-[477.581px]"
            data-name="Blob Ornament"
          >
            <div className="absolute bottom-[-29.332%] left-[-41.878%] right-[-41.878%] top-[-29.332%]">
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 878 1082"
              >
                <g
                  filter="url(#filter0_f_3_1956)"
                  id="Blob Ornament"
                  opacity="0.4"
                >
                  <path
                    clipRule="evenodd"
                    d={svgPaths.p345d6940}
                    fill="url(#paint0_linear_3_1956)"
                    fillRule="evenodd"
                  />
                </g>
                <defs>
                  <filter
                    colorInterpolationFilters="sRGB"
                    filterUnits="userSpaceOnUse"
                    height="1081.86"
                    id="filter0_f_3_1956"
                    width="877.581"
                    x="-1.13794e-06"
                    y="-4.75855e-08"
                  >
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend
                      in="SourceGraphic"
                      in2="BackgroundImageFix"
                      mode="normal"
                      result="shape"
                    />
                    <feGaussianBlur
                      result="effect1_foregroundBlur_3_1956"
                      stdDeviation="100"
                    />
                  </filter>
                  <linearGradient
                    gradientUnits="userSpaceOnUse"
                    id="paint0_linear_3_1956"
                    x1="438.79"
                    x2="438.79"
                    y1="200"
                    y2="881.857"
                  >
                    <stop stopColor="#00F0CA" stopOpacity="0.75" />
                    <stop
                      offset="0.9998"
                      stopColor="#02A189"
                      stopOpacity="0.723734"
                    />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[882.309px] items-center justify-center left-[-449px] top-[-507px] w-[969.985px]">
        <div className="flex-none rotate-[115deg]">
          <div
            className="h-[787.557px] relative w-[606.294px]"
            data-name="Blob Ornament"
          >
            <div className="absolute bottom-[-25.395%] left-[-32.987%] right-[-32.987%] top-[-25.395%]">
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 1007 1188"
              >
                <g
                  filter="url(#filter0_f_3_1986)"
                  id="Blob Ornament"
                  opacity="0.4"
                >
                  <path
                    clipRule="evenodd"
                    d={svgPaths.p847b00}
                    fill="url(#paint0_linear_3_1986)"
                    fillRule="evenodd"
                  />
                </g>
                <defs>
                  <filter
                    colorInterpolationFilters="sRGB"
                    filterUnits="userSpaceOnUse"
                    height="1187.56"
                    id="filter0_f_3_1986"
                    width="1006.29"
                    x="7.36824e-07"
                    y="1.59959e-08"
                  >
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend
                      in="SourceGraphic"
                      in2="BackgroundImageFix"
                      mode="normal"
                      result="shape"
                    />
                    <feGaussianBlur
                      result="effect1_foregroundBlur_3_1986"
                      stdDeviation="100"
                    />
                  </filter>
                  <linearGradient
                    gradientUnits="userSpaceOnUse"
                    id="paint0_linear_3_1986"
                    x1="503.147"
                    x2="503.147"
                    y1="200"
                    y2="987.557"
                  >
                    <stop stopColor="#0D65D2" stopOpacity="0.75" />
                    <stop
                      offset="0.9999"
                      stopColor="#0D65D2"
                      stopOpacity="0.695913"
                    />
                    <stop offset="1" stopColor="#0D65D2" stopOpacity="0.5" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div
        className="absolute bg-center bg-cover bg-no-repeat h-[2957px] top-[1147px] w-[3366px]"
        data-name="image 26"
        style={{
          left: "calc(100% + 370px)",
          backgroundImage: `url('${imgImage26}')`,
        }}
      />
      <Frame1000002575 />
      <div
        className="absolute h-[571.808px] top-[832px] translate-x-[-50%] w-[1828.36px]"
        style={{ left: "calc(58.333% - 30.822px)" }}
      >
        <div className="absolute bottom-[-37.383%] left-[-11.691%] right-[-11.691%] top-[-37.383%]">
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 2257 1000"
          >
            <g filter="url(#filter0_f_1_2627)" id="Vector 28" opacity="0.5">
              <path d={svgPaths.p12749600} fill="url(#paint0_radial_1_2627)" />
              <path d={svgPaths.p12749600} stroke="var(--stroke-0, black)" />
            </g>
            <defs>
              <filter
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
                height="999.323"
                id="filter0_f_1_2627"
                width="2255.87"
                x="0.242337"
                y="0.242378"
              >
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend
                  in="SourceGraphic"
                  in2="BackgroundImageFix"
                  mode="normal"
                  result="shape"
                />
                <feGaussianBlur
                  result="effect1_foregroundBlur_1_2627"
                  stdDeviation="106.629"
                />
              </filter>
              <radialGradient
                cx="0"
                cy="0"
                gradientTransform="translate(1916.03 748.497) rotate(-175.349) scale(1496.82 671.743)"
                gradientUnits="userSpaceOnUse"
                id="paint0_radial_1_2627"
                r="1"
              >
                <stop stopColor="#3898D3" />
                <stop offset="0.3635" stopColor="#3898D3" />
                <stop offset="0.631367" stopColor="#EEEAC8" />
                <stop offset="0.708333" stopColor="#0E55A7" />
                <stop offset="0.932292" stopColor="#3898D3" />
              </radialGradient>
            </defs>
          </svg>
        </div>
      </div>
      <Footer />
      <Frame1000002909 />
      <Frame1597881555 />
    </div>
  );
}