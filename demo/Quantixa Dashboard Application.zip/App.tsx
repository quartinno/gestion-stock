import React, { useState, useRef } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardFrame } from './components/DashboardFrame';
import { POSFrame } from './components/POSFrame';
import { InventoryFrame } from './components/InventoryFrame';
import { InvoiceFrame } from './components/InvoiceFrame';
import { ClientsFrame } from './components/ClientsFrame';
import { UsersFrame } from './components/UsersFrame';
import { OrdersFrame } from './components/OrdersFrame';
import { AnalyticsFrame } from './components/AnalyticsFrame';
import { SettingsFrame } from './components/SettingsFrame';
import { BarcodeScanner } from './components/BarcodeScanner';
import { AddProduct } from './components/AddProduct';
import type { ProductData } from './components/AddProduct';
import { toast, Toaster } from 'sonner@2.0.3';

export default function App() {
  const [activeFrame, setActiveFrame] = useState('dashboard');
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scannerContext, setScannerContext] = useState<'pos' | 'inventory'>('inventory');
  const [addProductOpen, setAddProductOpen] = useState(false);
  const [pendingBarcodeForNewProduct, setPendingBarcodeForNewProduct] = useState<string | undefined>();
  const inventoryFrameRef = useRef<any>(null);

  const openScanner = (context: 'pos' | 'inventory' = 'inventory') => {
    setScannerContext(context);
    setScannerOpen(true);
  };

  const renderFrame = () => {
    switch (activeFrame) {
      case 'dashboard':
        return <DashboardFrame onOpenScanner={() => openScanner('inventory')} />;
      case 'pos':
        return <POSFrame onOpenScanner={() => openScanner('pos')} />;
      case 'inventory':
        return <InventoryFrame onOpenScanner={() => openScanner('inventory')} />;
      case 'invoices':
        return <InvoiceFrame />;
      case 'clients':
        return <ClientsFrame />;
      case 'sales':
        return <OrdersFrame />;
      case 'users':
        return <UsersFrame />;
      case 'suppliers':
        return <InventoryFrame onOpenScanner={() => openScanner('inventory')} />; // Will show suppliers tab
      case 'analytics':
        return <AnalyticsFrame />;
      case 'settings':
        return <SettingsFrame />;
      default:
        return <DashboardFrame onOpenScanner={() => openScanner('inventory')} />;
    }
  };

  const handleScanResult = (barcode: string, productData?: any) => {
    if (scannerContext === 'pos') {
      // Handle POS scanning - add to cart
      if (productData) {
        toast.success(`Product added to cart: ${productData.name}`, {
          description: `Barcode: ${barcode} | Price: ${productData.price} | Stock: ${productData.stock} units`,
          action: {
            label: 'Go to POS',
            onClick: () => setActiveFrame('pos')
          }
        });
        
        // Switch to POS if not already there
        if (activeFrame !== 'pos') {
          setActiveFrame('pos');
        }
      } else {
        toast.info('Product not found for sale', {
          description: `Barcode: ${barcode} - Add to inventory first?`,
          action: {
            label: 'Add to Inventory',
            onClick: () => {
              setPendingBarcodeForNewProduct(barcode);
              setAddProductOpen(true);
            }
          }
        });
      }
    } else {
      // Handle inventory scanning - view/edit product
      if (productData) {
        toast.success(`Product found: ${productData.name}`, {
          description: `Barcode: ${barcode} | Stock: ${productData.stock} units`,
          action: {
            label: 'View in Inventory',
            onClick: () => setActiveFrame('inventory')
          }
        });
        
        // Switch to inventory if not already there
        if (activeFrame !== 'inventory') {
          setActiveFrame('inventory');
        }
      } else {
        toast.info('Product not found in inventory', {
          description: `Barcode: ${barcode} - Would you like to add it as a new product?`,
          action: {
            label: 'Add Product',
            onClick: () => {
              setPendingBarcodeForNewProduct(barcode);
              setAddProductOpen(true);
            }
          }
        });
      }
    }
  };

  const handleSaveNewProduct = (product: ProductData) => {
    // Here you would typically save to your backend/state management
    console.log('Saving new product from barcode scan:', product);
    
    toast.success(`Product "${product.name}" added successfully!`, {
      description: `Barcode: ${product.barcode} | Stock: ${product.stock} ${product.unit}`,
      action: {
        label: 'View in Inventory',
        onClick: () => setActiveFrame('inventory')
      }
    });

    // Switch to inventory to show the new product
    if (activeFrame !== 'inventory') {
      setActiveFrame('inventory');
    }
  };

  const handleCloseAddProduct = () => {
    setAddProductOpen(false);
    setPendingBarcodeForNewProduct(undefined);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onOpenScanner={() => openScanner(activeFrame === 'pos' ? 'pos' : 'inventory')} />
      
      <div className="flex max-w-7xl mx-auto">
        <Sidebar activeFrame={activeFrame} onFrameChange={setActiveFrame} />
        
        <main className="flex-1 p-6">
          {renderFrame()}
        </main>
      </div>

      <BarcodeScanner
        isOpen={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onScanResult={handleScanResult}
      />

      <AddProduct
        isOpen={addProductOpen}
        onClose={handleCloseAddProduct}
        onSave={handleSaveNewProduct}
        onOpenScanner={() => {
          setAddProductOpen(false);
          openScanner('inventory');
        }}
        initialBarcode={pendingBarcodeForNewProduct}
      />
      
      <Toaster richColors position="top-right" />
    </div>
  );
}