import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { 
  Plus,
  Search,
  Eye,
  MoreHorizontal,
  CreditCard,
  Building,
  Users,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Crown,
  Shield,
  Star,
  Edit,
  Trash2,
  Calendar,
  DollarSign
} from 'lucide-react';

export function SubscriptionFrame() {
  const [activeTab, setActiveTab] = useState('businesses');

  // Mock subscription plans
  const subscriptionPlans = [
    {
      id: 'basic',
      name: 'Basic Plan',
      price: 29.99,
      duration: 'monthly',
      maxUsers: 3,
      maxProducts: 1000,
      features: ['Inventory Management', 'Basic POS', 'Client Management', 'Basic Reports'],
      icon: Shield
    },
    {
      id: 'professional',
      name: 'Professional Plan',
      price: 79.99,
      duration: 'monthly',
      maxUsers: 10,
      maxProducts: 5000,
      features: ['All Basic Features', 'Advanced POS', 'Invoice Management', 'Advanced Analytics', 'Multi-user Support'],
      icon: Star
    },
    {
      id: 'enterprise',
      name: 'Enterprise Plan',
      price: 199.99,
      duration: 'monthly',
      maxUsers: -1, // unlimited
      maxProducts: -1, // unlimited
      features: ['All Professional Features', 'Multi-branch Support', 'API Access', 'Priority Support', 'Custom Reports'],
      icon: Crown
    }
  ];

  // Mock businesses
  const mockBusinesses = [
    {
      id: 'BIZ-001',
      name: 'Santos Pharmacy',
      email: 'admin@santospharmacy.com',
      phone: '+1 (555) 123-4567',
      plan: subscriptionPlans[1], // Professional
      subscriptionStart: '2024-12-01',
      subscriptionEnd: '2025-12-01',
      status: 'active',
      users: 5,
      products: 2847,
      lastPayment: '2024-12-01',
      paymentStatus: 'current',
      totalRevenue: 959.88
    },
    {
      id: 'BIZ-002',
      name: 'MediCare Drugstore',
      email: 'owner@medicaredrug.com',
      phone: '+1 (555) 234-5678',
      plan: subscriptionPlans[0], // Basic
      subscriptionStart: '2025-01-15',
      subscriptionEnd: '2025-02-15',
      status: 'active',
      users: 2,
      products: 456,
      lastPayment: '2025-01-15',
      paymentStatus: 'current',
      totalRevenue: 29.99
    },
    {
      id: 'BIZ-003',
      name: 'Downtown Supermarket',
      email: 'manager@downtown.com',
      phone: '+1 (555) 345-6789',
      plan: subscriptionPlans[2], // Enterprise
      subscriptionStart: '2024-06-01',
      subscriptionEnd: '2025-06-01',
      status: 'active',
      users: 25,
      products: 12000,
      lastPayment: '2024-12-01',
      paymentStatus: 'current',
      totalRevenue: 1399.93
    },
    {
      id: 'BIZ-004',
      name: 'City Parapharmacy',
      email: 'info@citypara.com',
      phone: '+1 (555) 456-7890',
      plan: subscriptionPlans[0], // Basic
      subscriptionStart: '2024-11-01',
      subscriptionEnd: '2024-12-01',
      status: 'expired',
      users: 3,
      products: 234,
      lastPayment: '2024-11-01',
      paymentStatus: 'overdue',
      totalRevenue: 59.98
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'expired': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'suspended': return 'bg-gray-100 text-gray-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'current': return 'bg-green-100 text-green-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#00193b]">Subscription Management</h1>
          <p className="text-gray-600">Manage business subscriptions, plans, and payments</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            New Plan
          </Button>
          <Button className="bg-[#007aff] hover:bg-[#007aff]/90">
            <Building className="w-4 h-4 mr-2" />
            Add Business
          </Button>
        </div>
      </div>

      {/* Subscription Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Businesses</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">247</div>
            <p className="text-xs text-muted-foreground">+23 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$18,750</div>
            <p className="text-xs text-muted-foreground">+15.2% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expired Subscriptions</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">12</div>
            <p className="text-xs text-muted-foreground">Need renewal</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,847</div>
            <p className="text-xs text-muted-foreground">Across all businesses</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="businesses">Businesses</TabsTrigger>
          <TabsTrigger value="plans">Subscription Plans</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="businesses" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input placeholder="Search businesses..." className="pl-9" />
            </div>
            <Badge variant="secondary">{mockBusinesses.length} businesses</Badge>
          </div>

          <div className="space-y-4">
            {mockBusinesses.map(business => {
              const PlanIcon = business.plan.icon;
              return (
                <Card key={business.id} className={business.status === 'expired' ? 'border-red-200 bg-red-50' : ''}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="space-y-3">
                        <div className="flex items-center gap-4">
                          <div>
                            <p className="font-bold text-lg">{business.name}</p>
                            <p className="text-sm text-muted-foreground">ID: {business.id}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={getStatusColor(business.status)}>
                              {business.status}
                            </Badge>
                            <Badge className={getPaymentStatusColor(business.paymentStatus)}>
                              {business.paymentStatus}
                            </Badge>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Contact:</p>
                            <p>{business.email}</p>
                            <p>{business.phone}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Subscription:</p>
                            <p>Start: {business.subscriptionStart}</p>
                            <p>End: {business.subscriptionEnd}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-6 text-sm">
                          <div className="flex items-center gap-2">
                            <PlanIcon className="w-4 h-4" />
                            <span className="font-medium">{business.plan.name}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Users: </span>
                            <span>{business.users}/{business.plan.maxUsers === -1 ? '∞' : business.plan.maxUsers}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Products: </span>
                            <span>{business.products.toLocaleString()}/{business.plan.maxProducts === -1 ? '∞' : business.plan.maxProducts.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-right space-y-2">
                        <div className="text-2xl font-bold text-[#007aff]">
                          ${business.plan.price.toFixed(2)}/mo
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Total Revenue: ${business.totalRevenue.toFixed(2)}
                        </p>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="w-4 h-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit Business
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <CreditCard className="w-4 h-4 mr-2" />
                              Change Plan
                            </DropdownMenuItem>
                            {business.status === 'expired' && (
                              <DropdownMenuItem>
                                <CheckCircle className="w-4 h-4 mr-2" />
                                Renew Subscription
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem>
                              <Calendar className="w-4 h-4 mr-2" />
                              Extend Subscription
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">
                              <XCircle className="w-4 h-4 mr-2" />
                              Suspend Access
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="plans" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {subscriptionPlans.map(plan => {
              const PlanIcon = plan.icon;
              return (
                <Card key={plan.id} className="relative">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <PlanIcon className="w-6 h-6 text-[#007aff]" />
                      <CardTitle>{plan.name}</CardTitle>
                    </div>
                    <div className="text-3xl font-bold">
                      ${plan.price}
                      <span className="text-sm text-muted-foreground">/{plan.duration}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Max Users:</span>
                          <span className="font-medium">{plan.maxUsers === -1 ? 'Unlimited' : plan.maxUsers}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Max Products:</span>
                          <span className="font-medium">{plan.maxProducts === -1 ? 'Unlimited' : plan.maxProducts.toLocaleString()}</span>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="font-medium text-sm">Features:</p>
                        <ul className="space-y-1 text-xs text-muted-foreground">
                          {plan.features.map((feature, index) => (
                            <li key={index} className="flex items-center gap-2">
                              <CheckCircle className="w-3 h-3 text-green-500" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="pt-2 space-y-2">
                        <Button variant="outline" className="w-full">
                          <Edit className="w-4 h-4 mr-2" />
                          Edit Plan
                        </Button>
                        <p className="text-xs text-center text-muted-foreground">
                          Currently used by {mockBusinesses.filter(b => b.plan.id === plan.id).length} businesses
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="payments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Payments</CardTitle>
              <CardDescription>Latest subscription payments and transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { business: 'Santos Pharmacy', amount: 79.99, plan: 'Professional', date: '2025-01-15', status: 'completed' },
                  { business: 'MediCare Drugstore', amount: 29.99, plan: 'Basic', date: '2025-01-15', status: 'completed' },
                  { business: 'Downtown Supermarket', amount: 199.99, plan: 'Enterprise', date: '2025-01-01', status: 'completed' },
                  { business: 'City Parapharmacy', amount: 29.99, plan: 'Basic', date: '2024-12-01', status: 'failed' },
                ].map((payment, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-1">
                      <p className="font-medium">{payment.business}</p>
                      <p className="text-sm text-muted-foreground">{payment.plan} Plan</p>
                      <p className="text-xs text-muted-foreground">{payment.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">${payment.amount}</p>
                      <Badge className={payment.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                        {payment.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue by Plan</CardTitle>
                <CardDescription>Monthly revenue breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Basic Plan:</span>
                    <span className="font-medium">$2,399.20 (128 subs)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Professional Plan:</span>
                    <span className="font-medium">$9,599.00 (120 subs)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Enterprise Plan:</span>
                    <span className="font-medium">$5,999.70 (30 subs)</span>
                  </div>
                  <div className="flex justify-between font-bold pt-2 border-t">
                    <span>Total:</span>
                    <span>$17,997.90</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Subscription Growth</CardTitle>
                <CardDescription>New subscriptions this month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>New Businesses:</span>
                    <span className="font-medium text-green-600">+23</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Renewals:</span>
                    <span className="font-medium text-blue-600">+89</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cancellations:</span>
                    <span className="font-medium text-red-600">-8</span>
                  </div>
                  <div className="flex justify-between font-bold pt-2 border-t">
                    <span>Net Growth:</span>
                    <span className="text-green-600">+104</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}