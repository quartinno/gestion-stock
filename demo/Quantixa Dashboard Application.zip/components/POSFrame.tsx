import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Separator } from "./ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { 
  Scan, 
  Plus, 
  Minus, 
  Trash2, 
  CreditCard, 
  DollarSign, 
  Receipt, 
  User,
  Search,
  ShoppingCart,
  Calculator,
  Percent,
  Save,
  Print
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface POSFrameProps {
  onOpenScanner: () => void;
}

interface CartItem {
  id: string;
  name: string;
  barcode: string;
  price: number;
  quantity: number;
  stock: number;
  category: string;
}

interface Client {
  id: string;
  name: string;
  phone: string;
  creditLimit: number;
  creditBalance: number;
}

export function POSFrame({ onOpenScanner }: POSFrameProps) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'credit' | 'card' | 'mobile'>('cash');
  const [discount, setDiscount] = useState(0);
  const [cashReceived, setCashReceived] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');

  // Mock data - in real app this would come from API
  const mockProducts = [
    { id: '1', name: 'Paracetamol 500mg', barcode: '7891234567890', price: 2.50, stock: 8, category: 'Analgesics' },
    { id: '2', name: 'Amoxicillin 250mg', barcode: '7891234567891', price: 8.90, stock: 45, category: 'Antibiotics' },
    { id: '3', name: 'Vitamin C 1000mg', barcode: '7891234567892', price: 15.80, stock: 12, category: 'Vitamins' },
    { id: '4', name: 'Ibuprofen 400mg', barcode: '7891234567893', price: 3.20, stock: 0, category: 'Analgesics' },
    { id: '5', name: 'Hand Sanitizer 250ml', barcode: '7891234567894', price: 4.50, stock: 67, category: 'Hygiene' }
  ];

  const mockClients = [
    { id: '1', name: 'Maria Santos', phone: '+1 (555) 123-4567', creditLimit: 500, creditBalance: 125.50 },
    { id: '2', name: 'Carlos Rodriguez', phone: '+1 (555) 234-5678', creditLimit: 300, creditBalance: 0 },
    { id: '3', name: 'Ana Garcia', phone: '+1 (555) 345-6789', creditLimit: 200, creditBalance: 245.80 }
  ];

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const discountAmount = (subtotal * discount) / 100;
  const total = subtotal - discountAmount;
  const change = paymentMethod === 'cash' ? Math.max(0, cashReceived - total) : 0;

  const addToCart = (product: typeof mockProducts[0]) => {
    if (product.stock <= 0) {
      toast.error('Product out of stock');
      return;
    }

    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
      if (existingItem.quantity >= product.stock) {
        toast.error('Cannot add more items than available stock');
        return;
      }
      updateQuantity(product.id, existingItem.quantity + 1);
    } else {
      setCart(prev => [...prev, {
        id: product.id,
        name: product.name,
        barcode: product.barcode,
        price: product.price,
        quantity: 1,
        stock: product.stock,
        category: product.category
      }]);
    }
  };

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id);
      return;
    }

    setCart(prev => prev.map(item => {
      if (item.id === id) {
        if (quantity > item.stock) {
          toast.error('Cannot exceed available stock');
          return item;
        }
        return { ...item, quantity };
      }
      return item;
    }));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const clearCart = () => {
    setCart([]);
    setSelectedClient(null);
    setDiscount(0);
    setCashReceived(0);
  };

  const processSale = () => {
    if (cart.length === 0) {
      toast.error('Cart is empty');
      return;
    }

    if (paymentMethod === 'cash' && cashReceived < total) {
      toast.error('Insufficient cash received');
      return;
    }

    if (paymentMethod === 'credit') {
      if (!selectedClient) {
        toast.error('Please select a client for credit sale');
        return;
      }
      
      const availableCredit = selectedClient.creditLimit - selectedClient.creditBalance;
      if (total > availableCredit) {
        toast.error('Insufficient credit limit');
        return;
      }
    }

    // Simulate processing sale
    const saleId = `TXN-${Date.now()}`;
    
    toast.success('Sale completed successfully!', {
      description: `Transaction ${saleId} - Total: $${total.toFixed(2)}`,
      action: {
        label: 'Print Receipt',
        onClick: () => printReceipt(saleId)
      }
    });

    clearCart();
  };

  const printReceipt = (saleId: string) => {
    toast.info('Receipt sent to printer');
  };

  const filteredProducts = mockProducts.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.barcode.includes(searchTerm)
  );

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[#00193b]">Point of Sale</h1>
            <p className="text-gray-600">Process sales and manage transactions</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onOpenScanner}>
              <Scan className="w-4 h-4 mr-2" />
              Scan Product
            </Button>
            <Button variant="outline" onClick={clearCart}>
              <Trash2 className="w-4 h-4 mr-2" />
              Clear Cart
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel - Products */}
        <div className="w-1/2 p-6 overflow-y-auto">
          <Card>
            <CardHeader>
              <CardTitle>Products</CardTitle>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {filteredProducts.map(product => (
                  <Card 
                    key={product.id} 
                    className={`cursor-pointer hover:bg-gray-50 transition-colors ${
                      product.stock <= 0 ? 'opacity-50' : ''
                    }`}
                    onClick={() => addToCart(product)}
                  >
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <p className="font-medium text-sm">{product.name}</p>
                            <p className="text-xs text-muted-foreground">Code: {product.barcode}</p>
                          </div>
                          <Badge variant={product.stock > 0 ? "default" : "destructive"} className="text-xs">
                            {product.stock} left
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-lg font-bold text-[#007aff]">${product.price.toFixed(2)}</p>
                          <Button 
                            size="sm" 
                            disabled={product.stock <= 0}
                            onClick={(e) => {
                              e.stopPropagation();
                              addToCart(product);
                            }}
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Cart & Checkout */}
        <div className="w-1/2 p-6 border-l bg-white flex flex-col">
          {/* Client Selection */}
          <Card className="mb-4">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <User className="w-5 h-5 text-muted-foreground" />
                <Select onValueChange={(value) => {
                  const client = mockClients.find(c => c.id === value) || null;
                  setSelectedClient(client);
                }}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select client (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockClients.map(client => (
                      <SelectItem key={client.id} value={client.id}>
                        <div className="flex items-center justify-between w-full">
                          <span>{client.name}</span>
                          <span className="text-xs text-muted-foreground ml-2">
                            Credit: ${(client.creditLimit - client.creditBalance).toFixed(2)}
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {selectedClient && (
                <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedClient.name}`} />
                      <AvatarFallback>{selectedClient.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{selectedClient.name}</p>
                      <p className="text-xs text-muted-foreground">{selectedClient.phone}</p>
                    </div>
                  </div>
                  <div className="mt-2 text-xs">
                    <p>Credit Limit: ${selectedClient.creditLimit.toFixed(2)}</p>
                    <p>Current Balance: ${selectedClient.creditBalance.toFixed(2)}</p>
                    <p className="font-medium">Available Credit: ${(selectedClient.creditLimit - selectedClient.creditBalance).toFixed(2)}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Cart Items */}
          <Card className="flex-1 flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5" />
                Cart ({cart.length} items)
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto">
              <div className="space-y-3">
                {cart.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <ShoppingCart className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>Cart is empty</p>
                    <p className="text-sm">Scan or click products to add them</p>
                  </div>
                ) : (
                  cart.map(item => (
                    <div key={item.id} className="flex items-center gap-3 p-3 border rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{item.name}</p>
                        <p className="text-xs text-muted-foreground">{item.category}</p>
                        <p className="text-sm font-bold text-[#007aff]">${item.price.toFixed(2)} each</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => removeFromCart(item.id)}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Checkout Panel */}
          {cart.length > 0 && (
            <Card className="mt-4">
              <CardContent className="p-4 space-y-4">
                {/* Discount */}
                <div className="flex items-center gap-2">
                  <Percent className="w-4 h-4" />
                  <Input
                    type="number"
                    placeholder="Discount %"
                    value={discount}
                    onChange={(e) => setDiscount(Math.max(0, Math.min(100, Number(e.target.value))))}
                    className="flex-1"
                  />
                </div>

                {/* Payment Method */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Payment Method</label>
                  <Select value={paymentMethod} onValueChange={(value: any) => setPaymentMethod(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="credit">Credit</SelectItem>
                      <SelectItem value="card">Card</SelectItem>
                      <SelectItem value="mobile">Mobile Payment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Cash Payment */}
                {paymentMethod === 'cash' && (
                  <div>
                    <label className="text-sm font-medium mb-2 block">Cash Received</label>
                    <Input
                      type="number"
                      step="0.01"
                      value={cashReceived}
                      onChange={(e) => setCashReceived(Number(e.target.value))}
                      placeholder="0.00"
                    />
                  </div>
                )}

                <Separator />

                {/* Totals */}
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Discount ({discount}%):</span>
                      <span>-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total:</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                  {paymentMethod === 'cash' && cashReceived > 0 && (
                    <div className="flex justify-between text-muted-foreground">
                      <span>Change:</span>
                      <span>${change.toFixed(2)}</span>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" onClick={() => {}}>
                    <Save className="w-4 h-4 mr-2" />
                    Hold
                  </Button>
                  <Button onClick={processSale} className="bg-[#007aff] hover:bg-[#007aff]/90">
                    <Receipt className="w-4 h-4 mr-2" />
                    Complete Sale
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}