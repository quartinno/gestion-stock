import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { Alert, AlertDescription } from "./ui/alert";
import { 
  Package, 
  Scan, 
  Upload, 
  Plus, 
  X, 
  Save, 
  AlertCircle, 
  CheckCircle2,
  Calendar,
  DollarSign,
  Barcode
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface AddProductProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (product: ProductData) => void;
  onOpenScanner: () => void;
  initialBarcode?: string;
}

export interface ProductData {
  id?: string;
  name: string;
  barcode: string;
  category: string;
  description: string;
  price: string;
  costPrice: string;
  supplier: string;
  sku: string;
  stock: number;
  minStock: number;
  maxStock: number;
  unit: string;
  expirationDate: string;
  location: string;
  tags: string[];
  isActive: boolean;
  taxRate: string;
  discount: string;
  imageUrl?: string;
}

const initialProductData: ProductData = {
  name: '',
  barcode: '',
  category: '',
  description: '',
  price: '',
  costPrice: '',
  supplier: '',
  sku: '',
  stock: 0,
  minStock: 5,
  maxStock: 100,
  unit: 'pcs',
  expirationDate: '',
  location: '',
  tags: [],
  isActive: true,
  taxRate: '0',
  discount: '0'
};

const categories = [
  'Pharmaceuticals',
  'Over-the-Counter',
  'Vitamins & Supplements',
  'Personal Care',
  'Baby Care',
  'Health & Wellness',
  'Medical Devices',
  'First Aid',
  'Beauty & Cosmetics',
  'Household',
  'Other'
];

const suppliers = [
  'MedSupply Co.',
  'PharmaHealth',
  'VitaHealth',
  'WellnessCorp',
  'HealthPlus Distributors',
  'MediCare Supplies',
  'PharmaTech',
  'BioHealth Solutions'
];

const units = ['pcs', 'bottles', 'boxes', 'strips', 'tubes', 'vials', 'packets', 'ml', 'g', 'kg'];

export function AddProduct({ 
  isOpen, 
  onClose, 
  onSave, 
  onOpenScanner, 
  initialBarcode 
}: AddProductProps) {
  const [productData, setProductData] = useState<ProductData>(initialProductData);
  const [newTag, setNewTag] = useState('');
  const [errors, setErrors] = useState<Partial<ProductData>>({});
  const [isLoading, setIsLoading] = useState(false);

  // Set initial barcode when provided
  React.useEffect(() => {
    if (initialBarcode && isOpen) {
      setProductData(prev => ({ ...prev, barcode: initialBarcode }));
    }
  }, [initialBarcode, isOpen]);

  const validateForm = (): boolean => {
    const newErrors: Partial<ProductData> = {};

    if (!productData.name.trim()) newErrors.name = 'Product name is required';
    if (!productData.barcode.trim()) newErrors.barcode = 'Barcode is required';
    if (!productData.category) newErrors.category = 'Category is required';
    if (!productData.price || parseFloat(productData.price) <= 0) {
      newErrors.price = 'Valid price is required';
    }
    if (!productData.supplier) newErrors.supplier = 'Supplier is required';
    if (!productData.sku.trim()) newErrors.sku = 'SKU is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field: keyof ProductData, value: any) => {
    setProductData(prev => ({ ...prev, [field]: value }));
    
    // Clear error for this field when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const addTag = () => {
    if (newTag.trim() && !productData.tags.includes(newTag.trim())) {
      handleInputChange('tags', [...productData.tags, newTag.trim()]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    handleInputChange('tags', productData.tags.filter(tag => tag !== tagToRemove));
  };

  const generateSKU = () => {
    const prefix = productData.category.slice(0, 3).toUpperCase();
    const random = Math.random().toString(36).substr(2, 6).toUpperCase();
    const sku = `${prefix}-${random}`;
    handleInputChange('sku', sku);
    toast.success('SKU generated automatically');
  };

  const handleSave = async () => {
    if (!validateForm()) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsLoading(true);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const finalProduct = {
        ...productData,
        id: `prod_${Date.now()}`,
        price: parseFloat(productData.price).toFixed(2),
        costPrice: parseFloat(productData.costPrice || '0').toFixed(2),
        taxRate: parseFloat(productData.taxRate || '0').toFixed(2),
        discount: parseFloat(productData.discount || '0').toFixed(2)
      };

      onSave(finalProduct);
      
      toast.success('Product added successfully!', {
        description: `${finalProduct.name} has been added to your inventory`,
        action: {
          label: 'View Product',
          onClick: () => console.log('View product details')
        }
      });

      handleClose();
    } catch (error) {
      toast.error('Failed to save product');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setProductData(initialProductData);
    setNewTag('');
    setErrors({});
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Add New Product
          </DialogTitle>
          <DialogDescription>
            Fill in the product details below. Required fields are marked with *
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-6 pr-2">
          {/* Basic Information */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Product Name *</Label>
                  <Input
                    id="name"
                    placeholder="Enter product name"
                    value={productData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    className={errors.name ? 'border-red-500' : ''}
                  />
                  {errors.name && (
                    <p className="text-sm text-red-500">{errors.name}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="barcode">Barcode *</Label>
                  <div className="flex gap-2">
                    <Input
                      id="barcode"
                      placeholder="Enter or scan barcode"
                      value={productData.barcode}
                      onChange={(e) => handleInputChange('barcode', e.target.value)}
                      className={`flex-1 font-mono ${errors.barcode ? 'border-red-500' : ''}`}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={onOpenScanner}
                      className="px-3"
                    >
                      <Scan className="w-4 h-4" />
                    </Button>
                  </div>
                  {errors.barcode && (
                    <p className="text-sm text-red-500">{errors.barcode}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category *</Label>
                  <Select
                    value={productData.category}
                    onValueChange={(value) => handleInputChange('category', value)}
                  >
                    <SelectTrigger className={errors.category ? 'border-red-500' : ''}>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.category && (
                    <p className="text-sm text-red-500">{errors.category}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sku">SKU *</Label>
                  <div className="flex gap-2">
                    <Input
                      id="sku"
                      placeholder="Product SKU"
                      value={productData.sku}
                      onChange={(e) => handleInputChange('sku', e.target.value)}
                      className={`flex-1 ${errors.sku ? 'border-red-500' : ''}`}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={generateSKU}
                      className="px-3"
                      disabled={!productData.category}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  {errors.sku && (
                    <p className="text-sm text-red-500">{errors.sku}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Enter product description"
                  value={productData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Pricing Information */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Pricing Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Selling Price *</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={productData.price}
                    onChange={(e) => handleInputChange('price', e.target.value)}
                    className={errors.price ? 'border-red-500' : ''}
                  />
                  {errors.price && (
                    <p className="text-sm text-red-500">{errors.price}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="costPrice">Cost Price</Label>
                  <Input
                    id="costPrice"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={productData.costPrice}
                    onChange={(e) => handleInputChange('costPrice', e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="taxRate">Tax Rate (%)</Label>
                  <Input
                    id="taxRate"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={productData.taxRate}
                    onChange={(e) => handleInputChange('taxRate', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Inventory Information */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Inventory Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="stock">Current Stock</Label>
                  <Input
                    id="stock"
                    type="number"
                    min="0"
                    placeholder="0"
                    value={productData.stock}
                    onChange={(e) => handleInputChange('stock', parseInt(e.target.value) || 0)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="minStock">Min Stock Alert</Label>
                  <Input
                    id="minStock"
                    type="number"
                    min="0"
                    placeholder="5"
                    value={productData.minStock}
                    onChange={(e) => handleInputChange('minStock', parseInt(e.target.value) || 0)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxStock">Max Stock</Label>
                  <Input
                    id="maxStock"
                    type="number"
                    min="0"
                    placeholder="100"
                    value={productData.maxStock}
                    onChange={(e) => handleInputChange('maxStock', parseInt(e.target.value) || 0)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="unit">Unit</Label>
                  <Select
                    value={productData.unit}
                    onValueChange={(value) => handleInputChange('unit', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {units.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="supplier">Supplier *</Label>
                  <Select
                    value={productData.supplier}
                    onValueChange={(value) => handleInputChange('supplier', value)}
                  >
                    <SelectTrigger className={errors.supplier ? 'border-red-500' : ''}>
                      <SelectValue placeholder="Select supplier" />
                    </SelectTrigger>
                    <SelectContent>
                      {suppliers.map((supplier) => (
                        <SelectItem key={supplier} value={supplier}>
                          {supplier}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.supplier && (
                    <p className="text-sm text-red-500">{errors.supplier}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="expirationDate">Expiration Date</Label>
                  <Input
                    id="expirationDate"
                    type="date"
                    value={productData.expirationDate}
                    onChange={(e) => handleInputChange('expirationDate', e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Storage Location</Label>
                  <Input
                    id="location"
                    placeholder="e.g., Aisle A, Shelf 1"
                    value={productData.location}
                    onChange={(e) => handleInputChange('location', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tags */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Product Tags</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {productData.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                    {tag}
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="ml-1 hover:text-red-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>

              <div className="flex gap-2">
                <Input
                  placeholder="Add a tag..."
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addTag();
                    }
                  }}
                  className="flex-1"
                />
                <Button type="button" variant="outline" onClick={addTag}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer Actions */}
        <Separator />
        <div className="flex justify-between items-center pt-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <AlertCircle className="w-4 h-4" />
            Fields marked with * are required
          </div>
          
          <div className="flex gap-3">
            <Button variant="outline" onClick={handleClose} disabled={isLoading}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={isLoading}>
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save Product
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}