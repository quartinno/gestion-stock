import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { AddClientForm } from "./AddClientForm";
import { 
  Plus,
  Search,
  Filter,
  Eye,
  MoreHorizontal,
  Users,
  CreditCard,
  AlertCircle,
  UserCheck,
  UserX,
  DollarSign,
  TrendingUp,
  Clock,
  Phone,
  Mail,
  MapPin
} from 'lucide-react';

export function ClientsFrame() {
  const handleClientAdded = (newClient: any) => {
    // In a real application, you would add the client to your state/database
    console.log('New client added:', newClient);
    // Refresh the client list or update local state
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#00193b]">Client Management</h1>
          <p className="text-gray-600">Manage customer accounts and credit tracking</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <AddClientForm onClientAdded={handleClientAdded} />
        </div>
      </div>

      {/* Client Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,247</div>
            <p className="text-xs text-muted-foreground">+89 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Credits</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">156</div>
            <p className="text-xs text-muted-foreground">Clients with credit</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding Credit</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$24,567</div>
            <p className="text-xs text-muted-foreground">Total owed</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overdue Accounts</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">12</div>
            <p className="text-xs text-muted-foreground">Need attention</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input placeholder="Search clients by name, phone, or email..." className="pl-9" />
        </div>
        <Badge variant="secondary">1,247 clients</Badge>
      </div>

      {/* Client List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {[
          {
            name: "Maria Santos",
            phone: "+1 (555) 123-4567",
            email: "maria.santos@email.com",
            address: "123 Main St, City Center",
            creditLimit: 500,
            creditBalance: 125.50,
            status: "active",
            lastPurchase: "2 days ago",
            totalPurchases: 1250.75,
            visits: 34
          },
          {
            name: "Carlos Rodriguez",
            phone: "+1 (555) 234-5678",
            email: "carlos.r@email.com",
            address: "456 Oak Ave, Downtown",
            creditLimit: 300,
            creditBalance: 0,
            status: "active",
            lastPurchase: "1 week ago",
            totalPurchases: 867.40,
            visits: 23
          },
          {
            name: "Ana Garcia",
            phone: "+1 (555) 345-6789",
            email: "ana.garcia@email.com",
            address: "789 Pine St, Uptown",
            creditLimit: 200,
            creditBalance: 245.80,
            status: "overdue",
            lastPurchase: "3 weeks ago",
            totalPurchases: 2150.30,
            visits: 67
          },
          {
            name: "Juan Lopez",
            phone: "+1 (555) 456-7890",
            email: "juan.lopez@email.com",
            address: "321 Elm St, Suburbs",
            creditLimit: 400,
            creditBalance: 89.25,
            status: "active",
            lastPurchase: "5 days ago",
            totalPurchases: 945.60,
            visits: 28
          },
          {
            name: "Sofia Martinez",
            phone: "+1 (555) 567-8901",
            email: "sofia.m@email.com",
            address: "654 Maple Dr, North Side",
            creditLimit: 150,
            creditBalance: 150.00,
            status: "credit_limit",
            lastPurchase: "1 month ago",
            totalPurchases: 567.85,
            visits: 15
          },
          {
            name: "Diego Fernandez",
            phone: "+1 (555) 678-9012",
            email: "diego.f@email.com",
            address: "987 Cedar Ln, East End",
            creditLimit: 600,
            creditBalance: 0,
            status: "inactive",
            lastPurchase: "3 months ago",
            totalPurchases: 1789.20,
            visits: 45
          }
        ].map((client, index) => (
          <Card key={index} className={`${
            client.status === 'overdue' ? 'border-red-200 bg-red-50' :
            client.status === 'credit_limit' ? 'border-orange-200 bg-orange-50' :
            client.status === 'inactive' ? 'border-gray-200 bg-gray-50' : ''
          }`}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${client.name}`} />
                    <AvatarFallback>{client.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-lg">{client.name}</CardTitle>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Phone className="w-3 h-3" />
                      <span>{client.phone}</span>
                    </div>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem>
                      <Eye className="w-4 h-4 mr-2" />
                      View Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <CreditCard className="w-4 h-4 mr-2" />
                      Credit History
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <DollarSign className="w-4 h-4 mr-2" />
                      Process Payment
                    </DropdownMenuItem>
                    <DropdownMenuItem>Edit Client</DropdownMenuItem>
                    <DropdownMenuItem className="text-red-600">Delete</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="w-3 h-3" />
                  <span>{client.email}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-3 h-3" />
                  <span>{client.address}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div>
                    <p className="text-xs text-muted-foreground">Credit Balance</p>
                    <p className={`font-medium ${client.creditBalance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      ${client.creditBalance.toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Credit Limit</p>
                    <p className="font-medium">${client.creditLimit}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Total Purchases</p>
                    <p className="font-medium">${client.totalPurchases.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Visits</p>
                    <p className="font-medium">{client.visits} times</p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <Badge 
                    variant={client.status === 'active' ? 'default' : 
                            client.status === 'overdue' ? 'destructive' :
                            client.status === 'credit_limit' ? 'secondary' : 'outline'}
                    className={
                      client.status === 'active' ? 'bg-green-100 text-green-800' :
                      client.status === 'overdue' ? 'bg-red-100 text-red-800' :
                      client.status === 'credit_limit' ? 'bg-orange-100 text-orange-800' :
                      'bg-gray-100 text-gray-800'
                    }
                  >
                    {client.status === 'active' ? 'Active' :
                     client.status === 'overdue' ? 'Overdue' :
                     client.status === 'credit_limit' ? 'Credit Limit' : 'Inactive'}
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    <span>Last: {client.lastPurchase}</span>
                  </div>
                </div>

                {client.creditBalance > 0 && (
                  <div className="pt-2">
                    <Button size="sm" variant="outline" className="w-full">
                      <DollarSign className="w-3 h-3 mr-1" />
                      Process Payment
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Credit Transactions</CardTitle>
            <CardDescription>Latest credit activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { client: "Maria Santos", type: "credit_sale", amount: "$45.80", time: "2 hours ago" },
                { client: "Ana Garcia", type: "payment", amount: "$100.00", time: "1 day ago" },
                { client: "Juan Lopez", type: "credit_sale", amount: "$23.45", time: "2 days ago" },
                { client: "Sofia Martinez", type: "credit_sale", amount: "$67.20", time: "3 days ago" },
              ].map((transaction, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">{transaction.client}</p>
                    <p className="text-xs text-muted-foreground">{transaction.time}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${transaction.type === 'payment' ? 'text-green-600' : 'text-red-600'}`}>
                      {transaction.type === 'payment' ? '+' : '-'}{transaction.amount}
                    </p>
                    <Badge variant="outline" className="text-xs">
                      {transaction.type.replace('_', ' ')}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Clients</CardTitle>
            <CardDescription>Highest spending customers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { name: "Ana Garcia", spent: "$2,150.30", visits: 67 },
                { name: "Diego Fernandez", spent: "$1,789.20", visits: 45 },
                { name: "Maria Santos", spent: "$1,250.75", visits: 34 },
                { name: "Juan Lopez", spent: "$945.60", visits: 28 },
              ].map((client, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-muted-foreground">#{index + 1}</span>
                    <span className="text-sm font-medium">{client.name}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{client.spent}</p>
                    <p className="text-xs text-muted-foreground">{client.visits} visits</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Credit Summary</CardTitle>
            <CardDescription>Credit status overview</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-2xl font-bold">$24,567</div>
                <p className="text-sm text-muted-foreground">Total Outstanding</p>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Current (0-30 days)</span>
                  <span className="font-medium">$18,450</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Overdue (30+ days)</span>
                  <span className="font-medium text-orange-600">$4,230</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Critical (60+ days)</span>
                  <span className="font-medium text-red-600">$1,887</span>
                </div>
              </div>

              <Button variant="outline" className="w-full">
                <TrendingUp className="w-4 h-4 mr-2" />
                View Credit Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}