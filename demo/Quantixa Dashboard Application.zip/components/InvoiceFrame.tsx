import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { 
  Plus,
  Search,
  Filter,
  Eye,
  MoreHorizontal,
  FileText,
  Download,
  Send,
  DollarSign,
  Calendar,
  User,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Edit,
  Trash2,
  Printer
} from 'lucide-react';

export function InvoiceFrame() {
  const [activeTab, setActiveTab] = useState('invoices');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Mock invoice data
  const mockInvoices = [
    {
      id: 'INV-001',
      number: 'INV-2025-001',
      client: { name: 'Maria Santos', email: 'maria@email.com', phone: '+1 (555) 123-4567' },
      date: '2025-01-15',
      dueDate: '2025-01-30',
      items: [
        { name: 'Paracetamol 500mg', quantity: 5, price: 2.50, total: 12.50 },
        { name: 'Vitamin C 1000mg', quantity: 2, price: 15.80, total: 31.60 }
      ],
      subtotal: 44.10,
      tax: 4.41,
      discount: 0,
      total: 48.51,
      status: 'sent',
      paymentStatus: 'pending',
      paymentMethod: 'credit'
    },
    {
      id: 'INV-002',
      number: 'INV-2025-002',
      client: { name: 'Carlos Rodriguez', email: 'carlos@email.com', phone: '+1 (555) 234-5678' },
      date: '2025-01-14',
      dueDate: '2025-01-29',
      items: [
        { name: 'Amoxicillin 250mg', quantity: 3, price: 8.90, total: 26.70 },
        { name: 'Hand Sanitizer', quantity: 2, price: 4.50, total: 9.00 }
      ],
      subtotal: 35.70,
      tax: 3.57,
      discount: 5.00,
      total: 34.27,
      status: 'paid',
      paymentStatus: 'paid',
      paymentMethod: 'cash'
    },
    {
      id: 'INV-003',
      number: 'INV-2025-003',
      client: { name: 'Ana Garcia', email: 'ana@email.com', phone: '+1 (555) 345-6789' },
      date: '2025-01-10',
      dueDate: '2025-01-25',
      items: [
        { name: 'Ibuprofen 400mg', quantity: 4, price: 3.20, total: 12.80 }
      ],
      subtotal: 12.80,
      tax: 1.28,
      discount: 0,
      total: 14.08,
      status: 'sent',
      paymentStatus: 'overdue',
      paymentMethod: 'credit'
    }
  ];

  const filteredInvoices = mockInvoices.filter(invoice => {
    const matchesSearch = invoice.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         invoice.client.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || 
                         (statusFilter === 'paid' && invoice.paymentStatus === 'paid') ||
                         (statusFilter === 'pending' && invoice.paymentStatus === 'pending') ||
                         (statusFilter === 'overdue' && invoice.paymentStatus === 'overdue');
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      case 'cancelled': return 'bg-gray-100 text-gray-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getPaymentStatusIcon = (status: string) => {
    switch (status) {
      case 'paid': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-600" />;
      case 'overdue': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      default: return <XCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#00193b]">Invoice Management</h1>
          <p className="text-gray-600">Create, track, and manage invoices and payments</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button className="bg-[#007aff] hover:bg-[#007aff]/90">
            <Plus className="w-4 h-4 mr-2" />
            New Invoice
          </Button>
        </div>
      </div>

      {/* Invoice Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Invoices</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">124</div>
            <p className="text-xs text-muted-foreground">+12 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding Amount</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$12,450</div>
            <p className="text-xs text-muted-foreground">Pending collection</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Paid This Month</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$28,750</div>
            <p className="text-xs text-muted-foreground">89 invoices paid</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overdue</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">8</div>
            <p className="text-xs text-muted-foreground">Need attention</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="invoices">All Invoices</TabsTrigger>
          <TabsTrigger value="pending">Pending Payment</TabsTrigger>
          <TabsTrigger value="overdue">Overdue</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="invoices" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search invoices..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="secondary">{filteredInvoices.length} invoices</Badge>
          </div>

          <div className="space-y-4">
            {filteredInvoices.map(invoice => (
              <Card key={invoice.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-3">
                      <div className="flex items-center gap-4">
                        <div>
                          <p className="font-bold text-lg">{invoice.number}</p>
                          <p className="text-sm text-muted-foreground">
                            Created: {invoice.date} | Due: {invoice.dueDate}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          {getPaymentStatusIcon(invoice.paymentStatus)}
                          <Badge className={getStatusColor(invoice.paymentStatus)}>
                            {invoice.paymentStatus}
                          </Badge>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{invoice.client.name}</p>
                            <p className="text-sm text-muted-foreground">{invoice.client.email}</p>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Items:</p>
                        {invoice.items.map((item, index) => (
                          <p key={index} className="text-sm">
                            {item.quantity}x {item.name} - ${item.total.toFixed(2)}
                          </p>
                        ))}
                      </div>
                    </div>

                    <div className="text-right space-y-2">
                      <div className="text-2xl font-bold text-[#007aff]">
                        ${invoice.total.toFixed(2)}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Payment: {invoice.paymentMethod}
                      </p>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Download className="w-4 h-4 mr-2" />
                            Download PDF
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Send className="w-4 h-4 mr-2" />
                            Send Email
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Printer className="w-4 h-4 mr-2" />
                            Print
                          </DropdownMenuItem>
                          {invoice.paymentStatus !== 'paid' && (
                            <>
                              <DropdownMenuItem>
                                <DollarSign className="w-4 h-4 mr-2" />
                                Record Payment
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Edit className="w-4 h-4 mr-2" />
                                Edit Invoice
                              </DropdownMenuItem>
                            </>
                          )}
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Cancel Invoice
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pending Payment Invoices</CardTitle>
              <CardDescription>Invoices awaiting payment from clients</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredInvoices.filter(inv => inv.paymentStatus === 'pending').map(invoice => (
                  <div key={invoice.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-1">
                      <p className="font-medium">{invoice.number}</p>
                      <p className="text-sm text-muted-foreground">{invoice.client.name}</p>
                      <p className="text-xs text-muted-foreground">Due: {invoice.dueDate}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">${invoice.total.toFixed(2)}</p>
                      <Button size="sm" variant="outline">
                        <DollarSign className="w-3 h-3 mr-1" />
                        Record Payment
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overdue" className="space-y-4">
          <Card className="border-red-200">
            <CardHeader>
              <CardTitle className="text-red-800">Overdue Invoices</CardTitle>
              <CardDescription>Invoices that are past their due date</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredInvoices.filter(inv => inv.paymentStatus === 'overdue').map(invoice => (
                  <div key={invoice.id} className="flex items-center justify-between p-4 border border-red-200 bg-red-50 rounded-lg">
                    <div className="space-y-1">
                      <p className="font-medium">{invoice.number}</p>
                      <p className="text-sm text-muted-foreground">{invoice.client.name}</p>
                      <p className="text-xs text-red-600">Overdue since: {invoice.dueDate}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-red-600">${invoice.total.toFixed(2)}</p>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Send className="w-3 h-3 mr-1" />
                          Send Reminder
                        </Button>
                        <Button size="sm" variant="outline">
                          <DollarSign className="w-3 h-3 mr-1" />
                          Record Payment
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Invoice Summary</CardTitle>
                <CardDescription>Monthly invoice statistics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Total Invoiced:</span>
                    <span className="font-medium">$45,230.50</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Paid:</span>
                    <span className="font-medium text-green-600">$32,780.50</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Outstanding:</span>
                    <span className="font-medium text-orange-600">$12,450.00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Overdue:</span>
                    <span className="font-medium text-red-600">$2,150.00</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Breakdown by payment method</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Cash:</span>
                    <span className="font-medium">$18,450.00 (56%)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Credit:</span>
                    <span className="font-medium">$12,230.50 (37%)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Card:</span>
                    <span className="font-medium">$2,100.00 (7%)</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Export Reports</CardTitle>
              <CardDescription>Generate detailed reports for accounting</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Invoice List (CSV)
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Payment Report (PDF)
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Tax Summary (PDF)
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}