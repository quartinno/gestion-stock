import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { AddProduct, type ProductData } from "./AddProduct";
import { 
  Plus,
  Search,
  Filter,
  Eye,
  MoreHorizontal,
  Package,
  Scan,
  AlertTriangle,
  Calendar,
  Truck,
  BarChart3,
  Edit,
  Trash2,
  TrendingDown,
  TrendingUp,
  Clock
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface InventoryFrameProps {
  onOpenScanner: () => void;
}

export function InventoryFrame({ onOpenScanner }: InventoryFrameProps) {
  const [activeTab, setActiveTab] = useState('products');
  const [addProductOpen, setAddProductOpen] = useState(false);
  const [scannerInitiatedBarcode, setScannerInitiatedBarcode] = useState<string | undefined>();

  const handleAddProduct = () => {
    setScannerInitiatedBarcode(undefined);
    setAddProductOpen(true);
  };

  const handleScanForNewProduct = () => {
    onOpenScanner();
  };

  const handleSaveProduct = (product: ProductData) => {
    // Here you would typically save to your backend/state management
    console.log('Saving product:', product);
    
    toast.success(`Product "${product.name}" added successfully!`, {
      description: `Barcode: ${product.barcode} | Stock: ${product.stock} ${product.unit}`,
      action: {
        label: 'View Product',
        onClick: () => console.log('View product details')
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#00193b]">Inventory Management</h1>
          <p className="text-gray-600">Manage your pharmaceutical inventory and stock levels</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline"
            onClick={onOpenScanner}
            className="hover:bg-[#007aff] hover:text-white transition-colors"
          >
            <Scan className="w-4 h-4 mr-2" />
            Scan Barcode
          </Button>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button 
            className="bg-[#007aff] hover:bg-[#007aff]/90"
            onClick={handleAddProduct}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Product
          </Button>
        </div>
      </div>

      {/* Inventory Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2,847</div>
            <p className="text-xs text-muted-foreground">+147 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">23</div>
            <p className="text-xs text-muted-foreground">Needs attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
            <Calendar className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">8</div>
            <p className="text-xs text-muted-foreground">Next 30 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inventory Value</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$187,450</div>
            <p className="text-xs text-muted-foreground">+$12,340 this month</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
          <TabsTrigger value="movements">Stock Movements</TabsTrigger>
        </TabsList>

        <TabsContent value="products" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input placeholder="Search by name, barcode, or category..." className="pl-9" />
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={onOpenScanner}
              className="hover:bg-[#007aff] hover:text-white transition-colors"
            >
              <Scan className="w-4 h-4 mr-2" />
              Quick Scan
            </Button>
            <Badge variant="secondary">2,847 products</Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { 
                name: "Paracetamol 500mg", 
                barcode: "7891234567890", 
                price: "$2.50", 
                cost: "$1.20",
                stock: 8, 
                minimum: 50, 
                status: "low_stock", 
                category: "Analgesics",
                supplier: "MedSupply Co.",
                expiry: "2025-12-15"
              },
              { 
                name: "Amoxicillin 250mg", 
                barcode: "7891234567891", 
                price: "$8.90", 
                cost: "$4.20",
                stock: 45, 
                minimum: 30, 
                status: "in_stock", 
                category: "Antibiotics",
                supplier: "PharmaHealth",
                expiry: "2025-09-20"
              },
              { 
                name: "Vitamin C 1000mg", 
                barcode: "7891234567892", 
                price: "$15.80", 
                cost: "$7.50",
                stock: 12, 
                minimum: 30, 
                status: "low_stock", 
                category: "Vitamins",
                supplier: "VitaHealth",
                expiry: "2026-03-10"
              },
              { 
                name: "Ibuprofen 400mg", 
                barcode: "7891234567893", 
                price: "$3.20", 
                cost: "$1.80",
                stock: 0, 
                minimum: 40, 
                status: "out_of_stock", 
                category: "Analgesics",
                supplier: "MedSupply Co.",
                expiry: "2025-11-30"
              },
              { 
                name: "Hand Sanitizer 250ml", 
                barcode: "7891234567894", 
                price: "$4.50", 
                cost: "$2.10",
                stock: 67, 
                minimum: 25, 
                status: "in_stock", 
                category: "Hygiene",
                supplier: "CleanCare",
                expiry: "2025-08-15"
              },
              { 
                name: "Aspirin 100mg", 
                barcode: "7891234567895", 
                price: "$1.80", 
                cost: "$0.90",
                stock: 3, 
                minimum: 40, 
                status: "critical", 
                category: "Analgesics",
                supplier: "MedSupply Co.",
                expiry: "2025-07-25"
              },
            ].map((product, index) => (
              <Card key={index} className={`${product.status === 'out_of_stock' ? 'border-red-200 bg-red-50' : 
                                                product.status === 'critical' ? 'border-red-200 bg-red-50' :
                                                product.status === 'low_stock' ? 'border-orange-200 bg-orange-50' : ''}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{product.name}</CardTitle>
                      <CardDescription className="text-xs text-muted-foreground">
                        Code: {product.barcode}
                      </CardDescription>
                      <CardDescription className="text-lg font-bold text-[#007aff]">
                        {product.price}
                      </CardDescription>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem>
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit Product
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Package className="w-4 h-4 mr-2" />
                          Stock Movement
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Truck className="w-4 h-4 mr-2" />
                          Reorder
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={onOpenScanner}
                          className="text-[#007aff]"
                        >
                          <Scan className="w-4 h-4 mr-2" />
                          Scan Barcode
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Stock Level</span>
                      <span className={`font-medium ${product.status === 'out_of_stock' ? 'text-red-600' : 
                                                      product.status === 'critical' ? 'text-red-600' :
                                                      product.status === 'low_stock' ? 'text-orange-600' : 'text-green-600'}`}>
                        {product.stock} / {product.minimum}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Category</span>
                      <Badge variant="outline" className="text-xs">{product.category}</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Supplier</span>
                      <span className="text-xs">{product.supplier}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Expires</span>
                      <span className="text-xs">{product.expiry}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Cost Price</span>
                      <span className="text-xs font-medium">{product.cost}</span>
                    </div>
                    <div className="pt-2">
                      <Badge 
                        variant={product.status === 'in_stock' ? 'default' : 
                                product.status === 'low_stock' ? 'secondary' : 'destructive'}
                        className={
                          product.status === 'in_stock' ? 'bg-green-100 text-green-800' :
                          product.status === 'low_stock' ? 'bg-orange-100 text-orange-800' : 
                          'bg-red-100 text-red-800'
                        }
                      >
                        {product.status === 'in_stock' ? 'In Stock' : 
                         product.status === 'low_stock' ? 'Low Stock' :
                         product.status === 'critical' ? 'Critical' : 'Out of Stock'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Product Categories</CardTitle>
              <CardDescription>Organize your inventory by categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { name: "Analgesics", products: 156, subcategories: 8 },
                  { name: "Antibiotics", products: 89, subcategories: 12 },
                  { name: "Vitamins & Supplements", products: 234, subcategories: 15 },
                  { name: "Hygiene Products", products: 167, subcategories: 6 },
                  { name: "Baby Care", products: 78, subcategories: 9 },
                  { name: "First Aid", products: 45, subcategories: 4 },
                ].map((category, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <h3 className="font-medium">{category.name}</h3>
                      <p className="text-sm text-muted-foreground">{category.products} products</p>
                      <p className="text-xs text-muted-foreground">{category.subcategories} subcategories</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="suppliers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Suppliers</CardTitle>
              <CardDescription>Manage your pharmaceutical suppliers</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: "MedSupply Co.", contact: "John Smith", products: 456, email: "orders@medsupply.com", phone: "+1 (555) 123-4567" },
                  { name: "PharmaHealth", contact: "Maria Garcia", products: 289, email: "supply@pharmahealth.com", phone: "+1 (555) 234-5678" },
                  { name: "VitaHealth", contact: "Carlos Rodriguez", products: 134, email: "orders@vitahealth.com", phone: "+1 (555) 345-6789" },
                  { name: "CleanCare", contact: "Ana Lopez", products: 67, email: "sales@cleancare.com", phone: "+1 (555) 456-7890" },
                ].map((supplier, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-1">
                      <p className="font-medium">{supplier.name}</p>
                      <p className="text-sm text-muted-foreground">Contact: {supplier.contact}</p>
                      <p className="text-sm text-muted-foreground">{supplier.email} • {supplier.phone}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{supplier.products} products</p>
                      <Button size="sm" variant="outline">
                        <Truck className="w-3 h-3 mr-1" />
                        Order
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="movements" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Stock Movements</CardTitle>
              <CardDescription>Track all inventory movements and adjustments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { 
                    product: "Paracetamol 500mg", 
                    type: "stock_out", 
                    quantity: -5, 
                    reference: "Sale #TXN-001", 
                    user: "Ana Rodriguez",
                    time: "2 hours ago" 
                  },
                  { 
                    product: "Vitamin C 1000mg", 
                    type: "stock_in", 
                    quantity: +50, 
                    reference: "Purchase Order #PO-234", 
                    user: "Carlos Manager",
                    time: "5 hours ago" 
                  },
                  { 
                    product: "Hand Sanitizer 250ml", 
                    type: "adjustment", 
                    quantity: -2, 
                    reference: "Damaged items", 
                    user: "Maria Admin",
                    time: "1 day ago" 
                  },
                  { 
                    product: "Ibuprofen 400mg", 
                    type: "expired", 
                    quantity: -15, 
                    reference: "Expiry removal", 
                    user: "John Supervisor",
                    time: "2 days ago" 
                  },
                ].map((movement, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-full ${
                        movement.type === 'stock_in' ? 'bg-green-100' :
                        movement.type === 'stock_out' ? 'bg-blue-100' :
                        movement.type === 'adjustment' ? 'bg-yellow-100' :
                        'bg-red-100'
                      }`}>
                        {movement.type === 'stock_in' ? <TrendingUp className="w-4 h-4 text-green-600" /> :
                         movement.type === 'stock_out' ? <TrendingDown className="w-4 h-4 text-blue-600" /> :
                         movement.type === 'adjustment' ? <Edit className="w-4 h-4 text-yellow-600" /> :
                         <Clock className="w-4 h-4 text-red-600" />}
                      </div>
                      <div>
                        <p className="font-medium">{movement.product}</p>
                        <p className="text-sm text-muted-foreground">{movement.reference}</p>
                        <p className="text-xs text-muted-foreground">By {movement.user} • {movement.time}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-medium ${movement.quantity > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {movement.quantity > 0 ? '+' : ''}{movement.quantity}
                      </p>
                      <Badge variant="outline" className="text-xs">
                        {movement.type.replace('_', ' ')}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AddProduct
        isOpen={addProductOpen}
        onClose={() => setAddProductOpen(false)}
        onSave={handleSaveProduct}
        onOpenScanner={handleScanForNewProduct}
        initialBarcode={scannerInitiatedBarcode}
      />
    </div>
  );
}