import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { 
  BarChart3, 
  Users, 
  Package, 
  ShoppingCart, 
  Plus,
  DollarSign,
  AlertTriangle,
  TrendingUp,
  Calendar,
  Clock,
  UserCheck,
  CreditCard,
  Truck,
  Scan,
  AlertCircle
} from 'lucide-react';

interface DashboardFrameProps {
  onOpenScanner: () => void;
}

export function DashboardFrame({ onOpenScanner }: DashboardFrameProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#00193b]">Stock Management Dashboard</h1>
          <p className="text-gray-600">Overview of your pharmacy inventory and business operations</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline"
            onClick={onOpenScanner}
            className="hover:bg-[#007aff] hover:text-white transition-colors"
          >
            <Scan className="w-4 h-4 mr-2" />
            Scan Barcode
          </Button>
          <Button className="bg-[#007aff] hover:bg-[#007aff]/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Product
          </Button>
        </div>
      </div>

      {/* Critical Alerts */}
      <Card className="border-red-200 bg-red-50">
        <CardHeader>
          <CardTitle className="text-red-800 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Critical Inventory Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">23</div>
              <p className="text-sm text-red-600">Low Stock Items</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">8</div>
              <p className="text-sm text-orange-600">Expiring Soon</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">12</div>
              <p className="text-sm text-yellow-600">Out of Stock</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$2,847.60</div>
            <p className="text-xs text-muted-foreground">
              +18.2% from yesterday
            </p>
            <Progress value={78} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2,847</div>
            <p className="text-xs text-muted-foreground">
              147 added this week
            </p>
            <Progress value={85} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Clients</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,247</div>
            <p className="text-xs text-muted-foreground">
              89 new this month
            </p>
            <Progress value={92} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Sales</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">164</div>
            <p className="text-xs text-muted-foreground">
              +24 from yesterday
            </p>
            <Progress value={67} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Sales */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Sales</CardTitle>
            <CardDescription>Latest transactions in your pharmacy</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { id: "TXN-001", client: "Maria Santos", amount: "$45.80", items: "3 items", time: "2 min ago", payment: "Cash" },
                { id: "TXN-002", client: "John Cruz", amount: "$129.50", items: "7 items", time: "8 min ago", payment: "Card" },
                { id: "TXN-003", client: "Ana Garcia", amount: "$23.20", items: "2 items", time: "12 min ago", payment: "Credit" },
                { id: "TXN-004", client: "Carlos Lopez", amount: "$87.40", items: "5 items", time: "18 min ago", payment: "Cash" },
              ].map((sale) => (
                <div key={sale.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">{sale.id}</p>
                    <p className="text-xs text-muted-foreground">{sale.client} • {sale.items}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{sale.amount}</p>
                    <div className="flex items-center gap-1">
                      <Badge variant="outline" className="text-xs">{sale.payment}</Badge>
                      <span className="text-xs text-muted-foreground">{sale.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Low Stock Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-orange-500" />
              Low Stock Alerts
            </CardTitle>
            <CardDescription>Products that need restocking</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: "Paracetamol 500mg", barcode: "7891234567890", current: 8, minimum: 50, supplier: "MedSupply Co." },
                { name: "Vitamin C 1000mg", barcode: "7891234567891", current: 12, minimum: 30, supplier: "VitaHealth" },
                { name: "Bandages (Pack)", barcode: "7891234567892", current: 5, minimum: 25, supplier: "MedEquip Ltd" },
                { name: "Hand Sanitizer 250ml", barcode: "7891234567893", current: 3, minimum: 40, supplier: "CleanCare" },
              ].map((product, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg bg-orange-50">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">{product.name}</p>
                    <p className="text-xs text-muted-foreground">Code: {product.barcode}</p>
                    <p className="text-xs text-muted-foreground">Supplier: {product.supplier}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-orange-600">
                      {product.current} / {product.minimum}
                    </p>
                    <Button size="sm" variant="outline" className="text-xs">
                      <Truck className="w-3 h-3 mr-1" />
                      Reorder
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Frequently used operations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <Button 
                variant="outline" 
                className="h-20 flex-col gap-2 hover:bg-[#007aff] hover:text-white transition-colors"
                onClick={onOpenScanner}
              >
                <Scan className="w-6 h-6" />
                <span>Scan Product</span>
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2">
                <ShoppingCart className="w-6 h-6" />
                <span>New Sale</span>
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2">
                <Users className="w-6 h-6" />
                <span>Add Client</span>
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2">
                <Package className="w-6 h-6" />
                <span>Stock Count</span>
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2">
                <CreditCard className="w-6 h-6" />
                <span>Client Credit</span>
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2">
                <BarChart3 className="w-6 h-6" />
                <span>Reports</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Business Status */}
        <Card>
          <CardHeader>
            <CardTitle>Business Status</CardTitle>
            <CardDescription>Your subscription and business health</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Plan Status</span>
              <Badge className="bg-green-100 text-green-800">Professional Plan</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Next Billing</span>
              <span className="text-sm">August 20, 2025</span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Staff Members</span>
                <span>8/15</span>
              </div>
              <Progress value={53} />
              <div className="flex justify-between text-sm">
                <span>Product Catalog</span>
                <span>2,847/5,000</span>
              </div>
              <Progress value={57} />
            </div>
            <div className="pt-2">
              <div className="flex items-center gap-2 text-sm text-green-600">
                <Clock className="w-4 h-4" />
                <span>All systems operational</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}