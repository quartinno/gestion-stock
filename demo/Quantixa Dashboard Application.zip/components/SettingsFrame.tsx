import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Progress } from "./ui/progress";
import { Separator } from "./ui/separator";
import { 
  CreditCard,
  MessageSquare,
  Download
} from 'lucide-react';

export function SettingsFrame() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#00193b]">Settings</h1>
          <p className="text-gray-600">Manage your account and subscription preferences</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Subscription Details</CardTitle>
            <CardDescription>Your current Plus Plan subscription</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-medium">Plan</span>
              <Badge className="bg-[#007aff]">Plus Plan</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-medium">Price</span>
              <span>$19.99/month</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-medium">Next Billing</span>
              <span>August 20, 2025</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-medium">Status</span>
              <Badge variant="outline" className="bg-green-100 text-green-800">Active</Badge>
            </div>
            <Separator />
            <div className="space-y-2">
              <h4 className="font-medium">Usage</h4>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Users</span>
                  <span>4/5</span>
                </div>
                <Progress value={80} />
                <div className="flex justify-between text-sm">
                  <span>Products</span>
                  <span>147/200</span>
                </div>
                <Progress value={74} />
              </div>
            </div>
            <Button variant="outline" className="w-full">
              <CreditCard className="w-4 h-4 mr-2" />
              Update Payment Method
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
            <CardDescription>Manage your account details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Company Name</label>
              <Input defaultValue="Acme Corporation" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Email</label>
              <Input defaultValue="admin@acme.com" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Phone</label>
              <Input defaultValue="+1 (555) 123-4567" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Address</label>
              <Input defaultValue="123 Business Ave, Suite 100" />
            </div>
            <Button className="w-full">Save Changes</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Notification Preferences</CardTitle>
            <CardDescription>Choose what notifications you want to receive</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Order Updates</p>
                <p className="text-sm text-muted-foreground">Get notified about order status changes</p>
              </div>
              <input type="checkbox" defaultChecked className="toggle" />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Marketing Emails</p>
                <p className="text-sm text-muted-foreground">Receive product updates and promotions</p>
              </div>
              <input type="checkbox" className="toggle" />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Security Alerts</p>
                <p className="text-sm text-muted-foreground">Important account security notifications</p>
              </div>
              <input type="checkbox" defaultChecked className="toggle" />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Weekly Reports</p>
                <p className="text-sm text-muted-foreground">Summary of your account activity</p>
              </div>
              <input type="checkbox" defaultChecked className="toggle" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Support & Help</CardTitle>
            <CardDescription>Get assistance and access resources</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full justify-start">
              <MessageSquare className="w-4 h-4 mr-2" />
              Live Chat Support
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Download className="w-4 h-4 mr-2" />
              Download User Guide
            </Button>
            <Button variant="outline" className="w-full justify-start">
              Contact Support Team
            </Button>
            <Separator />
            <div className="text-center text-sm text-muted-foreground">
              <p>Plus Plan includes priority support</p>
              <p>Average response time: &lt; 2 hours</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}