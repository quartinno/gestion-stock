import React from 'react';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { Search, Bell, Scan, AlertTriangle, Clock, User, Settings, LogOut } from 'lucide-react';

function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="relative size-12">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 64 59"
        >
          <g id="LOGO">
            <circle
              cx="29.5"
              cy="29.5"
              fill="url(#paint0_linear_1_3115)"
              id="shape"
              r="29.5"
            />
            <g filter="url(#filter0_d_1_3115)" id="shape_2">
              <circle
                cx="45.1176"
                cy="17.3529"
                fill="url(#paint1_linear_1_3115)"
                r="13.8824"
              />
            </g>
          </g>
          <defs>
            <filter
              colorInterpolationFilters="sRGB"
              filterUnits="userSpaceOnUse"
              height="35.7647"
              id="filter0_d_1_3115"
              width="35.7647"
              x="28.2353"
              y="3.47059"
            >
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix
                in="SourceAlpha"
                result="hardAlpha"
                type="matrix"
                values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
              />
              <feOffset dx="1" dy="4" />
              <feGaussianBlur stdDeviation="2" />
              <feColorMatrix
                type="matrix"
                values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"
              />
              <feBlend
                in2="BackgroundImageFix"
                mode="normal"
                result="effect1_dropShadow_1_3115"
              />
              <feBlend
                in="SourceGraphic"
                in2="effect1_dropShadow_1_3115"
                mode="normal"
                result="shape"
              />
            </filter>
            <linearGradient
              gradientUnits="userSpaceOnUse"
              id="paint0_linear_1_3115"
              x1="3.35402"
              x2="56.615"
              y1="70.9033"
              y2="43.6757"
            >
              <stop stopColor="#0D65D2" />
              <stop offset="1" stopColor="#00214D" />
            </linearGradient>
            <linearGradient
              gradientUnits="userSpaceOnUse"
              id="paint1_linear_1_3115"
              x1="41.4941"
              x2="62.9218"
              y1="35.9105"
              y2="28.0668"
            >
              <stop stopColor="#00F0CA" />
              <stop offset="1" stopColor="#02A189" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div>
        <span className="text-2xl font-bold text-[#00193b]">Quantixa</span>
        <p className="text-xs text-gray-600">Pharmacy Management</p>
      </div>
    </div>
  );
}

interface HeaderProps {
  onOpenScanner: () => void;
}

export function Header({ onOpenScanner }: HeaderProps) {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        <Logo />
        
        <div className="flex items-center gap-4">
          {/* Quick Barcode Scanner */}
          <Button 
            variant="outline" 
            size="sm"
            onClick={onOpenScanner}
            className="hover:bg-[#007aff] hover:text-white transition-colors"
          >
            <Scan className="w-4 h-4 mr-2" />
            Quick Scan
          </Button>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input placeholder="Search products, clients, invoices..." className="pl-9 w-80" />
          </div>
          
          {/* Notifications with alerts */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="w-5 h-5" />
                <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 bg-red-500 text-white text-xs flex items-center justify-center">
                  3
                </Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <div className="p-2 font-medium border-b">Notifications</div>
              <DropdownMenuItem className="p-3">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Low Stock Alert</p>
                    <p className="text-xs text-muted-foreground">Paracetamol 500mg has only 8 units left</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      2 hours ago
                    </p>
                  </div>
                </div>
              </DropdownMenuItem>
              <DropdownMenuItem className="p-3">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Expiry Warning</p>
                    <p className="text-xs text-muted-foreground">8 products expiring within 30 days</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      4 hours ago
                    </p>
                  </div>
                </div>
              </DropdownMenuItem>
              <DropdownMenuItem className="p-3">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Overdue Payment</p>
                    <p className="text-xs text-muted-foreground">Ana Garcia has overdue balance of $245.80</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      1 day ago
                    </p>
                  </div>
                </div>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          {/* User Profile */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2">
                <Avatar className="w-8 h-8">
                  <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=admin" />
                  <AvatarFallback>AD</AvatarFallback>
                </Avatar>
                <div className="text-left">
                  <p className="text-sm font-medium">Admin User</p>
                  <p className="text-xs text-muted-foreground">Pharmacy Manager</p>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <User className="w-4 h-4 mr-2" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-600">
                <LogOut className="w-4 h-4 mr-2" />
                Log Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}