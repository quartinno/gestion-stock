import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Card, CardContent } from "./ui/card";
import { Input } from "./ui/input";
import { X, Camera, Scan, CheckCircle, AlertCircle, Keyboard } from 'lucide-react';

interface BarcodeScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onScanResult: (barcode: string, productData?: any) => void;
}

export function BarcodeScanner({ isOpen, onClose, onScanResult }: BarcodeScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [productFound, setProductFound] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [manualMode, setManualMode] = useState(false);
  const [manualBarcode, setManualBarcode] = useState('');
  const [cameraSupported, setCameraSupported] = useState(true);
  const [hasAttemptedCamera, setHasAttemptedCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Mock product database for demo
  const mockProducts = {
    '7891234567890': {
      name: 'Paracetamol 500mg',
      category: 'Analgesics',
      price: '$2.50',
      supplier: 'MedSupply Co.',
      inStock: true,
      stock: 8
    },
    '7891234567891': {
      name: 'Amoxicillin 250mg', 
      category: 'Antibiotics',
      price: '$8.90',
      supplier: 'PharmaHealth',
      inStock: true,
      stock: 45
    },
    '7891234567892': {
      name: 'Vitamin C 1000mg',
      category: 'Vitamins',
      price: '$15.80',
      supplier: 'VitaHealth',
      inStock: true,
      stock: 12
    }
  };

  const checkCameraSupport = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraSupported(false);
        return false;
      }

      // Check if we can enumerate devices (this doesn't require permissions)
      const devices = await navigator.mediaDevices.enumerateDevices();
      const hasCamera = devices.some(device => device.kind === 'videoinput');
      setCameraSupported(hasCamera);
      return hasCamera;
    } catch (err) {
      setCameraSupported(false);
      return false;
    }
  };

  const startCamera = async () => {
    try {
      setError(null);
      setIsScanning(true);
      setHasAttemptedCamera(true);

      // Check if camera is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera not supported by this browser');
      }
      
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment', // Use back camera if available
          width: { ideal: 1280 },
          height: { ideal: 720 }
        } 
      });
      
      setStream(mediaStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play();
      }
    } catch (err: any) {
      let errorMessage = 'Camera access denied or not available';
      
      if (err.name === 'NotAllowedError') {
        errorMessage = 'Camera permission denied. Use manual entry below instead.';
        setManualMode(true); // Auto-switch to manual mode
      } else if (err.name === 'NotFoundError') {
        errorMessage = 'No camera found on this device.';
        setManualMode(true);
      } else if (err.name === 'NotSupportedError') {
        errorMessage = 'Camera not supported by this browser.';
        setManualMode(true);
      } else if (err.name === 'NotReadableError') {
        errorMessage = 'Camera is already in use by another application.';
      }
      
      setError(errorMessage);
      setIsScanning(false);
      setCameraSupported(false);
      
      // Don't log to console for permission denied - this is expected behavior
      if (err.name !== 'NotAllowedError') {
        console.error('Error accessing camera:', err);
      }
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsScanning(false);
  };

  const simulateBarcodeScan = () => {
    // Simulate scanning different barcodes for demo
    const barcodes = Object.keys(mockProducts);
    const randomBarcode = barcodes[Math.floor(Math.random() * barcodes.length)];
    
    setScanResult(randomBarcode);
    const product = mockProducts[randomBarcode as keyof typeof mockProducts];
    setProductFound(product);
    stopCamera();
  };

  const handleScanComplete = () => {
    if (scanResult) {
      onScanResult(scanResult, productFound);
      handleClose();
    }
  };

  const handleManualScan = () => {
    if (manualBarcode.trim()) {
      setScanResult(manualBarcode.trim());
      const product = mockProducts[manualBarcode.trim() as keyof typeof mockProducts];
      setProductFound(product || null);
      setManualMode(false);
      setManualBarcode('');
    }
  };

  const handleClose = () => {
    stopCamera();
    setScanResult(null);
    setProductFound(null);
    setError(null);
    setManualMode(false);
    setManualBarcode('');
    setHasAttemptedCamera(false);
    onClose();
  };

  useEffect(() => {
    if (isOpen) {
      checkCameraSupport().then((supported) => {
        if (supported && !hasAttemptedCamera) {
          startCamera();
        } else if (!supported) {
          setManualMode(true);
          setError('Camera not available - using manual entry mode');
        }
      });
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Scan className="w-5 h-5" />
            Barcode Scanner
          </DialogTitle>
          <DialogDescription>
            Point your camera at a product barcode to scan
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Always show manual entry option prominently */}
          {(manualMode || error || !cameraSupported) && (
            <Card className="border-blue-200 bg-blue-50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2 text-blue-600">
                  <Keyboard className="w-4 h-4" />
                  <span className="font-medium">
                    {error ? 'Camera Unavailable - Manual Entry' : 'Manual Barcode Entry'}
                  </span>
                </div>
                {error && (
                  <div className="flex items-start gap-2 text-sm text-blue-700 bg-blue-100 p-2 rounded">
                    <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}
                <div className="space-y-2">
                  <Input
                    placeholder="Enter barcode number (e.g., 7891234567890)..."
                    value={manualBarcode}
                    onChange={(e) => setManualBarcode(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleManualScan();
                      }
                    }}
                    className="font-mono"
                    autoFocus
                  />
                  
                  {/* Sample barcodes for testing */}
                  <div className="text-xs text-muted-foreground">
                    <span>Try these samples: </span>
                    {Object.keys(mockProducts).map((barcode, index) => (
                      <button
                        key={barcode}
                        onClick={() => setManualBarcode(barcode)}
                        className="text-blue-600 hover:text-blue-800 underline ml-1"
                      >
                        {barcode}
                        {index < Object.keys(mockProducts).length - 1 && ', '}
                      </button>
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button onClick={handleManualScan} size="sm" disabled={!manualBarcode.trim()}>
                      <Scan className="w-3 h-3 mr-1" />
                      Scan Barcode
                    </Button>
                    {cameraSupported && !error && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => {
                          setManualMode(false);
                          setManualBarcode('');
                          startCamera();
                        }}
                      >
                        <Camera className="w-3 h-3 mr-1" />
                        Try Camera
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {scanResult ? (
            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2 text-green-600">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-medium">Barcode Scanned Successfully!</span>
                </div>
                
                <div className="space-y-2">
                  <p className="text-sm">
                    <span className="font-medium">Barcode:</span> {scanResult}
                  </p>
                  
                  {productFound ? (
                    <div className="space-y-1">
                      <p className="font-medium text-[#007aff]">{productFound.name}</p>
                      <p className="text-sm text-muted-foreground">{productFound.category}</p>
                      <p className="text-sm">Price: {productFound.price}</p>
                      <p className="text-sm">Stock: {productFound.stock} units</p>
                      <Badge variant="outline">{productFound.supplier}</Badge>
                    </div>
                  ) : (
                    <div className="p-2 border rounded bg-yellow-50">
                      <p className="text-sm text-yellow-700">Product not found in inventory</p>
                      <p className="text-xs text-yellow-600">You can add this as a new product</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleScanComplete} className="flex-1">
                    {productFound ? 'Use Product' : 'Add New Product'}
                  </Button>
                  <Button variant="outline" onClick={() => {
                    setScanResult(null);
                    setProductFound(null);
                    if (!error) {
                      startCamera();
                    } else {
                      setManualMode(true);
                    }
                  }}>
                    Scan Again
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : !manualMode && !error && cameraSupported && (
            <>
              <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  autoPlay
                  playsInline
                  muted
                />
                
                {/* Scanning overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-64 h-64 border-2 border-white rounded-lg relative">
                    <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-[#007aff] rounded-tl"></div>
                    <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-[#007aff] rounded-tr"></div>
                    <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-[#007aff] rounded-bl"></div>
                    <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-[#007aff] rounded-br"></div>
                    
                    {/* Scanning line animation */}
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-[#007aff] animate-pulse"></div>
                  </div>
                </div>

                <div className="absolute bottom-4 left-0 right-0 text-center">
                  <Badge className="bg-black/50 text-white">
                    {isScanning ? 'Scanning...' : 'Camera Loading...'}
                  </Badge>
                </div>
              </div>

              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    onClick={simulateBarcodeScan} 
                    disabled={!isScanning}
                    variant="outline"
                  >
                    <Scan className="w-4 h-4 mr-2" />
                    Demo Scan
                  </Button>
                  <Button 
                    onClick={() => setManualMode(true)}
                    variant="outline"
                  >
                    <Keyboard className="w-4 h-4 mr-2" />
                    Manual Entry
                  </Button>
                </div>
                
                <p className="text-xs text-center text-muted-foreground">
                  Position the barcode within the frame above or use manual entry
                </p>
              </div>
            </>
          )}

          {/* Show camera options only if no manual mode and camera hasn't failed */}
          {!manualMode && !isScanning && !error && cameraSupported && (
            <div className="text-center space-y-3">
              <div className="p-8 border-2 border-dashed border-gray-300 rounded-lg">
                <Camera className="w-12 h-12 mx-auto text-gray-400 mb-3" />
                <p className="text-sm text-muted-foreground mb-3">Camera ready to scan</p>
                <Button onClick={startCamera} className="mb-2">
                  <Camera className="w-4 h-4 mr-2" />
                  Start Camera
                </Button>
              </div>
              <Button 
                onClick={() => setManualMode(true)}
                variant="outline"
                className="w-full"
              >
                <Keyboard className="w-4 h-4 mr-2" />
                Use Manual Entry Instead
              </Button>
            </div>
          )}

          <div className="flex gap-2">
            <Button variant="outline" onClick={handleClose} className="flex-1">
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        </div>

        <canvas ref={canvasRef} className="hidden" />
      </DialogContent>
    </Dialog>
  );
}